from __future__ import absolute_import

import base64
import gzip
import re
import struct
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlsplit, urlunsplit


TSGZ = b"TIKTIKTSGZ"
TRAW = b"TIKTIKRAW"
TPIX = b"TIKTIKPX"


def _paeth(a, b, c):
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def _is_ts(data):
    """Four MPEG-TS packets in a row. Two sync bytes is too easy to hit by accident."""
    if not data or len(data) <= 188 * 3:
        return False
    if data[0] != 0x47:
        return False
    return data[188] == 0x47 and data[376] == 0x47 and data[564] == 0x47


def _find_ts(data):
    blob = data or b""
    limit = len(blob) - (188 * 3)
    for index in range(0, max(0, limit)):
        if blob[index] != 0x47:
            continue
        if blob[index + 188] == 0x47 and blob[index + 376] == 0x47 and blob[index + 564] == 0x47:
            return blob[index:]
    return None


def _as_ts(data):
    if _is_ts(data):
        return bytes(data)
    return _find_ts(data)


def _one_member(data, bits):
    try:
        obj = zlib.decompressobj(bits)
        out = obj.decompress(data)
        out += obj.flush()
    except Exception:
        return None
    return out or None


def _gunzip_member(data):
    return _one_member(data, 16 + zlib.MAX_WBITS)


def _inflate_member(data):
    for bits in (zlib.MAX_WBITS, -zlib.MAX_WBITS):
        out = _one_member(data, bits)
        if out:
            return out
    return None


def _compressed_ts(blob):
    """Gzip or zlib wrapped around MPEG-TS, with or without a marker in front."""
    data = blob or b""
    checks = (
        (b"\x1f\x8b\x08", _gunzip_member),
        (b"\x78\x01", _inflate_member),
        (b"\x78\x9c", _inflate_member),
        (b"\x78\xda", _inflate_member),
    )
    for magic, unpack in checks:
        start = 0
        found = 0
        while found < 16:
            at = data.find(magic, start)
            if at < 0:
                break
            found += 1
            start = at + 1
            ts = _as_ts(unpack(data[at:]))
            if ts:
                return ts
    return None


def _maybe_base64(blob):
    text = blob or b""
    if len(text) < 32 or len(text) > 8 * 1024 * 1024:
        return None
    stripped = bytes(byte for byte in text if byte not in b" \t\r\n")
    if not stripped or len(stripped) % 4:
        return None
    for byte in stripped:
        if byte not in b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=":
            return None
    try:
        raw = base64.b64decode(stripped, validate=False)
    except Exception:
        return None
    if not raw or len(raw) <= 188:
        return None
    return raw


def _png_extra(data):
    """Bytes after IEND, plus text chunks. Both have carried the video before."""
    tail = b""
    extras = []
    if len(data) < 16 or data[0] != 0x89 or data[1] != 0x50:
        return tail, extras
    off = 8
    while off + 8 <= len(data):
        length = struct.unpack_from(">I", data, off)[0]
        if length < 0 or length > len(data) - off - 12:
            break
        kind = data[off + 4:off + 8]
        chunk = data[off + 8:off + 8 + length]
        off += 12 + length
        if kind == b"IEND":
            tail = data[off:]
            break
        if kind == b"tEXt":
            parts = chunk.split(b"\x00", 1)
            if len(parts) == 2 and parts[1]:
                extras.append(parts[1])
        elif kind == b"zTXt" and b"\x00" in chunk:
            _name, rest = chunk.split(b"\x00", 1)
            if len(rest) > 1:
                extras.append(rest[1:])
        elif kind == b"iTXt" and b"\x00" in chunk:
            _name, rest = chunk.split(b"\x00", 1)
            if len(rest) > 2:
                extras.append(rest[2:])
    return tail, extras


def _png_iend_ts(data):
    tail, _extras = _png_extra(data)
    return _as_ts(tail)


def _webp_exif_ts(data):
    if len(data) < 16 or data[0:4] != b"RIFF" or data[8:12] != b"WEBP":
        return None
    off = 12
    while off + 8 <= len(data):
        tag = data[off:off + 4]
        size = struct.unpack_from("<I", data, off + 4)[0]
        off += 8
        if size < 0 or off + size > len(data):
            return None
        if tag == b"EXIF":
            chunk = data[off:off + size]
            if len(chunk) >= 188 and chunk[0] == 0x47 and chunk[188] == 0x47:
                return chunk
            return None
        off += size + (size & 1)
    return None


def _png_rgb(data):
    if len(data) < 8 or data[0] != 0x89 or data[1] != 0x50:
        return None
    off = 8
    width = height = depth = color_type = interlace = 0
    idats = []
    while off + 8 <= len(data):
        length = struct.unpack_from(">I", data, off)[0]
        if length > len(data) - off - 12:
            return None
        kind = data[off + 4:off + 8]
        chunk = data[off + 8:off + 8 + length]
        if kind == b"IHDR":
            width, height = struct.unpack_from(">II", chunk, 0)
            depth = chunk[8]
            color_type = chunk[9]
            interlace = chunk[12]
        elif kind == b"IDAT":
            idats.append(chunk)
        elif kind == b"IEND":
            break
        off += 12 + length
    if not width or not height or depth != 8 or interlace or color_type not in (2, 6):
        return None
    raw = zlib.decompress(b"".join(idats))
    bpp = 4 if color_type == 6 else 3
    stride = width * bpp
    rgb = bytearray(width * height * 3)
    src = 0
    dst = 0
    prev = bytearray(stride)
    for _y in range(height):
        if src + 1 + stride > len(raw):
            return None
        filt = raw[src]
        src += 1
        row = raw[src:src + stride]
        src += stride
        recon = bytearray(stride)
        for i in range(stride):
            a = recon[i - bpp] if i >= bpp else 0
            b = prev[i]
            c = prev[i - bpp] if i >= bpp else 0
            value = row[i]
            if filt == 1:
                value = (value + a) & 255
            elif filt == 2:
                value = (value + b) & 255
            elif filt == 3:
                value = (value + ((a + b) >> 1)) & 255
            elif filt == 4:
                value = (value + _paeth(a, b, c)) & 255
            elif filt != 0:
                return None
            recon[i] = value
        if color_type == 2:
            rgb[dst:dst + stride] = recon
            dst += stride
        else:
            for i in range(0, stride, 4):
                rgb[dst] = recon[i]
                rgb[dst + 1] = recon[i + 1]
                rgb[dst + 2] = recon[i + 2]
                dst += 3
        prev = recon
    return bytes(rgb)


def _marked_gzip_ts(rgb):
    """Old picture pack: TIKTIKPX, a 4-byte length, then gzip of the video."""
    data = rgb or b""
    start = 0
    while True:
        at = data.find(TPIX, start)
        if at < 0 or at + 12 > len(data):
            return None
        size = struct.unpack_from(">I", data, at + 8)[0]
        if size <= 0 or at + 12 + size > len(data):
            start = at + 1
            continue
        ts = _as_ts(_gunzip_member(data[at + 12:at + 12 + size]))
        if ts:
            return ts
        start = at + 1


def _marked_raw_ts(data):
    """Old file pack: TIKTIKRAW then the video bytes."""
    at = (data or b"").find(TRAW)
    if at < 0:
        return None
    return _as_ts(data[at + len(TRAW):])


def _marked_gzip_file(data):
    """Old file pack: TIKTIKTSGZ then gzip of the video."""
    at = (data or b"").find(TSGZ)
    if at < 0:
        return None
    return _as_ts(_gunzip_member(data[at + len(TSGZ):]))


def _blobs_from(blob):
    if not blob:
        return
    yield blob
    decoded = _maybe_base64(blob)
    if decoded:
        yield decoded


def _from_blobs(blobs):
    for blob in blobs:
        for item in _blobs_from(blob):
            if _is_ts(item):
                return bytes(item)
            ts = _compressed_ts(item)
            if ts:
                return ts
            ts = _find_ts(item)
            if ts:
                return ts
    return None


def _unwrap_pixels(data):
    try:
        rgb = _png_rgb(data)
    except Exception:
        rgb = None
    if not rgb or len(rgb) < 12:
        return None
    marked = _marked_gzip_ts(rgb)
    if marked:
        return marked
    channels = (rgb[0::3], rgb[1::3], rgb[2::3])
    return _from_blobs((rgb,) + channels)


def unwrap_segment(data):
    """Turn a wrapped image segment into MPEG-TS.

    The old packs stay first: video after the PNG end, TIKTIKPX in the pixels,
    TIKTIKRAW, and TIKTIKTSGZ. After those, look for gzip, zlib, or bare video
    in the pixels, in one colour channel, in a text chunk, or in the file.
    """
    data = bytes(data or b"")
    found = _webp_exif_ts(data)
    if found and _is_ts(found):
        return found
    found = _png_iend_ts(data)
    if found:
        return found
    tail, extras = _png_extra(data)
    found = _from_blobs([tail] + extras)
    if found:
        return found
    found = _unwrap_pixels(data)
    if found:
        return found
    found = _marked_raw_ts(data)
    if found:
        return found
    found = _marked_gzip_file(data)
    if found:
        return found
    found = _from_blobs([data])
    if found:
        return found
    raise RuntimeError("TS payload not found")


class PlaylistBlocked(Exception):
    """Kodi's own address was told to wait. wait is the seconds left."""

    def __init__(self, wait):
        Exception.__init__(self, "playlist host blocked")
        self.wait = wait


_COOL_UNTIL = {}


def _playback_host(url):
    return (urlparse(url or "").netloc or "").lower()


def _mark_blocked(url, response):
    wait = 20
    try:
        wait = int(response.headers.get("Retry-After"))
    except (TypeError, ValueError):
        wait = 20
    wait = min(120, max(5, wait))
    _COOL_UNTIL[_playback_host(url)] = time.time() + wait
    raise PlaylistBlocked(wait)


_HDM_LOCK = threading.Lock()
_HDM_TOKENS = {}


def _hdm_channel(url):
    match = re.search(r"https://cdn\.hdm1\.net/([^/?#]+)/", url or "", re.I)
    return match.group(1) if match else ""


def _query_token(url):
    for key, value in parse_qsl(urlsplit(url or "").query, keep_blank_values=True):
        if key == "token" and value:
            return value
    return ""


def _token_expiry(token):
    try:
        raw = (token or "").split(".", 1)[0]
        raw = raw.replace("-", "+").replace("_", "/")
        raw += "=" * (-len(raw) % 4)
        payload = base64.b64decode(raw).decode("utf-8", "ignore")
        return int(payload.rsplit("|", 1)[-1])
    except (TypeError, ValueError):
        return 0


def _replace_token(url, token):
    parts = urlsplit(url or "")
    query = []
    found = False
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        if key == "token":
            query.append((key, token))
            found = True
        else:
            query.append((key, value))
    if not found:
        query.append(("token", token))
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _refresh_hdm_token(channel, token):
    import requests
    if not channel or not token:
        return ""
    try:
        response = requests.post(
            "https://wideiptv.top/api/refresh_token.php",
            json={"channel": channel, "current_token": token},
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                ),
                "Referer": "https://wideiptv.top/",
                "Origin": "https://wideiptv.top",
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=15,
            verify=False,
        )
        data = response.json() if response.status_code == 200 else {}
    except Exception:
        return ""
    if not isinstance(data, dict) or not data.get("success"):
        return ""
    return str(data.get("token") or "")


def _fresh_hdm_url(url, force=False):
    """Keep a wideiptv playlist token alive. InputStream Adaptive reloads the
    local manifest; this swaps the upstream token before that reload."""
    channel = _hdm_channel(url)
    if not channel:
        return url
    with _HDM_LOCK:
        token = _HDM_TOKENS.get(channel) or _query_token(url)
        if token and not force and _token_expiry(token) - time.time() > 40:
            return _replace_token(url, token)
        fresh = _refresh_hdm_token(channel, token)
        if fresh:
            _HDM_TOKENS[channel] = fresh
            return _replace_token(url, fresh)
        if token:
            return _replace_token(url, token)
        return url


def _without_cache_buster(url):
    """Drop a previous cache-buster without turning ?_=1&token= into &token=."""
    parts = urlsplit(url or "")
    query = [(key, value) for key, value in parse_qsl(parts.query, keep_blank_values=True) if key != "_"]
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def _with_cache_buster(url):
    # This CDN copies the query onto the quality playlist. A leading _= then
    # loses the ? and the next request 404s. The token already changes.
    if _hdm_channel(url):
        return _without_cache_buster(url)
    fresh = _without_cache_buster(url)
    joiner = "&" if urlsplit(fresh).query else "?"
    return fresh + joiner + "_=" + str(int(time.time() * 1000))


def _playlist_text(url, headers):
    import requests
    url = _fresh_hdm_url(url)
    remaining = _COOL_UNTIL.get(_playback_host(url), 0) - time.time()
    if remaining > 0:
        raise PlaylistBlocked(int(remaining) + 1)
    fresh = _with_cache_buster(url)
    timeout = 25 if "sid=" in (fresh or "") else 15
    response = requests.get(fresh, headers=headers or {}, timeout=timeout, verify=False)
    if response.status_code in (401, 403) and _hdm_channel(url):
        fresh = _with_cache_buster(_fresh_hdm_url(url, force=True))
        response = requests.get(fresh, headers=headers or {}, timeout=timeout, verify=False)
    if response.status_code == 429:
        _mark_blocked(url, response)
    response.raise_for_status()
    return response.text or "", response.url or fresh


def _refresh_gap(playlist):
    """Seconds until a new piece can exist. None means the playlist is complete."""
    if "#EXT-X-ENDLIST" in (playlist or ""):
        return None
    match = re.search(r"#EXT-X-TARGETDURATION:(\d+)", playlist or "")
    if match:
        return max(1, int(match.group(1)))
    durations = re.findall(r"#EXTINF:([\d.]+)", playlist or "")
    if durations:
        try:
            return max(1, int(float(durations[-1])))
        except ValueError:
            pass
    return 6


def _needs_unwrap(playlist):
    """True when a media playlist's segments are images with video inside."""
    for line in (playlist or "").splitlines():
        item = line.strip()
        if not item or item.startswith("#"):
            continue
        lowered = item.lower()
        if ".image" in lowered or "tiktokcdn" in lowered:
            return True
    return False


def _variant_urls(playlist, base_url):
    found = []
    expect = False
    for raw in (playlist or "").splitlines():
        item = raw.strip()
        if item.startswith("#EXT-X-STREAM-INF"):
            expect = True
            continue
        if not expect or not item or item.startswith("#"):
            continue
        expect = False
        found.append(urljoin(base_url, item))
    return found


def _master_hides_images(playlist, base_url, headers):
    """A master playlist hides images one level down, inside each quality."""
    if "#EXT-X-STREAM-INF" not in (playlist or ""):
        return False
    if _needs_unwrap(playlist):
        return False
    for variant in _variant_urls(playlist, base_url):
        try:
            text, _final = _playlist_text(variant, headers)
        except Exception:
            continue
        return _needs_unwrap(text)
    return False


_URI_ATTR = re.compile(r'URI="([^"]*)"', re.I)


def _absolutize(playlist, base_url):
    """Make every address in a playlist absolute, so it can be served locally."""
    lines = []
    for raw in (playlist or "").splitlines():
        item = raw.strip()
        if not item:
            lines.append(raw)
            continue
        if item.startswith("#"):
            def repl(match, base=base_url):
                target = match.group(1)
                if target.startswith("http://") or target.startswith("https://"):
                    return match.group(0)
                return 'URI="%s"' % urljoin(base, target)
            lines.append(_URI_ATTR.sub(repl, raw))
            continue
        if item.startswith("http://") or item.startswith("https://"):
            lines.append(item)
            continue
        lines.append(urljoin(base_url, item))
    return "\n".join(lines) + "\n"


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        proxy = self.server.proxy
        path = self.path.split("?", 1)[0]
        try:
            if path.endswith("live.m3u8"):
                body = proxy.playlist().encode("utf-8")
                content_type = "application/vnd.apple.mpegurl"
            elif path.startswith("/v/"):
                vid = path[3:]
                if vid.endswith(".m3u8"):
                    vid = vid[:-5]
                body = proxy.variant(vid).encode("utf-8")
                content_type = "application/vnd.apple.mpegurl"
            elif path.startswith("/s/"):
                sid = path[3:]
                if sid.endswith(".ts"):
                    sid = sid[:-3]
                body = proxy.segment(sid)
                content_type = "video/mp2t"
            else:
                self.send_error(404)
                return
        except Exception:
            self.send_error(502)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


class _UnwrapProxy(object):
    def __init__(self):
        self.upstream = ""
        self.headers = {}
        self.segments = {}
        self.segment_owners = {}
        self.variants = {}
        self.variant_by_url = {}
        self.served = {}
        self.seq = 0
        self.vseq = 0
        self.mode = "unwrap"
        self.seed = None
        self.seed_final = None
        self.peeked = None
        self.lock = threading.Lock()
        self.refresh_lock = threading.Lock()
        self.httpd = None
        self.thread = None

    def local_url(self):
        return "http://127.0.0.1:%s/live.m3u8" % self.httpd.server_address[1]

    def start(self, upstream, headers, mode="unwrap", seed=None, seed_final=None, peeked=None):
        self.upstream = seed_final or upstream
        self.headers = dict(headers or {})
        self.mode = mode
        self.seed = seed
        self.seed_final = seed_final or upstream
        self.peeked = peeked
        self.segments = {}
        self.segment_owners = {}
        self.variants = {}
        self.variant_by_url = {}
        self.served = {}
        self.seq = 0
        self.vseq = 0
        if self.httpd is None:
            self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
            self.httpd.proxy = self
            self.thread = threading.Thread(target=self.httpd.serve_forever, name="colossus-hls")
            self.thread.daemon = True
            self.thread.start()
        return self.local_url()

    def playlist(self):
        return self._serve("root", self._load_root)

    def _serve(self, key, load):
        """Repeat the playlist we already have until a new piece is due."""
        now = time.time()
        with self.lock:
            item = self.served.get(key)
        if item and (item[2] is None or now < item[1] + item[2]):
            return item[0]
        with self.refresh_lock:
            now = time.time()
            with self.lock:
                item = self.served.get(key)
            if item and (item[2] is None or now < item[1] + item[2]):
                return item[0]
            try:
                body, gap = load()
            except Exception as exc:
                try:
                    import xbmc
                    xbmc.log('[Colossus] Playlist refresh failed: %s' % exc, xbmc.LOGINFO)
                except Exception:
                    pass
                if item:
                    return item[0]
                raise
            with self.lock:
                self.served[key] = (body, time.time(), gap)
            return body

    def _load_root(self):
        if self.seed is not None:
            text, final = self.seed, self.seed_final
            self.seed = None
        else:
            text, final = _playlist_text(self.upstream, self.headers)
        if "#EXT-X-STREAM-INF" in text and not _needs_unwrap(text):
            body = self._rewrite_master(text, final)
        elif self.mode == "unwrap":
            body = self._rewrite_media(text, final)
        else:
            body = _absolutize(text, final)
        return body, _refresh_gap(text)

    def _port(self):
        return self.httpd.server_address[1]

    def _rewrite_master(self, text, base_url):
        """Point each quality at a local playlist. Those playlists unwrap the images."""
        lines = []
        expect = False
        fresh = []
        port = self._port()
        with self.lock:
            for raw in text.splitlines():
                item = raw.strip()
                if item.startswith("#EXT-X-STREAM-INF"):
                    lines.append(raw)
                    expect = True
                    continue
                if expect and item and not item.startswith("#"):
                    vid = self._variant_id(urljoin(base_url, item))
                    fresh.append(vid)
                    lines.append("http://127.0.0.1:%s/v/%s.m3u8" % (port, vid))
                    expect = False
                    continue
                lines.append(raw)
            dropped = self._drop_stale(self.variants, fresh)
            for vid in dropped:
                self._forget_owner(vid)
                self.served.pop("v:" + vid, None)
                for address, mapped in list(self.variant_by_url.items()):
                    if mapped == vid:
                        self.variant_by_url.pop(address, None)
        return "\n".join(lines) + "\n"

    def _rewrite_media(self, text, base_url, owner="media"):
        """Replace image segment URLs with local .ts addresses."""
        lines = []
        fresh = []
        port = self._port()
        with self.lock:
            for raw in text.splitlines():
                item = raw.strip()
                if item and not item.startswith("#"):
                    target = item
                    if not (item.startswith("http://") or item.startswith("https://")):
                        target = urljoin(base_url, item)
                    if target.startswith("http://") or target.startswith("https://"):
                        self.seq += 1
                        sid = str(self.seq)
                        self.segments[sid] = target
                        self.segment_owners[sid] = owner
                        fresh.append(sid)
                        raw = "http://127.0.0.1:%s/s/%s.ts" % (port, sid)
                lines.append(raw)
            self._drop_owner(owner, fresh)
        return "\n".join(lines) + "\n"

    def _drop_stale(self, store, fresh):
        """Drop addresses from older refreshes. Keep the playlist just built."""
        keep = set(fresh)
        for key in sorted(store, key=int)[-20:]:
            keep.add(key)
        dropped = []
        if len(store) <= len(keep):
            return dropped
        for key in list(sorted(store, key=int)):
            if key in keep:
                continue
            store.pop(key, None)
            dropped.append(key)
        return dropped

    def _drop_owner(self, owner, fresh):
        """Drop this playlist's old segments. Leave the other quality alone."""
        owned = [key for key, who in self.segment_owners.items() if who == owner]
        keep = set(fresh)
        for key in sorted(owned, key=int)[-250:]:
            keep.add(key)
        for key in owned:
            if key in keep:
                continue
            self.segments.pop(key, None)
            self.segment_owners.pop(key, None)

    def _forget_owner(self, owner):
        for key, who in list(self.segment_owners.items()):
            if who != owner:
                continue
            self.segments.pop(key, None)
            self.segment_owners.pop(key, None)

    def _variant_id(self, absolute):
        vid = self.variant_by_url.get(absolute)
        if vid:
            return vid
        self.vseq += 1
        vid = str(self.vseq)
        self.variant_by_url[absolute] = vid
        self.variants[vid] = absolute
        return vid

    def variant(self, vid):
        return self._serve("v:" + str(vid), lambda: self._load_variant(vid))

    def _load_variant(self, vid):
        with self.lock:
            url = self.variants.get(vid)
        if not url:
            raise RuntimeError("unknown variant")
        peeked = self.peeked
        if peeked and peeked[0] == url:
            text, final = peeked[1], peeked[2]
            self.peeked = None
        else:
            text, final = _playlist_text(url, self.headers)
        if self.mode == "unwrap" and _needs_unwrap(text):
            body = self._rewrite_media(text, final, owner=vid)
        else:
            body = _absolutize(text, final)
        return body, _refresh_gap(text)

    def segment(self, sid):
        import requests
        with self.lock:
            url = self.segments.get(sid)
        if not url:
            raise RuntimeError("unknown segment")
        response = requests.get(url, headers=self.headers, timeout=20, verify=False)
        response.raise_for_status()
        return unwrap_segment(response.content)


_PROXY = _UnwrapProxy()


def start_wrapped_playlist(play_url, headers):
    """Serve a local HLS playlist when segments are images with video inside.

    The images can be the segments of this playlist, or one level down inside
    a master playlist's quality versions.
    """
    if ".m3u8" not in (play_url or "").lower():
        return None
    if (play_url or "").startswith("http://127.0.0.1:"):
        return None
    fetch_headers = dict(headers or {})
    if not fetch_headers.get("User-Agent") and not fetch_headers.get("user-agent"):
        fetch_headers["User-Agent"] = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )
    try:
        text, final = _playlist_text(play_url, fetch_headers)
    except PlaylistBlocked:
        raise
    except Exception as exc:
        try:
            import xbmc
            xbmc.log("[Colossus] Playlist check failed: %s" % exc, xbmc.LOGINFO)
        except Exception:
            pass
        return None
    headers = fetch_headers
    peeked = None
    needs = _needs_unwrap(text)
    if not needs and "#EXT-X-STREAM-INF" in text:
        for variant in _variant_urls(text, final):
            try:
                variant_text, variant_final = _playlist_text(variant, headers)
            except Exception:
                continue
            peeked = (variant, variant_text, variant_final)
            needs = _needs_unwrap(variant_text)
            break
    mode = "unwrap" if needs else "pass"
    return _PROXY.start(
        play_url,
        headers,
        mode=mode,
        seed=text,
        seed_final=final,
        peeked=peeked,
    ), mode
