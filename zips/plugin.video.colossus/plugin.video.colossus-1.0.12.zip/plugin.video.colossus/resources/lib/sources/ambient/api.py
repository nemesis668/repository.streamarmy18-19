from __future__ import absolute_import

from resources.lib.core.remote import RemoteError, call


class AmbientError(Exception):
    pass


def _run(name, payload=None, on_progress=None):
    try:
        return call('ambient', name, [payload or {}], on_progress=on_progress) or {}
    except RemoteError as exc:
        raise AmbientError(str(exc))


def browse(payload, on_progress=None):
    return _run('browse', payload, on_progress)


def resolve(video_id, on_progress=None):
    return _run('resolve', {'id': video_id or ''}, on_progress)
