from __future__ import absolute_import

from resources.lib.core.remote import RemoteError, call


class ChatError(Exception):
    pass


def _run(name, payload):
    try:
        return call('chat', name, [payload or {}]) or {}
    except RemoteError as exc:
        raise ChatError(str(exc))


def hello(token='', nick='', password=''):
    return _run('hello', {
        'token': token or '',
        'nick': nick or '',
        'password': password or '',
    })


def send(token, text):
    return _run('send', {'token': token or '', 'text': text or ''})


def sync(token, since):
    return _run('sync', {'token': token or '', 'since': int(since or 0)})
