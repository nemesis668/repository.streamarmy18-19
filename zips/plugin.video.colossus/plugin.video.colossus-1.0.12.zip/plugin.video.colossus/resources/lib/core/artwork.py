from __future__ import absolute_import

import json
import os
import shutil
import time
import zipfile
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.core import remote


ARTWORK_VERSION = '4'
PACK_NAME = 'colossus-artwork-%s.zip' % ARTWORK_VERSION
_MARKER = 'artwork.json'
_SAMPLE = ('backdrop.png', 'button.png')


def ensure():
    if ready():
        return True
    _dismiss_busy()
    progress = xbmcgui.DialogProgress()
    progress.create(paths.ADDON_NAME, 'Downloading artwork')
    try:
        if not _install(progress):
            progress.close()
            xbmcgui.Dialog().ok(paths.ADDON_NAME, 'Artwork failed.\nTry again.')
            return False
    except Exception:
        try:
            progress.close()
        except Exception:
            pass
        xbmcgui.Dialog().ok(paths.ADDON_NAME, 'Artwork failed.\nTry again.')
        return False
    try:
        progress.close()
    except Exception:
        pass
    if ready():
        return True
    xbmcgui.Dialog().ok(paths.ADDON_NAME, 'Artwork failed.\nTry again.')
    return False


def ready():
    if _saved_version() != ARTWORK_VERSION:
        return False
    folder = paths.MEDIA_PATH
    for name in _SAMPLE:
        if not os.path.isfile(os.path.join(folder, name)):
            return False
    return True


def _install(progress):
    started = time.time()
    os.makedirs(paths.PROFILE_PATH, exist_ok=True)
    part = os.path.join(paths.PROFILE_PATH, 'artwork.zip.part')
    staging = os.path.join(paths.PROFILE_PATH, 'media.new')
    _remove(part)
    _remove(staging)
    url = '%s/artwork/%s' % (_engine(), PACK_NAME)
    if not _download(url, part, progress, started):
        _remove(part)
        return False
    if progress.iscanceled():
        _remove(part)
        return False
    _status(progress, started, 99, 'Unpacking artwork')
    if not _extract(part, staging):
        _remove(part)
        _remove(staging)
        return False
    _remove(part)
    for name in _SAMPLE:
        if not os.path.isfile(os.path.join(staging, name)):
            _remove(staging)
            return False
    _remove(paths.MEDIA_PATH)
    os.rename(staging, paths.MEDIA_PATH)
    _write_version()
    return ready()


def _download(url, dest, progress, started):
    request = Request(url, headers={'User-Agent': 'Colossus'})
    try:
        response = urlopen(request, timeout=30)
    except Exception:
        return False
    try:
        total = int(response.headers.get('Content-Length') or 0)
    except (TypeError, ValueError):
        total = 0
    got = 0
    try:
        with open(dest, 'wb') as handle:
            while True:
                if progress.iscanceled():
                    return False
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
                got += len(chunk)
                if total > 0:
                    percent = min(98, int(got * 100 / total))
                else:
                    percent = min(92, 8 + int(time.time() - started))
                _status(progress, started, percent, 'Downloading artwork')
    except Exception:
        return False
    finally:
        try:
            response.close()
        except Exception:
            pass
    if total > 0 and got != total:
        return False
    return got > 0


def _extract(pack, dest):
    os.makedirs(dest, exist_ok=True)
    try:
        with zipfile.ZipFile(pack) as archive:
            for info in archive.infolist():
                name = info.filename.replace('\\', '/').lstrip('/')
                if not name or name.endswith('/'):
                    continue
                parts = [part for part in name.split('/') if part not in ('', '.')]
                if not parts or '..' in parts:
                    return False
                target = os.path.join(dest, *parts)
                folder = os.path.dirname(target)
                if folder:
                    os.makedirs(folder, exist_ok=True)
                with archive.open(info) as source, open(target, 'wb') as output:
                    shutil.copyfileobj(source, output)
    except Exception:
        return False
    return True


def _status(progress, started, percent, message):
    elapsed = max(0, int(time.time() - started))
    if elapsed >= 1:
        unit = 'second' if elapsed == 1 else 'seconds'
        message = '%s  |  %s %s' % (message, elapsed, unit)
    try:
        progress.update(int(percent), message)
    except Exception:
        pass


def _engine():
    try:
        _token, engine, _exp = remote._load()
    except Exception:
        engine = ''
    return (engine or remote.ENGINE_FALLBACK).rstrip('/')


def _marker_path():
    return os.path.join(paths.PROFILE_PATH, _MARKER)


def _saved_version():
    try:
        with open(_marker_path(), 'r', encoding='utf-8') as handle:
            payload = json.loads(handle.read() or '{}')
    except Exception:
        return ''
    return str(payload.get('version') or '')


def _write_version():
    with open(_marker_path(), 'w', encoding='utf-8') as handle:
        handle.write(json.dumps({'version': ARTWORK_VERSION}))


def _remove(path):
    if not path or not os.path.exists(path):
        return
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
        return
    try:
        os.remove(path)
    except Exception:
        pass


def _dismiss_busy():
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
