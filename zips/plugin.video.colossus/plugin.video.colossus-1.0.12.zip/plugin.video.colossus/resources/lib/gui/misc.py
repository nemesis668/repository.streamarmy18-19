from __future__ import absolute_import

import os

import pyxbmct

from resources.lib.core import paths
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.buttons import text_button


def _tile(normal, selected, focused=False):
    if focused and os.path.exists(selected):
        return selected
    if os.path.exists(normal):
        return normal
    return paths.ICON_PATH


def documentaries_art(focused=False):
    return _tile(paths.DOC_PATH, paths.DOC_FOCUS_PATH, focused)


def webcams_art(focused=False):
    return _tile(paths.WEBCAM_PATH, paths.WEBCAM_FOCUS_PATH, focused)


def ambient_art(focused=False):
    return _tile(paths.AMBIENT_PATH, paths.AMBIENT_FOCUS_PATH, focused)


def chat_art(focused=False):
    return _tile(paths.CHAT_PATH, paths.CHAT_FOCUS_PATH, focused)


HUB_OPTIONS = (
    {
        'key': 'documentaries',
        'caption': 'DOCUMENTARIES',
        'title': 'Documentaries',
        'meta': 'Three sites  |  Categories  |  Search',
        'overview': 'Open Watch Documentaries, Top Documentary Films, or Documentary Heaven.',
        'art': documentaries_art,
    },
    {
        'key': 'webcams',
        'caption': 'WEBCAMS',
        'title': 'Webcams',
        'meta': 'Three sites  |  Sections  |  Search',
        'overview': 'Open SkylineWebcams, EarthCam, or Webcamtaxi.',
        'art': webcams_art,
    },
    {
        'key': 'ambient',
        'caption': 'AMBIENT',
        'title': 'Ambient',
        'meta': 'Popular  |  Categories  |  Search  |  Favs',
        'overview': 'Play Framic window views. Browse popular scenes and categories, search, and save favourites.',
        'art': ambient_art,
    },
    {
        'key': 'chat',
        'caption': 'CHAT',
        'title': 'Chat',
        'meta': 'Nickname  |  Room  |  Who is here',
        'overview': 'Chat with other people using Colossus. Pick a nickname, then type. New messages show up on their own.',
        'art': chat_art,
    },
)


def open_misc():
    window = MiscHubWindow()
    window.show()
    window.focus_first()
    window.doModal()
    del window


class MiscHubWindow(ColossusFullWindow):
    def __init__(self):
        super(MiscHubWindow, self).__init__('')
        self.option_images = {}
        self.option_buttons = {}
        self.option_captions = {}
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.focus_first()

    def onInit(self):
        super(MiscHubWindow, self).onInit()
        self.focus_first()

    def focus_first(self):
        button = self.option_buttons.get('documentaries')
        if button is None:
            return
        try:
            self.setFocus(button)
        except Exception:
            pass
        self.update_preview()

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]MISC[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 14, 6, 30)
        self.status_label = pyxbmct.Label(
            'Choose Documentaries, Webcams, Ambient, or Chat.',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 46, 6, 50)
        self.poster = pyxbmct.Image(documentaries_art(focused=True), aspectRatio=0)
        self.placeControl(self.poster, 12, 3, 16, 16)
        self.title_label = pyxbmct.Label(
            '[B]Documentaries[/B]',
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.title_label, 12, 22, 8, 74)
        self.meta_label = pyxbmct.Label(
            HUB_OPTIONS[0]['meta'],
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.meta_label, 20, 22, 5, 74)
        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 26, 22, 10, 74)
        self.overview_box.setText(HUB_OPTIONS[0]['overview'])
        layouts = ((40, 5), (40, 28), (40, 51), (40, 74))
        for option, (row, column) in zip(HUB_OPTIONS, layouts):
            art = option['art'](focused=(option['key'] == 'documentaries'))
            image = pyxbmct.Image(art, aspectRatio=0)
            self.option_images[option['key']] = image
            self.placeControl(image, row, column, 40, 22, pad_x=0, pad_y=0)
            button = pyxbmct.Button('', noFocusTexture='', focusTexture='')
            self.option_buttons[option['key']] = button
            self.placeControl(button, row, column, 40, 22, pad_x=0, pad_y=0)
            self.connect(button, (lambda current=option: self.open_option(current)))
            caption = pyxbmct.Label(
                '[COLOR aqua][B]%s[/B][/COLOR]' % option['caption'] if option['key'] == 'documentaries' else '[B]%s[/B]' % option['caption'],
                font='font13',
                textColor='0xFFFFFFFF',
                alignment=pyxbmct.ALIGN_CENTER,
            )
            self.option_captions[option['key']] = caption
            self.placeControl(caption, 80, column, 6, 22)

    def set_navigation(self):
        docs = self.option_buttons['documentaries']
        cams = self.option_buttons['webcams']
        ambient = self.option_buttons['ambient']
        chat = self.option_buttons['chat']
        self.back_button.controlDown(docs)
        self.back_button.controlRight(docs)
        docs.controlUp(self.back_button)
        docs.controlRight(cams)
        cams.controlUp(self.back_button)
        cams.controlLeft(docs)
        cams.controlRight(ambient)
        ambient.controlUp(self.back_button)
        ambient.controlLeft(cams)
        ambient.controlRight(chat)
        chat.controlUp(self.back_button)
        chat.controlLeft(ambient)

    def onAction(self, action):
        super(MiscHubWindow, self).onAction(action)
        self.update_preview()

    def update_preview(self):
        try:
            focused = self.getFocus()
        except Exception:
            return
        current = HUB_OPTIONS[0]
        for option in HUB_OPTIONS:
            caption = self.option_captions[option['key']]
            is_focused = focused == self.option_buttons[option['key']]
            if is_focused:
                current = option
                caption.setLabel('[COLOR aqua][B]%s[/B][/COLOR]' % option['caption'])
            else:
                caption.setLabel('[B]%s[/B]' % option['caption'])
            try:
                self.option_images[option['key']].setImage(option['art'](focused=is_focused))
            except Exception:
                pass
        try:
            self.poster.setImage(current['art'](focused=True))
        except Exception:
            pass
        self.title_label.setLabel('[B]%s[/B]' % current['title'])
        self.meta_label.setLabel(current['meta'])
        self.overview_box.setText(current['overview'])

    def open_option(self, option):
        key = option.get('key')
        if key == 'webcams':
            from resources.lib.gui.webcams import open_webcams
            open_webcams()
            return
        if key == 'ambient':
            from resources.lib.gui.ambient import open_ambient
            open_ambient()
            return
        if key == 'chat':
            from resources.lib.gui.chat import open_chat
            open_chat()
            return
        from resources.lib.gui.documentaries import open_documentaries
        open_documentaries()
