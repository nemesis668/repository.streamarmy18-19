from __future__ import absolute_import

import json
import os
import threading
import time

import pyxbmct
import xbmc

from resources.lib.core import paths
from resources.lib.gui import dialogs
from resources.lib.gui.buttons import text_button
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.sources.chat import api
from resources.lib.sources.chat.api import ChatError


PROFILE = os.path.join(paths.PROFILE_PATH, 'chat.json')


def _load_profile():
    try:
        with open(PROFILE, 'r', encoding='utf-8') as handle:
            data = json.loads(handle.read() or '{}')
    except Exception:
        data = {}
    return {
        'token': str(data.get('token') or ''),
        'nick': str(data.get('nick') or ''),
    }


def _save_profile(token, nick):
    try:
        folder = os.path.dirname(PROFILE)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(PROFILE, 'w', encoding='utf-8') as handle:
            json.dump({'token': token or '', 'nick': nick or ''}, handle)
    except Exception:
        pass


def _ask(heading, hidden=False):
    keyboard = xbmc.Keyboard('', heading, hidden)
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return None
    return keyboard.getText() or ''


def open_chat():
    window = ChatWindow()
    window.doModal()
    window.stop()
    del window


class ChatWindow(ColossusFullWindow):
    def __init__(self):
        super(ChatWindow, self).__init__('')
        saved = _load_profile()
        self.token = saved['token']
        self.nick = saved['nick']
        self.since = 0
        self.generation = None
        self.lines = []
        self.people = []
        self._stop = False
        self._joined = False
        self._lock = threading.Lock()
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self._thread = threading.Thread(target=self._poll)
        self._thread.daemon = True
        self._thread.start()
        try:
            self.setFocus(self.type_button)
        except Exception:
            pass

    def stop(self):
        self._stop = True

    def close(self):
        self._stop = True
        super(ChatWindow, self).close()

    def onInit(self):
        super(ChatWindow, self).onInit()
        if self._joined:
            return
        self._joined = True
        self._enter()

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 12)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]CHAT[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 16, 6, 24)
        self.status_label = pyxbmct.Label(
            'Choose a nickname to join the room.',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 42, 6, 56)
        self.log_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.log_box, 12, 3, 64, 70)
        self.log_box.setText('Joining the room...')
        self._quiet(self.log_box)
        self.people_label = pyxbmct.Label(
            '[B]WHO IS HERE[/B]',
            font='font12',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.people_label, 12, 76, 5, 22)
        self.people_box = pyxbmct.TextBox(font='font12', textColor='0xFFD0D6DE')
        self.placeControl(self.people_box, 18, 76, 58, 22)
        self.people_box.setText('')
        self._quiet(self.people_box)
        self.type_button = text_button('Type')
        self.placeControl(self.type_button, 80, 3, 8, 22)
        self.connect(self.type_button, self.type_message)
        self.nick_button = text_button('Nickname')
        self.placeControl(self.nick_button, 80, 28, 8, 22)
        self.connect(self.nick_button, self.change_nick)

    def set_navigation(self):
        self.back_button.controlDown(self.type_button)
        self.back_button.controlRight(self.type_button)
        self.type_button.controlUp(self.back_button)
        self.type_button.controlRight(self.nick_button)
        self.nick_button.controlUp(self.back_button)
        self.nick_button.controlLeft(self.type_button)

    def _quiet(self, control):
        try:
            control.setEnabled(False)
        except Exception:
            pass

    def _enter(self):
        data, error = self._hello(self.token, '', '')
        if data and data.get('ok') and data.get('nick'):
            self._accept(data)
            return
        self._choose_nick()

    def _choose_nick(self):
        while not self._stop:
            typed = _ask('Choose a nickname')
            if typed is None:
                self._set_status('Choose a nickname to join the room.')
                return
            nick = ' '.join(typed.split())
            if not nick:
                continue
            data, error = self._hello(self.token, nick, '')
            if error:
                dialogs.ok(paths.ADDON_NAME, error)
                continue
            if data.get('need_password'):
                secret = _ask('Password for that name', hidden=True)
                if secret is None:
                    continue
                data, error = self._hello(self.token, nick, secret)
                if error:
                    dialogs.ok(paths.ADDON_NAME, error)
                    continue
                if data.get('need_password'):
                    continue
            if data.get('ok'):
                self._accept(data)
                return
            dialogs.ok(paths.ADDON_NAME, data.get('error') or 'That name was not accepted.')

    def _hello(self, token, nick, password):
        try:
            data = api.hello(token, nick, password) or {}
        except ChatError as exc:
            return {}, str(exc)
        return data, ''

    def _accept(self, data):
        self.token = data.get('token') or self.token
        self.nick = data.get('nick') or self.nick
        _save_profile(self.token, self.nick)
        self._take(data, replace=True)

    def change_nick(self):
        self._choose_nick()

    def type_message(self):
        if not self.nick or not self.token:
            self._choose_nick()
            if not self.nick:
                return
        typed = _ask('Message')
        if typed is None:
            return
        text = ' '.join(typed.split())
        if not text:
            return
        try:
            data = api.send(self.token, text) or {}
        except ChatError as exc:
            dialogs.ok(paths.ADDON_NAME, str(exc))
            return
        if not data.get('ok'):
            dialogs.ok(paths.ADDON_NAME, data.get('error') or 'Message was not sent.')
            return
        self._take(data, replace=False)

    def _poll(self):
        while not self._stop:
            if not self.token or not self.nick:
                if self._stop:
                    return
                xbmc.sleep(400)
                continue
            try:
                data = api.sync(self.token, self.since) or {}
            except ChatError:
                if self._stop:
                    return
                xbmc.sleep(2000)
                continue
            if self._stop:
                return
            if not data.get('ok'):
                xbmc.sleep(1500)
                continue
            self._take(data, replace=False)

    def _take(self, data, replace):
        data = data or {}
        messages = data.get('messages') or []
        users = data.get('users') or []
        with self._lock:
            try:
                generation = int(data.get('generation') or 0)
            except (TypeError, ValueError):
                generation = 0
            if replace or (generation and self.generation and generation != self.generation):
                self.lines = []
                self.since = 0
            if generation:
                self.generation = generation
            removed = set()
            for item in data.get('removed') or []:
                try:
                    removed.add(int(item))
                except (TypeError, ValueError):
                    continue
            if removed:
                self.lines = [item for item in self.lines if item['id'] not in removed]
            known = set(item['id'] for item in self.lines)
            for item in messages or []:
                try:
                    number = int(item.get('id') or 0)
                except (TypeError, ValueError):
                    continue
                if number < 1 or number in known:
                    continue
                known.add(number)
                self.lines.append({
                    'id': number,
                    'nick': item.get('nick') or '',
                    'text': item.get('text') or '',
                    'ts': int(item.get('ts') or 0),
                })
                if number > self.since:
                    self.since = number
            self.lines = self.lines[-80:]
            self.people = [str(name) for name in (users or []) if name]
            lines = list(self.lines)
            people = list(self.people)
            nick = self.nick
        self._draw(lines, people, nick)

    def _draw(self, lines, people, nick):
        if lines:
            rows = []
            for item in reversed(lines):
                stamp = time.strftime('%H:%M', time.localtime(item['ts'] or time.time()))
                speaker = item['nick'] or 'Someone'
                body = '%s  %s: %s' % (stamp, speaker, item['text'])
                if speaker == nick:
                    body = '[COLOR aqua]%s[/COLOR]' % body
                rows.append(body)
            log = '\n'.join(rows)
        else:
            log = 'The room is quiet. Press Type to say hello.'
        here = []
        for name in people:
            if name == nick:
                here.append('[COLOR aqua]%s[/COLOR]' % name)
            else:
                here.append(name)
        people_text = '\n'.join(here) if here else 'Just you for now.'
        count = len(people) or (1 if nick else 0)
        if nick:
            status = 'You are %s  |  %s here' % (nick, count)
        else:
            status = 'Choose a nickname to join the room.'
        try:
            self.log_box.setText(log)
            self.people_box.setText(people_text)
            self.status_label.setLabel(status)
        except Exception:
            pass
