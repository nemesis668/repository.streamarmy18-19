from __future__ import absolute_import

import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pyxbmct
import xbmc

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.buttons import text_button
from resources.lib.sources.ambient import api
from resources.lib.sources.ambient.api import AmbientError


FAVS_PATH = os.path.join(paths.PROFILE_PATH, 'ambient_favs.json')

ACTIONS = (
    {'id': 'popular', 'label': 'Popular'},
    {'id': 'latest', 'label': 'Latest'},
    {'id': 'categories', 'label': 'Categories'},
    {'id': 'search', 'label': 'Search'},
    {'id': 'favs', 'label': 'Favs'},
)


def _load_message(mode):
    return {
        'popular': 'Loading popular scenes...',
        'latest': 'Loading the latest scenes...',
        'categories': 'Loading categories...',
        'category': 'Loading that category...',
        'search': 'Searching scenes...',
    }.get(mode or '', 'Loading scenes...')


def _plain(text):
    return ' '.join((text or '').replace('[CR]', ' ').split())


def _art(path):
    text = (path or '').strip()
    if text.startswith('//'):
        text = 'https:' + text
    if text.lower().startswith('http://') or text.lower().startswith('https://'):
        return text
    if text and os.path.exists(text):
        return text
    if os.path.exists(paths.AMBIENT_PATH):
        return paths.AMBIENT_PATH
    return paths.ICON_PATH


def _load_favs():
    try:
        if not os.path.exists(FAVS_PATH):
            return []
        with open(FAVS_PATH, 'r', encoding='utf-8') as handle:
            raw = json.load(handle)
    except Exception:
        return []
    if not isinstance(raw, list):
        return []
    kept = []
    seen = set()
    for row in raw:
        if not isinstance(row, dict):
            continue
        video_id = str(row.get('id') or row.get('url') or '').strip()
        if not video_id or video_id in seen:
            continue
        seen.add(video_id)
        kept.append({
            'kind': 'video',
            'id': video_id,
            'title': row.get('title') or 'Scene',
            'meta': row.get('meta') or '',
            'overview': row.get('overview') or 'Select this scene, choose a quality, then play it.',
            'image': row.get('image') or '',
            'url': video_id,
        })
    return kept


def _save_favs(items):
    try:
        folder = os.path.dirname(FAVS_PATH)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        payload = []
        for item in items or []:
            video_id = str(item.get('id') or '').strip()
            if not video_id:
                continue
            payload.append({
                'id': video_id,
                'title': item.get('title') or 'Scene',
                'meta': item.get('meta') or '',
                'overview': item.get('overview') or '',
                'image': item.get('image') or '',
                'url': video_id,
            })
        with open(FAVS_PATH, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle)
    except Exception:
        pass


def open_ambient():
    window = AmbientWindow()
    window.doModal()
    del window


class AmbientWindow(ColossusFullWindow):
    def __init__(self):
        super(AmbientWindow, self).__init__('')
        self.items = []
        self.favs = _load_favs()
        self.current_index = -1
        self.mode = 'popular'
        self.page = 1
        self.query = ''
        self.category = ''
        self.list_name = 'SCENES'
        self.action_buttons = []
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.load_mode('popular')
        try:
            self.setFocus(self.results_list)
        except Exception:
            if self.action_buttons:
                self.setFocus(self.action_buttons[0])

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 12)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]AMBIENT[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 16, 6, 40)
        self.status_label = pyxbmct.Label(
            '',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 58, 6, 38)
        self.poster = pyxbmct.Image(_art(paths.AMBIENT_PATH), aspectRatio=0)
        self.placeControl(self.poster, 10, 3, 18, 20)
        self.title_label = pyxbmct.Label(
            '[B]Ambient[/B]',
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.title_label, 10, 26, 8, 38)
        self.meta_label = pyxbmct.Label(
            'Popular  |  Categories  |  Search  |  Favs',
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.meta_label, 18, 26, 5, 38)
        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 24, 26, 12, 38)
        self.overview_box.setText(
            'Framic window views. Pick a scene, choose a quality, then play it.'
        )
        row = 30
        for action in ACTIONS:
            button = text_button(action.get('label') or 'Open')
            self.placeControl(button, row, 2, 6, 22)
            mode = action.get('id') or 'popular'
            self.connect(button, (lambda current=mode: self.load_mode(current)))
            self.action_buttons.append(button)
            row += 7
        self.fav_button = text_button('Favourite')
        self.placeControl(self.fav_button, row, 2, 6, 22)
        self.connect(self.fav_button, self.toggle_favourite)
        self.list_heading = pyxbmct.Label(
            '[B]SCENES[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)

    def set_navigation(self):
        controls = list(self.action_buttons) + [self.fav_button]
        first = controls[0]
        last = controls[-1]
        self.back_button.controlDown(first)
        self.back_button.controlRight(first)
        first.controlUp(self.back_button)
        first.controlLeft(self.back_button)
        for index, control in enumerate(controls):
            control.controlRight(self.results_list)
            control.controlLeft(self.back_button)
            if index > 0:
                control.controlUp(controls[index - 1])
            if index < len(controls) - 1:
                control.controlDown(controls[index + 1])
            else:
                control.controlDown(self.results_list)
        self.results_list.controlLeft(last)
        self.results_list.controlUp(last)

    def onAction(self, action):
        super(AmbientWindow, self).onAction(action)
        self.update_preview()

    def load_mode(self, mode, page=1, query='', category=''):
        if mode == 'search' and not query:
            keyboard = xbmc.Keyboard('', 'Search scenes')
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = (keyboard.getText() or '').strip()
            if not query:
                return
        self.mode = mode
        self.page = page
        self.query = query
        self.category = category
        if mode == 'favs':
            self.favs = _load_favs()
            self._show_items(self.favs, 'FAVS', 'scenes')
            return
        result = _with_progress(
            lambda on_progress: api.browse({
                'mode': mode,
                'page': page,
                'query': query,
                'category': category,
            }, on_progress),
            _load_message(mode),
        )
        if result is None or result.get('cancelled'):
            return
        noun = 'categories' if mode == 'categories' else 'scenes'
        self._show_items(result.get('items') or [], result.get('heading') or mode.upper(), noun)

    def _show_items(self, items, heading, noun):
        self.items = items or []
        self.list_name = heading or 'SCENES'
        try:
            self.list_heading.setLabel('[B]%s[/B]' % self.list_name)
        except Exception:
            pass
        self.results_list.reset()
        self.current_index = -1
        if not self.items:
            self.results_list.addItem('Nothing found')
            if self.mode == 'favs':
                self.status_label.setLabel('No favourites yet.')
                self.title_label.setLabel('[B]No favourites yet[/B]')
                self.overview_box.setText('Highlight a scene and choose Favourite to save it.')
            else:
                self.status_label.setLabel('Nothing found.')
                self.title_label.setLabel('[B]Nothing found[/B]')
                self.overview_box.setText('Try another category or search.')
            self.meta_label.setLabel('')
            self._refresh_fav_button(None)
            return
        for item in self.items:
            self.results_list.addItem(_plain(item.get('title') or ''))
        self.status_label.setLabel('%s %s  |  Select one.' % (len(self.items), noun))
        self.update_preview(force=True)
        try:
            self.setFocus(self.results_list)
        except Exception:
            pass

    def _current(self):
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return None
        if index < 0 or index >= len(self.items):
            return None
        return self.items[index]

    def _is_fav(self, item):
        video_id = str((item or {}).get('id') or '').strip()
        if not video_id:
            return False
        return any(str(row.get('id') or '') == video_id for row in self.favs)

    def update_preview(self, force=False):
        item = self._current()
        if item is None:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if not force and index == self.current_index:
            self._refresh_fav_button(item)
            return
        self.current_index = index
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or ''))
        self.meta_label.setLabel(item.get('meta') or '')
        self.overview_box.setText(item.get('overview') or '')
        try:
            self.poster.setImage(_art(item.get('image')))
        except Exception:
            pass
        self._refresh_fav_button(item)

    def _refresh_fav_button(self, item):
        if item and item.get('kind') == 'video' and self._is_fav(item):
            self.fav_button.setLabel('Unfavourite')
        else:
            self.fav_button.setLabel('Favourite')

    def toggle_favourite(self):
        item = self._current()
        if not item or item.get('kind') != 'video' or not item.get('id'):
            dialogs.ok(paths.ADDON_NAME, 'Highlight a scene, then save it.')
            return
        video_id = str(item.get('id') or '')
        self.favs = _load_favs()
        if self._is_fav(item):
            self.favs = [row for row in self.favs if str(row.get('id') or '') != video_id]
            _save_favs(self.favs)
            self._refresh_fav_button(item)
            if self.mode == 'favs':
                self._show_items(self.favs, 'FAVS', 'scenes')
            return
        self.favs.append({
            'kind': 'video',
            'id': video_id,
            'title': item.get('title') or 'Scene',
            'meta': item.get('meta') or '',
            'overview': item.get('overview') or '',
            'image': item.get('image') or '',
            'url': video_id,
        })
        _save_favs(self.favs)
        self._refresh_fav_button(item)

    def select_current(self):
        item = self._current()
        if item is None:
            return
        kind = item.get('kind') or ''
        if kind == 'page':
            self.load_mode(
                item.get('mode') or self.mode,
                page=int(item.get('page') or 1),
                query=item.get('query') or '',
                category=item.get('category') or '',
            )
            return
        if kind == 'category':
            self.load_mode('category', category=item.get('category') or item.get('id') or '')
            return
        if kind == 'video':
            _play_item(item)


def _with_progress(func, message):
    holder = {
        'data': None,
        'error': None,
        'done': False,
        'cancel': False,
        'percent': 8,
        'text': message or 'Loading scenes...',
    }

    def on_progress(percent, text):
        try:
            holder['percent'] = max(int(holder.get('percent') or 0), int(percent or 0))
        except (TypeError, ValueError):
            pass
        if text:
            holder['text'] = text
        return bool(holder.get('cancel'))

    def work():
        try:
            holder['data'] = func(on_progress)
        except Exception as exc:
            holder['error'] = exc
        finally:
            holder['done'] = True

    threading.Thread(target=work, daemon=True).start()
    progress = dialogs.Progress()
    started = time.time()
    progress.create(paths.ADDON_NAME, holder['text'])
    shown = None
    while not holder['done']:
        if progress.iscanceled():
            holder['cancel'] = True
            try:
                progress.close()
            except Exception:
                pass
            return None
        elapsed = max(0, int(time.time() - started))
        percent = min(92, int(holder.get('percent') or 8) + min(6, elapsed))
        text = holder.get('text') or message or 'Loading scenes...'
        if elapsed >= 1:
            unit = 'second' if elapsed == 1 else 'seconds'
            text = '%s  |  %s %s' % (text, elapsed, unit)
        key = (percent, text)
        if key != shown:
            shown = key
            progress.update(percent, text)
        xbmc.sleep(200)
    try:
        progress.update(100, 'Ready.')
        progress.close()
    except Exception:
        pass
    if holder.get('cancel'):
        return None
    if holder.get('error') is not None:
        dialogs.ok(paths.ADDON_NAME, 'Could not load that list.\n%s' % holder['error'])
        return None
    return holder.get('data') or {}


def _play_item(item):
    result = _with_progress(
        lambda on_progress: api.resolve(item.get('id') or item.get('url') or '', on_progress),
        'Opening the scene...',
    )
    if result is None or result.get('cancelled'):
        return
    streams = result.get('streams') or []
    if not streams:
        dialogs.ok(paths.ADDON_NAME, 'No playable quality on that scene.')
        return
    stream = streams[0]
    if len(streams) > 1:
        choice = dialogs.select(
            'Choose a quality',
            [row.get('label') or 'Play' for row in streams],
        )
        if choice < 0 or choice >= len(streams):
            return
        stream = streams[choice]
    title = item.get('title') or 'Ambient'
    playlist = stream.get('hls') or ''
    if playlist:
        player.play_stream(
            title,
            _serve_hls(playlist),
            stream.get('headers') or {},
            passthrough=True,
        )
        return
    player.play_stream(
        title,
        stream.get('url') or '',
        stream.get('headers') or {},
        passthrough=True,
        adaptive=False,
    )


class _Playlist(object):
    def __init__(self):
        self.body = b''
        self.httpd = None
        self.thread = None

    def url(self, text):
        self.body = (text or '').encode('utf-8')
        if self.httpd is None:
            owner = self

            class _Handler(BaseHTTPRequestHandler):
                def do_GET(self):
                    data = owner.body
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    self.wfile.write(data)

                def log_message(self, fmt, *args):
                    return

            self.httpd = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
            self.thread = threading.Thread(target=self.httpd.serve_forever)
            self.thread.daemon = True
            self.thread.start()
        return 'http://127.0.0.1:%s/play.m3u8' % self.httpd.server_address[1]


_PLAYLIST = _Playlist()


def _serve_hls(text):
    return _PLAYLIST.url(text)
