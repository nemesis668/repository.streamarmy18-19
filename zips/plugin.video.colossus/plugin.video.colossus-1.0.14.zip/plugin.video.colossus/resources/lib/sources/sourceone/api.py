from __future__ import absolute_import

from resources.lib.core.remote import RemoteError, call


def _run(name, **kwargs):
    try:
        return call('sourceone', name, [], kwargs)
    except RemoteError as exc:
        raise RuntimeError(str(exc))


def categories(kind, offset=0):
    return _run('categories', kind=kind, offset=offset)


def events(kind, category='All', offset=0):
    return _run('events', kind=kind, category=category, offset=offset)


def live_events(offset=0):
    return _run('live_events', offset=offset)


def streams(source, source_id):
    return _run('streams', source=source, source_id=source_id)


def resolve(embed_url='', stream_key='', stream_title='', stream_no='1'):
    return _run(
        'resolve',
        embed_url=embed_url,
        stream_key=stream_key,
        stream_title=stream_title,
        stream_no=stream_no,
    )
