from __future__ import absolute_import

import os
import threading

import pyxbmct
import xbmc
import xbmcgui

from resources.lib.core import debrid
from resources.lib.core import paths
from resources.lib.core import prowlarr
from resources.lib.core import tmdb
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.buttons import text_button
from resources.lib.gui import medialists


def panel_texture():
    if os.path.exists(paths.FRAME_PATH):
        return paths.FRAME_PATH
    return os.path.join(
        os.path.dirname(pyxbmct.__file__),
        'textures',
        'estuary',
        'AddonWindow',
        'ContentPanel.png'
    )


def dialog_background_texture():
    if os.path.exists(paths.DIALOG_BG_PATH):
        return paths.DIALOG_BG_PATH
    if os.path.exists(paths.BACKDROP_PATH):
        return paths.BACKDROP_PATH
    return panel_texture()


def truncate(text, limit):
    text = text or ''
    return text if len(text) <= limit else text[:limit - 3] + '...'


class ColossusDialog(pyxbmct.BlankDialogWindow):
    def __init__(self):
        super(ColossusDialog, self).__init__()
        self.setGeometry(1050, 650, 100, 100)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self._focus = None
        self._open = False

    def _apply_focus(self):
        control = self._focus
        if control is None:
            return
        try:
            self.setFocus(control)
        except Exception:
            pass
        try:
            xbmc.executebuiltin('SetFocus(%d)' % control.getId())
        except Exception:
            pass

    def _pump_focus(self):
        for _ in range(15):
            if not self._open:
                return
            xbmc.sleep(40)
            if not self._open:
                return
            self._apply_focus()

    def doModal(self):
        self._open = True
        threading.Thread(target=self._pump_focus).start()
        try:
            super(ColossusDialog, self).doModal()
        finally:
            self._open = False

    def close(self):
        self._open = False
        super(ColossusDialog, self).close()

    def add_panel(self):
        self.panel_background = pyxbmct.Image(dialog_background_texture())
        self.placeControl(self.panel_background, 0, 0, 100, 100, pad_x=0, pad_y=0)
        try:
            self.panel_background.setColorDiffuse(paths.DIALOG_BG_DIFFUSE)
        except Exception:
            pass
        try:
            self.panel_background.setEnabled(False)
        except Exception:
            pass
        if os.path.exists(paths.DIALOG_FRAME_PATH):
            self.panel_frame = pyxbmct.Image(paths.DIALOG_FRAME_PATH)
            self.placeControl(self.panel_frame, 0, 0, 100, 100, pad_x=0, pad_y=0)
            try:
                self.panel_frame.setEnabled(False)
            except Exception:
                pass

    def add_header(self, title, subtitle=''):
        self.title_label = pyxbmct.Label('[B]%s[/B]' % title, alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.title_label, 3, 8, 7, 84)
        self.status_label = pyxbmct.Label(subtitle, alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.status_label, 11, 8, 7, 84)


class MoviesWindow(ColossusFullWindow):
    def __init__(self, heading=None, genre_id=None):
        super(MoviesWindow, self).__init__('')
        self.window_heading = heading or 'MOVIES & SHOWS'
        self.genre_id = genre_id
        self.tmdb_results = []
        self.current_index = -1
        self.page_number = 1
        self.total_pages = 1
        self.query = ''
        self.browse_mode = None
        self.browse_genre_id = None
        self.browse_genre_name = ''
        self.library_view = ''
        self.playlist_name = ''
        self.saved_items = []
        self.column_buttons = []
        self.prev_button = None
        self.next_button = None
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        if self.genre_id:
            self.load_page(1)
            self.setFocus(self.results_list if self.tmdb_results else self.search_button)
        else:
            self.setFocus(self.search_button)

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)

        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)

        self.header_label = pyxbmct.Label(
            '[B]%s[/B]' % self.window_heading,
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.header_label, 2, 14, 6, 50)

        if self.genre_id:
            status_text = 'Browse TMDB musical movies, then select one to open the movie page.'
            empty_title = 'Musical Movies'
            empty_meta = 'TMDB Music / Musical genre'
            empty_overview = (
                'These films are tagged as Music on TMDB. Highlight one to preview it, '
                'then select it to open the same movie page used in Movies & Shows.'
            )
            search_label = 'Search movie'
            list_heading = 'MUSICALS'
        else:
            status_text = 'Search, or browse movies and shows.'
            empty_title = 'Movies & Shows'
            empty_meta = 'Search or browse'
            empty_overview = (
                'Use Popular, Top Rated, or Trending, or open Movie Genres. '
                'On a title, Favourite or Add to playlist. Favs and Playlists open them again. '
                'Playlists can rename or delete a whole list. '
                'A saved show can continue the last episode, or play the next one.'
            )
            search_label = 'Search'
            list_heading = 'RESULTS'

        self.status_label = pyxbmct.Label(
            status_text,
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.status_label, 2, 64, 6, 32)

        self.poster = pyxbmct.Image(paths.ICON_PATH, aspectRatio=2)
        if self.genre_id:
            self.placeControl(self.poster, 12, 3, 56, 20)
        else:
            self.placeControl(self.poster, 10, 3, 16, 16)

        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % empty_title,
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.title_label, 10, 24, 10, 40)

        self.meta_label = pyxbmct.Label(
            empty_meta,
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.meta_label, 20, 24, 6, 40)

        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 28, 26, 30, 38)
        self.overview_box.setText(empty_overview)

        self.search_button = text_button(search_label)
        self.resolveurl_button = text_button('ResolveURL')

        if self.genre_id:
            self.placeControl(self.search_button, 66, 1, 8, 28)
            self.connect(self.search_button, self.search)
            self.placeControl(self.resolveurl_button, 66, 31, 8, 24)
            self.connect(self.resolveurl_button, self.open_resolveurl_settings)
            self.prev_button = text_button('Previous')
            self.placeControl(self.prev_button, 76, 1, 8, 28)
            self.connect(self.prev_button, self.go_previous)
            self.next_button = text_button('Next page')
            self.placeControl(self.next_button, 86, 1, 8, 28)
            self.connect(self.next_button, self.go_next)
        else:
            self.favs_button = text_button('Favs')
            self.playlists_button = text_button('Playlists')
            specs = (
                (self.favs_button, self.show_favs),
                (self.playlists_button, self.open_playlists),
                (self.search_button, self.search),
                (text_button('Movie Genres'), self.open_movie_genres),
                (text_button('Popular Movies'), lambda: self.open_browse('movie_popular')),
                (text_button('Top Rated Movies'), lambda: self.open_browse('movie_top')),
                (text_button('Trending Movies'), lambda: self.open_browse('movie_trending')),
                (text_button('Popular Shows'), lambda: self.open_browse('tv_popular')),
                (text_button('Top Rated Shows'), lambda: self.open_browse('tv_top')),
                (text_button('Trending Shows'), lambda: self.open_browse('tv_trending')),
                (self.resolveurl_button, self.open_resolveurl_settings),
            )
            row = 26
            for button, action in specs:
                self.placeControl(button, row, 2, 6, 22)
                if action is not None:
                    self.connect(button, action)
                self.column_buttons.append(button)
                row += 6
            self.prev_button = text_button('Previous')
            self.placeControl(self.prev_button, 86, 64, 8, 16)
            self.connect(self.prev_button, self.go_previous)
            self.next_button = text_button('Next page')
            self.placeControl(self.next_button, 86, 81, 8, 17)
            self.connect(self.next_button, self.go_next)

        self.list_heading = pyxbmct.Label(
            '[B]%s[/B]' % list_heading,
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)

        self.results_list = pyxbmct.List()
        list_height = 78 if self.genre_id else 70
        self.placeControl(self.results_list, 14, 66, list_height, 32)
        self.connect(self.results_list, self.handle_selected)

    def set_navigation(self):
        if self.genre_id:
            self.back_button.controlRight(self.search_button)
            self.back_button.controlDown(self.search_button)
            self.search_button.controlUp(self.back_button)
            self.search_button.controlLeft(self.back_button)
            self.search_button.controlRight(self.resolveurl_button)
            self.search_button.controlDown(self.prev_button)
            self.resolveurl_button.controlUp(self.back_button)
            self.resolveurl_button.controlLeft(self.search_button)
            self.resolveurl_button.controlRight(self.results_list)
            self.resolveurl_button.controlDown(self.prev_button)
            self.prev_button.controlUp(self.search_button)
            self.prev_button.controlDown(self.next_button)
            self.prev_button.controlRight(self.results_list)
            self.next_button.controlUp(self.prev_button)
            self.next_button.controlRight(self.results_list)
            self.results_list.controlLeft(self.search_button)
            self.results_list.controlUp(self.search_button)
            return

        buttons = self.column_buttons
        self.back_button.controlRight(buttons[0])
        self.back_button.controlDown(buttons[0])
        for index, button in enumerate(buttons):
            if index == 0:
                button.controlUp(self.back_button)
                button.controlLeft(self.back_button)
            else:
                button.controlUp(buttons[index - 1])
                button.controlLeft(buttons[index - 1])
            if index + 1 < len(buttons):
                button.controlDown(buttons[index + 1])
            else:
                button.controlDown(self.prev_button)
            button.controlRight(self.results_list)
        self.results_list.controlLeft(buttons[0])
        self.results_list.controlUp(buttons[0])
        self.results_list.controlDown(self.prev_button)
        self.prev_button.controlUp(buttons[-1])
        self.prev_button.controlLeft(buttons[-1])
        self.prev_button.controlRight(self.next_button)
        self.next_button.controlLeft(self.prev_button)
        self.next_button.controlUp(buttons[-1])
        self.next_button.controlRight(self.results_list)

    def onAction(self, action):
        super(MoviesWindow, self).onAction(action)
        self.update_preview()

    def search(self):
        query = self.get_query()
        if query is None:
            return
        self.query = query
        self.page_number = 1
        if self.genre_id:
            self.load_page(1)
            return
        if not query:
            return
        self.library_view = ''
        self.playlist_name = ''
        self.saved_items = []
        self._sync_page_buttons()
        self.browse_mode = 'search'
        self.browse_genre_id = None
        self.browse_genre_name = ''
        self.fetch_current_page()

    def open_browse(self, mode):
        self.library_view = ''
        self.playlist_name = ''
        self.saved_items = []
        self._sync_page_buttons()
        self.browse_mode = mode
        self.browse_genre_id = None
        self.browse_genre_name = ''
        self.query = ''
        self.page_number = 1
        self.fetch_current_page()

    def open_movie_genres(self):
        try:
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            genres = tmdb.movie_genres()
        except Exception as error:
            self.show_error('Could not load genres: %s' % error)
            return
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        if not genres:
            self.show_error('No movie genres found.')
            return
        index = dialogs.select('Movie Genres', [genre['name'] for genre in genres])
        if index < 0:
            return
        chosen = genres[index]
        self.browse_mode = 'movie_genre'
        self.browse_genre_id = chosen['id']
        self.browse_genre_name = chosen['name']
        self.query = ''
        self.page_number = 1
        self.library_view = ''
        self.playlist_name = ''
        self.saved_items = []
        self._sync_page_buttons()
        self.fetch_current_page()

    def fetch_current_page(self):
        self.tmdb_results = []
        self.current_index = -1
        self.results_list.reset()
        self.status_label.setLabel('Loading...')
        try:
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            payload, heading, empty_message = self.request_page(self.page_number)
        except Exception as error:
            self.show_error('Could not load that list: %s' % error)
            return
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        self.show_loaded_page(payload, heading, empty_message)

    def request_page(self, page):
        if self.browse_mode == 'search':
            return tmdb.search(self.query, page=page), 'SEARCH', 'No movie or show results found.'
        if self.browse_mode == 'movie_genre':
            return (
                tmdb.browse('movie_genre', page=page, genre_id=self.browse_genre_id),
                (self.browse_genre_name or 'Genre').upper(),
                'No movies found in that genre.',
            )
        labels = {
            'movie_popular': ('POPULAR MOVIES', 'No popular movies found.'),
            'movie_top': ('TOP RATED MOVIES', 'No top rated movies found.'),
            'movie_trending': ('TRENDING MOVIES', 'No trending movies found.'),
            'tv_popular': ('POPULAR SHOWS', 'No popular shows found.'),
            'tv_top': ('TOP RATED SHOWS', 'No top rated shows found.'),
            'tv_trending': ('TRENDING SHOWS', 'No trending shows found.'),
        }
        heading, empty_message = labels[self.browse_mode]
        return tmdb.browse(self.browse_mode, page=page), heading, empty_message

    def show_loaded_page(self, payload, heading, empty_message):
        self.tmdb_results = payload.get('results') or []
        self.total_pages = max(1, int(payload.get('total_pages') or 1))
        self.page_number = int(payload.get('page') or self.page_number or 1)
        self.current_index = -1
        self.results_list.reset()
        if not self.tmdb_results:
            self.list_heading.setLabel('[B]%s[/B]' % heading)
            self.show_error(empty_message)
            return
        self.list_heading.setLabel('[B]%s[/B]' % heading)
        total = int(payload.get('total_results') or len(self.tmdb_results))
        week = ''
        if self.browse_mode in ('movie_trending', 'tv_trending'):
            week = '  |  This week'
        self.status_label.setLabel(
            'Page %s of %s  |  %s titles%s' % (self.page_number, self.total_pages, total, week)
        )
        for item in self.tmdb_results:
            self.results_list.addItem(self.format_tmdb_result(item))
        self.setFocus(self.results_list)
        self.update_preview(force=True)

    def load_page(self, page):
        page = max(1, int(page or 1))
        self.page_number = page
        self.tmdb_results = []
        self.current_index = -1
        self.results_list.reset()
        self.status_label.setLabel('Loading musical movies...')
        try:
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
            if self.query:
                payload = tmdb.search_movies(self.query, genre_id=self.genre_id, page=page)
            else:
                payload = tmdb.discover_movies(self.genre_id, page=page)
        except Exception as error:
            self.show_error('TMDB error: %s' % error)
            return
        finally:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

        self.tmdb_results = payload.get('results') or []
        self.total_pages = max(1, int(payload.get('total_pages') or 1))
        self.page_number = int(payload.get('page') or page)
        if not self.tmdb_results:
            self.show_error('No musical movies found.')
            return

        self.results_list.reset()
        total = int(payload.get('total_results') or len(self.tmdb_results))
        self.status_label.setLabel(
            'Page %s of %s  |  %s films  |  Select a movie.' % (
                self.page_number,
                self.total_pages,
                total
            )
        )
        for item in self.tmdb_results:
            self.results_list.addItem(self.format_tmdb_result(item))
        self.setFocus(self.results_list)
        self.update_preview(force=True)

    def go_previous(self):
        if self.library_view == 'playlist':
            self._move_saved(-1)
            return
        if self.library_view:
            self.page_notice('Open a playlist to change the order.')
            return
        if not self.genre_id and not self.browse_mode:
            self.page_notice('Choose a list or search first.')
            return
        if self.page_number <= 1:
            self.page_notice('Already on the first page.')
            return
        if self.genre_id:
            self.load_page(self.page_number - 1)
            return
        self.page_number -= 1
        self.fetch_current_page()

    def go_next(self):
        if self.library_view == 'playlist':
            self._move_saved(1)
            return
        if self.library_view:
            self.page_notice('Open a playlist to change the order.')
            return
        if not self.genre_id and not self.browse_mode:
            self.page_notice('Choose a list or search first.')
            return
        if self.page_number >= self.total_pages:
            self.page_notice('No more pages.')
            return
        if self.genre_id:
            self.load_page(self.page_number + 1)
            return
        self.page_number += 1
        self.fetch_current_page()

    def page_notice(self, message):
        xbmcgui.Dialog().notification(paths.ADDON_NAME, message, paths.ICON_PATH, 2500)

    def handle_selected(self):
        if self.library_view:
            index = self.results_list.getSelectedPosition()
            if index < 0 or index >= len(self.saved_items):
                return
            open_media_details(self.saved_items[index])
            self._refresh_library()
            return
        index = self.results_list.getSelectedPosition()
        if index < 0 or index >= len(self.tmdb_results):
            return
        open_media_details(self.tmdb_results[index])

    def update_preview(self, force=False):
        if self.library_view:
            self._preview_saved(force)
            return
        if not self.tmdb_results:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if index < 0 or index >= len(self.tmdb_results):
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        item = self.tmdb_results[index]
        media_type = 'Movie' if item.get('media_type') == 'movie' else 'TV Show'
        year = item.get('year') or ''
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or 'Unknown'))
        self.meta_label.setLabel('   |   '.join([part for part in (media_type, year) if part]))
        self.overview_box.setText(item.get('overview') or 'No overview available from TMDB.')
        try:
            self.poster.setImage(item.get('poster') or paths.ICON_PATH)
        except Exception:
            pass
        backdrop = item.get('backdrop') or paths.BACKDROP_PATH or paths.FANART_PATH
        try:
            self.backdrop.setImage(backdrop)
        except Exception:
            pass

    def get_query(self):
        heading = 'Search movie' if self.genre_id else 'Search Movies & Shows'
        keyboard = xbmc.Keyboard(self.query if self.genre_id else '', heading)
        keyboard.doModal()
        if keyboard.isConfirmed():
            return keyboard.getText().strip()
        return None

    def open_resolveurl_settings(self):
        debrid.open_resolveurl_settings()

    def show_error(self, message):
        self.tmdb_results = []
        self.current_index = -1
        self.results_list.reset()
        self.status_label.setLabel(message)
        self.title_label.setLabel('[B]No results[/B]')
        self.meta_label.setLabel('')
        self.overview_box.setText(message)
        xbmcgui.Dialog().notification(paths.ADDON_NAME, message, paths.ICON_PATH, 3500)

    def _sync_page_buttons(self):
        if getattr(self, 'prev_button', None) is None:
            return
        if self.library_view == 'playlist':
            self.prev_button.setLabel('Move up')
            self.next_button.setLabel('Move down')
        else:
            self.prev_button.setLabel('Previous')
            self.next_button.setLabel('Next page')
        if getattr(self, 'favs_button', None) is not None:
            self.favs_button.setLabel('Browse' if self.library_view == 'favs' else 'Favs')

    def _saved_label(self, item):
        kind = 'Movie' if item.get('media_type') == 'movie' else 'TV'
        year = item.get('year') or ''
        title = item.get('title') or 'Unknown'
        progress = medialists.progress_for(item) if item.get('media_type') == 'tv' else None
        episode = ''
        if progress:
            episode = '    S%s E%s' % (progress['season'], progress['episode'])
        if year:
            return '%s    %s    %s%s' % (title, year, kind, episode)
        return '%s    %s%s' % (title, kind, episode)

    def _show_saved(self, items, heading, status):
        self.tmdb_results = []
        self.saved_items = list(items or [])
        self.current_index = -1
        self.results_list.reset()
        self.list_heading.setLabel('[B]%s[/B]' % heading)
        self._sync_page_buttons()
        if not self.saved_items:
            self.status_label.setLabel(status)
            self.title_label.setLabel('[B]%s[/B]' % heading.title())
            self.meta_label.setLabel('')
            self.overview_box.setText(status)
            self.results_list.addItem(status)
            return
        self.status_label.setLabel('%s  |  Select a title.' % status)
        for item in self.saved_items:
            self.results_list.addItem(self._saved_label(item))
        self.setFocus(self.results_list)
        self.update_preview(force=True)

    def _show_home_prompt(self):
        self.library_view = ''
        self.playlist_name = ''
        self.saved_items = []
        self.tmdb_results = []
        self.current_index = -1
        self.browse_mode = None
        self.results_list.reset()
        self.list_heading.setLabel('[B]RESULTS[/B]')
        self.status_label.setLabel('Search, or browse movies and shows.')
        self.title_label.setLabel('[B]Movies & Shows[/B]')
        self.meta_label.setLabel('Search or browse')
        self.overview_box.setText(
            'Use Popular, Top Rated, or Trending, or open Movie Genres. '
            'On a title, Favourite or Add to playlist. Favs and Playlists open them again. '
            'Playlists can rename or delete a whole list. '
            'A saved show can continue the last episode, or play the next one.'
        )
        try:
            self.poster.setImage(paths.ICON_PATH)
        except Exception:
            pass
        self._sync_page_buttons()

    def _refresh_library(self):
        if self.library_view == 'favs':
            self.show_favs(refresh=True)
        elif self.library_view == 'playlist':
            self._open_named_playlist(self.playlist_name)

    def _preview_saved(self, force=False):
        if not self.saved_items:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if index < 0 or index >= len(self.saved_items):
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        item = self.saved_items[index]
        kind = 'Movie' if item.get('media_type') == 'movie' else 'TV Show'
        year = item.get('year') or ''
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or 'Unknown'))
        self.meta_label.setLabel('   |   '.join([part for part in (kind, year) if part]))
        notes = []
        if medialists.is_favourite(item):
            notes.append('Saved in favs.')
        names = medialists.playlist_names(item)
        if names:
            notes.append('Playlists: %s.' % ', '.join(names))
        progress = medialists.progress_for(item)
        if progress:
            label = 'S%s E%s' % (progress['season'], progress['episode'])
            if progress.get('name'):
                label = '%s  %s' % (label, progress['name'])
            notes.append('Last episode started: %s.' % label)
        text = item.get('overview') or 'No overview saved.'
        if notes:
            text = text + '\n\n' + '\n'.join(notes)
        self.overview_box.setText(text)
        try:
            self.poster.setImage(item.get('poster') or paths.ICON_PATH)
        except Exception:
            pass
        backdrop = item.get('backdrop') or paths.BACKDROP_PATH or paths.FANART_PATH
        try:
            self.backdrop.setImage(backdrop)
        except Exception:
            pass

    def show_favs(self, refresh=False):
        if self.library_view == 'favs' and not refresh:
            self._show_home_prompt()
            return
        self.library_view = 'favs'
        self.playlist_name = ''
        items = medialists.load_lists().get('favs') or []
        self._show_saved(
            items,
            'FAVS',
            'No favourites yet. Open a title and press Favourite.' if not items else '%s favs' % len(items),
        )

    def _open_named_playlist(self, name):
        playlist = None
        for item in medialists.load_lists().get('playlists') or []:
            if item.get('name') == name:
                playlist = item
                break
        if playlist is None:
            self._show_home_prompt()
            medialists.notify('That playlist is gone.')
            return
        self.library_view = 'playlist'
        self.playlist_name = name
        items = playlist.get('items') or []
        self._show_saved(
            items,
            name.upper(),
            'Playlist is empty. Open a title and press Add to playlist. Playlists can rename or delete this list.' if not items else '%s in %s' % (len(items), name),
        )

    def _move_saved(self, direction):
        if self.library_view != 'playlist':
            return
        index = self.results_list.getSelectedPosition()
        if index < 0 or index >= len(self.saved_items):
            medialists.notify('Highlight a title first.')
            return
        target = index + direction
        if target < 0:
            medialists.notify('Already at the top.')
            return
        if target >= len(self.saved_items):
            medialists.notify('Already at the bottom.')
            return
        data = medialists.load_lists()
        playlist = None
        for item in data.get('playlists') or []:
            if item.get('name') == self.playlist_name:
                playlist = item
                break
        if playlist is None:
            return
        rows = list(playlist.get('items') or [])
        if index >= len(rows) or target >= len(rows):
            return
        rows[index], rows[target] = rows[target], rows[index]
        playlist['items'] = rows
        medialists.save_lists(data)
        self._open_named_playlist(self.playlist_name)
        try:
            self.results_list.selectItem(target)
        except Exception:
            pass
        self.update_preview(force=True)
        self.setFocus(self.results_list)

    def open_playlists(self):
        data = medialists.load_lists()
        playlists = data.get('playlists') or []
        options = []
        actions = []
        if self.library_view:
            options.append('Movies & Shows')
            actions.append('home')
        options.append('New playlist')
        actions.append('new')
        if playlists:
            options.append('Rename a playlist')
            actions.append('rename')
            options.append('Delete a playlist')
            actions.append('delete')
        if self.library_view == 'playlist':
            options.append('Remove highlighted')
            actions.append('remove')
        for playlist in playlists:
            count = len(playlist.get('items') or [])
            options.append('%s    (%s)' % (playlist.get('name') or 'Playlist', count))
            actions.append(('open', playlist.get('name') or ''))
        choice = dialogs.select('Playlists', options)
        if choice < 0:
            return
        action = actions[choice]
        if action == 'home':
            self._show_home_prompt()
            return
        if action == 'new':
            name = medialists._ask_name(playlists)
            if not name:
                return
            data.setdefault('playlists', []).append({'name': name, 'items': []})
            medialists.save_lists(data)
            medialists.notify('Playlist created. Open a title and press Add to playlist.')
            self._open_named_playlist(name)
            return
        if action == 'rename':
            name = self._pick_playlist('Rename a playlist')
            if not name:
                return
            new_name = medialists._ask_name(playlists, current=name, ignore=name)
            if not new_name or new_name == name:
                return
            for playlist in playlists:
                if playlist.get('name') == name:
                    playlist['name'] = new_name
                    break
            medialists.save_lists(data)
            medialists.notify('Renamed to %s.' % new_name)
            if self.library_view == 'playlist' and self.playlist_name == name:
                self._open_named_playlist(new_name)
            return
        if action == 'remove':
            self._remove_highlighted()
            return
        if action == 'delete':
            name = self._pick_playlist('Delete a playlist')
            if not name:
                return
            if not dialogs.yesno(paths.ADDON_NAME, 'Delete the playlist "%s"?' % name):
                return
            data['playlists'] = [
                playlist for playlist in playlists
                if playlist.get('name') != name
            ]
            medialists.save_lists(data)
            medialists.notify('Playlist deleted.')
            if self.library_view == 'playlist' and self.playlist_name == name:
                self._show_home_prompt()
            return
        if isinstance(action, tuple) and action[0] == 'open':
            self._open_named_playlist(action[1])

    def _pick_playlist(self, heading):
        names = []
        for playlist in medialists.load_lists().get('playlists') or []:
            label = playlist.get('name') or ''
            if label:
                names.append(label)
        if self.library_view == 'playlist' and self.playlist_name in names:
            names = [self.playlist_name] + [label for label in names if label != self.playlist_name]
        if not names:
            medialists.notify('No playlists yet.')
            return ''
        choice = dialogs.select(heading, names)
        if choice < 0:
            return ''
        return names[choice]

    def _remove_highlighted(self):
        index = self.results_list.getSelectedPosition()
        if index < 0 or index >= len(self.saved_items):
            medialists.notify('Highlight a title first.')
            return
        chosen = self.saved_items[index]
        data = medialists.load_lists()
        for playlist in data.get('playlists') or []:
            if playlist.get('name') != self.playlist_name:
                continue
            playlist['items'] = [
                item for item in (playlist.get('items') or [])
                if not medialists._same(item, chosen)
            ]
            medialists.save_lists(data)
            medialists.notify('Removed from %s.' % self.playlist_name)
            self._open_named_playlist(self.playlist_name)
            return

    def format_tmdb_result(self, item):
        media_type = 'Movie' if item.get('media_type') == 'movie' else 'TV'
        year = item.get('year') or ''
        title = item.get('title') or 'Unknown'
        if year:
            return '%s    %s    %s' % (title, year, media_type)
        return '%s    %s' % (title, media_type)


class SourceWindow(ColossusDialog):
    def __init__(self, media, episode=None):
        super(SourceWindow, self).__init__()
        self.media = media
        self.episode = episode
        self.sources = []
        self.set_controls()
        self.set_navigation()
        self.search_sources()
        self._focus = self.list_control

    def onInit(self):
        self._apply_focus()

    def set_controls(self):
        self.add_panel()
        self.add_header(self.media.get('title', 'Sources'), 'Prowlarr results sorted by quality and seeders')
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 20, 5, 62, 90)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 87, 30, 8, 18)
        self.close_button = text_button('Close')
        self.placeControl(self.close_button, 87, 55, 8, 18)
        self.connect(self.list_control, self.play_selected)
        self.connect(self.back_button, self.close)
        self.connect(self.close_button, self.close)

    def set_navigation(self):
        self.list_control.controlDown(self.back_button)
        self.list_control.controlUp(self.back_button)
        self.back_button.controlUp(self.list_control)
        self.back_button.controlRight(self.close_button)
        self.close_button.controlUp(self.list_control)
        self.close_button.controlLeft(self.back_button)

    def search_sources(self):
        query = build_prowlarr_query(self.media, self.episode)
        self.list_control.reset()
        self.list_control.addItem('Searching Prowlarr for "%s"...' % query)
        try:
            self.sources = prowlarr.search(query)
        except Exception as error:
            self.list_control.reset()
            self.list_control.addItem('Prowlarr error: %s' % error)
            return
        self.list_control.reset()
        if not self.sources:
            self.list_control.addItem('No Prowlarr results found for "%s"' % query)
            return
        for source in self.sources:
            self.list_control.addItem(format_source(source))

    def play_selected(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.sources):
            return
        source = self.sources[index]
        self.status_label.setLabel('Resolving %s...' % source.get('quality', 'source'))
        try:
            stream_url = debrid.resolve_magnet(source['magnet'])
        except Exception as error:
            self.list_control.reset()
            self.list_control.addItem('ResolveURL error: %s' % error)
            self.status_label.setLabel('ResolveURL error: %s' % error)
            return
        list_item = xbmcgui.ListItem(label=source.get('title', 'Colossus Stream'))
        list_item.setPath(stream_url)
        xbmc.Player().play(stream_url, list_item)


def load_media_details(media):
    try:
        return tmdb.details(media['media_type'], media['id'])
    except Exception:
        return media


def build_prowlarr_query(media, episode=None):
    title = media.get('title', '').strip()
    if episode:
        return '%s S%02dE%02d' % (
            title,
            int(episode.get('season_number') or 0),
            int(episode.get('episode_number') or 0)
        )
    year = media.get('year', '').strip()
    if media.get('media_type') == 'movie' and year:
        return '%s %s' % (title, year)
    return title


def format_source(source):
    return '%s | %s seeds | %s | %s | %s' % (
        source.get('quality', 'unknown').upper(),
        source.get('seeders', 0),
        format_size(source.get('size', 0)),
        source.get('indexer', 'Prowlarr'),
        truncate(source.get('title', 'Unknown'), 90)
    )


def format_size(size):
    try:
        size = float(size)
    except Exception:
        return '? GB'
    if size <= 0:
        return '? GB'
    return '%.2f GB' % (size / (1024 ** 3))


def open_media_details(media):
    from resources.lib.gui.details import open_media_info_window
    open_media_info_window(media)


def open_season_window(show):
    from resources.lib.gui.details import open_media_info_window
    open_media_info_window(show)


def open_episode_window(show, season):
    from resources.lib.gui.details import open_episode_info_window
    open_episode_info_window(show, season)


def open_source_window(media, episode=None):
    window = SourceWindow(media, episode)
    window.doModal()
    del window


def open_media_from_home(media):
    open_media_details(media)


def open_movies_window():
    window = MoviesWindow()
    window.doModal()
    del window


def open_musical_movies_window():
    window = MoviesWindow(heading='MUSICAL MOVIES', genre_id=tmdb.MUSIC_GENRE_ID)
    window.doModal()
    del window
