from __future__ import absolute_import

import json
import os
import re
import threading
from datetime import datetime
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

import pyxbmct
import xbmc

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.core import remote
from resources.lib.gui import dialogs
from resources.lib.gui.buttons import text_button
from resources.lib.gui.sports import SportsBrowseWindow, notify


def open_iptv():
    rows = _call('sources', {}, 'Loading IPTV...')
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'No IPTV sources are available.')
        return
    items = [_source_item(row) for row in rows]

    def choose(item):
        if item.get('channel_id'):
            _play(item)
            return
        _open_categories(item['source_id'], item['title'])

    _browse(
        'IPTV',
        'Sources',
        items,
        choose,
        'IPTV',
        'Choose a source',
        'Sources are supplied by Colossus. Search or open a category, highlight a channel, '
        'then use Add to playlist. Playlists keeps those channels together, and can rename or delete a list.',
        allow_search=True,
        search_heading='Search all sources',
        search_source=_search_all,
        search_list_heading='CHANNELS'
    )


def _open_categories(source_id, source_name):
    rows = _call('categories', {'source_id': source_id}, 'Loading categories...')
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'No categories were found.')
        return
    items = [_category_item(source_id, row) for row in rows]

    def choose(item):
        if item.get('channel_id'):
            _play(item)
            return
        _open_channels(item['source_id'], item['category_id'], item['title'])

    _browse(
        source_name,
        'Categories',
        items,
        choose,
        source_name,
        'Choose a category',
        'Pick a category to see the channels in it.',
        allow_search=True,
        search_heading='Search channels' if source_id == 'guide' else 'Search categories',
        search_source=_search_guide if source_id == 'guide' else None,
        search_list_heading='CHANNELS' if source_id == 'guide' else 'CATEGORIES'
    )


def _open_channels(source_id, category_id, category_name):
    rows = _call(
        'channels',
        {'source_id': source_id, 'category_id': category_id},
        'Loading channels...'
    )
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'No channels were found.')
        return
    items = [_channel_item(source_id, row) for row in rows]

    def choose(item):
        _play(item)

    _browse(
        category_name,
        'Channels',
        items,
        choose,
        category_name,
        'Choose a channel',
        'Select a channel to play it. Add to playlist saves it, and inside a playlist '
        'Move up and Move down change the order. Playlists can rename or delete a whole list.',
        allow_search=True,
        search_heading='Search channels'
    )


def _play(item):
    result = _call(
        'play',
        {'source_id': item['source_id'], 'channel_id': item['channel_id']},
        'Opening channel...'
    )
    if not result:
        return
    url = result.get('url') or ''
    streams = result.get('streams') or []
    if url and url not in streams:
        streams.insert(0, url)
    if not url and not streams:
        dialogs.ok(paths.ADDON_NAME, 'That channel did not return a stream.')
        return
    headers = result.get('headers') or {}
    options = _quality_choices(streams or [url], headers)
    if options is None:
        return
    if not options:
        dialogs.ok(
            paths.ADDON_NAME,
            'That channel did not start.\nThe stream is blocked or the link is no longer online.'
        )
        return
    title = result.get('title') or item.get('title') or 'Channel'
    if len(options) == 1:
        outcome = player.play_stream(title, options[0]['url'], headers)
        if outcome is False or not player.wait_until_playback_ends(outcome):
            dialogs.ok(
                paths.ADDON_NAME,
                'That channel did not start.\nThe stream is blocked or the link is no longer online.'
            )
        return
    labels = [item['label'] for item in options]
    while True:
        choice = dialogs.select('Choose quality', labels)
        if choice < 0 or choice >= len(options):
            return
        outcome = player.play_stream(title, options[choice]['url'], headers)
        if outcome is False or not player.wait_until_playback_ends(outcome):
            continue
        return


def _quality_choices(urls, headers):
    progress = dialogs.Progress()
    progress.create(paths.ADDON_NAME, 'Checking quality...')
    holder = {'options': [], 'done': False}

    def worker():
        try:
            holder['options'] = _quality_options(urls, headers)
        except Exception:
            holder['options'] = []
        holder['done'] = True

    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
    while not holder['done']:
        if progress.iscanceled():
            try:
                progress.close()
            except Exception:
                pass
            return None
        xbmc.sleep(80)
    try:
        progress.close()
    except Exception:
        pass
    return holder['options'] or []


def _quality_options(urls, headers):
    found = []
    seen = set()
    for raw in urls:
        url = _open_stream(raw, headers)
        if not url or url in seen:
            continue
        seen.add(url)
        path = url.lower().split('?', 1)[0]
        if path.endswith('.mpd') or '.mpd' in path:
            found.append({'url': url, 'width': 0, 'height': 1, 'bandwidth': 1})
            continue
        playlist, base_url = _fetch_playlist(url, headers)
        variants = _hls_variants(playlist, base_url)
        if variants:
            found.extend(variants)
            continue
        if playlist and '#EXTM3U' in playlist:
            found.append({'url': url, 'width': 0, 'height': 0, 'bandwidth': 0})
    ranked = [item for item in found if item['height'] or item['bandwidth']]
    if ranked:
        found = ranked
    elif len(found) < 2:
        return found
    else:
        return []
    best = {}
    for item in found:
        key = (item['width'], item['height'], item['bandwidth'])
        current = best.get(key)
        if current is None or item['bandwidth'] > current['bandwidth']:
            best[key] = item
    options = list(best.values())
    options.sort(key=lambda item: (item['height'], item['bandwidth']), reverse=True)
    heights = {}
    for item in options:
        heights[item['height']] = heights.get(item['height'], 0) + 1
    for item in options:
        item['label'] = _quality_label(item, heights.get(item['height'], 0) > 1)
    return options


def _quality_label(item, crowded):
    path = (item.get('url') or '').lower().split('?', 1)[0]
    if path.endswith('.mpd') or '.mpd' in path:
        return 'DASH'
    height = item['height']
    bandwidth = item['bandwidth']
    if height and crowded:
        label = '%sx%s' % (item['width'], height)
    elif height:
        label = '%sp' % height
    elif bandwidth:
        label = '%s Mbps' % max(1, int(round(bandwidth / 1000000.0)))
    else:
        label = 'Standard'
    if height and bandwidth and crowded:
        label = '%s · %s Mbps' % (label, max(1, int(round(bandwidth / 1000000.0))))
    return label


def _hls_variants(playlist, base_url):
    if not playlist or '#EXT-X-STREAM-INF' not in playlist:
        return []
    variants = []
    pending = None
    for raw in playlist.splitlines():
        line = raw.strip()
        if line.startswith('#EXT-X-STREAM-INF'):
            pending = line
            continue
        if pending is None or not line or line.startswith('#'):
            continue
        resolution = re.search(r'RESOLUTION=(\d+)x(\d+)', pending, re.I)
        bandwidth = re.search(r'BANDWIDTH=(\d+)', pending, re.I)
        pending = None
        if resolution is None:
            continue
        variants.append({
            'url': _join_variant(base_url, line),
            'width': int(resolution.group(1)),
            'height': int(resolution.group(2)),
            'bandwidth': int(bandwidth.group(1)) if bandwidth else 0,
        })
    return variants


def _join_variant(base_url, uri):
    joined = urljoin(base_url, uri)
    base = urlparse(base_url)
    target = urlparse(joined)
    if base.query and not target.query:
        joined = '%s?%s' % (joined, base.query)
    return joined


def _open_stream(url, headers):
    """Follow the link and keep it only when it is a real stream."""
    url = str(url or '').strip()
    if not url.lower().startswith(('http://', 'https://')):
        return ''
    request_headers = {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
        ),
        'Accept': '*/*',
    }
    for key, value in (headers or {}).items():
        if value:
            request_headers[str(key)] = str(value)
    request = Request(url, headers=request_headers)
    try:
        response = urlopen(request, timeout=8)
        try:
            final = response.geturl() or url
            sample = response.read(12000)
            try:
                content_type = (response.headers.get('Content-Type') or '').lower()
            except Exception:
                content_type = ''
        finally:
            response.close()
    except Exception:
        return ''
    text = sample.decode('utf-8', 'ignore').lstrip().lower()
    if text.startswith('<!doctype html') or text.startswith('<html') or 'site suspended' in text:
        return ''
    path = (final or url).lower().split('?', 1)[0]
    if '#extm3u' in text or '.m3u8' in path or 'mpegurl' in content_type:
        return final
    if '<mpd' in text or path.endswith('.mpd') or '.mpd' in path or 'dash+xml' in content_type:
        return final
    if path.endswith(('.mp4', '.ts', '.mkv', '.m4v')) or content_type.startswith('video/'):
        return final
    return ''


def _fetch_playlist(url, headers):
    lowered = url.lower().split('?', 1)[0]
    if not lowered.endswith('.m3u8') and '.m3u8' not in lowered:
        return '', url
    request_headers = {
        'User-Agent': 'Mozilla/5.0',
        'Accept': '*/*',
    }
    for key, value in (headers or {}).items():
        if value:
            request_headers[str(key)] = str(value)
    request = Request(url, headers=request_headers)
    try:
        response = urlopen(request, timeout=8)
        try:
            # Follow the redirect. Source 4 answers on a different host, and
            # the quality paths in the playlist only exist on that host.
            final = response.geturl() or url
            return response.read(250000).decode('utf-8', 'ignore'), final
        finally:
            response.close()
    except Exception:
        return '', url


def _call(name, kwargs, message):
    progress = dialogs.Progress()
    progress.create(paths.ADDON_NAME, message)
    holder = {
        'data': None,
        'error': None,
        'done': False,
        'percent': 0,
        'text': message,
        'cancel': False,
    }

    def on_progress(percent, text):
        try:
            holder['percent'] = int(percent or 0)
        except Exception:
            holder['percent'] = 0
        if text:
            holder['text'] = text
        return holder['cancel']

    def worker():
        try:
            holder['data'] = remote.call('iptv', name, kwargs=kwargs, on_progress=on_progress)
        except Exception as exc:
            holder['error'] = exc
        holder['done'] = True

    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
    while not holder['done']:
        if progress.iscanceled():
            holder['cancel'] = True
            try:
                progress.close()
            except Exception:
                pass
            return None
        try:
            progress.update(holder['percent'], holder['text'])
        except Exception:
            pass
        xbmc.sleep(80)
    try:
        progress.close()
    except Exception:
        pass
    if holder['cancel']:
        return None
    if holder['error'] is not None:
        dialogs.ok(paths.ADDON_NAME, 'Request failed.\n%s' % holder['error'])
        return None
    return holder['data']


def _search_all(query):
    rows = _call('search', {'query': query}, 'Searching sources...')
    if rows is None:
        return None
    return [_search_item(row) for row in rows]


def _search_guide(query):
    rows = _call('search', {'query': query, 'source_id': 'guide'}, 'Searching Source 4...')
    if rows is None:
        return None
    return [_search_item(row) for row in rows]


def _search_item(row):
    source_name = row.get('source_name') or 'Source'
    category = row.get('category') or ''
    name = row.get('name') or 'Channel'
    now = row.get('now') or ''
    guide = _guide_text(now, row.get('upcoming') or [])
    return {
        'label': '%s    %s' % (name, source_name),
        'title': name,
        'meta': '%s  |  %s' % (source_name, now or category),
        'overview': guide or 'Select to play this channel.',
        'image': row.get('logo') or '',
        'source_id': row.get('source_id') or '',
        'channel_id': row.get('id') or '',
    }


def _browse(heading, list_heading, items, on_select, empty_title, empty_meta, empty_overview, allow_search=False, search_heading='Search', search_source=None, search_list_heading='CHANNELS'):
    window = _IptvWindow(
        heading=heading,
        status_text='%s %s' % (len(items), list_heading.lower()),
        items=items,
        on_select=on_select,
        art_path=paths.IPTV_BUTTON_PATH,
        empty_title=empty_title,
        empty_meta=empty_meta,
        empty_overview=empty_overview,
        allow_search=allow_search,
        search_heading=search_heading,
        search_source=search_source,
        search_list_heading=search_list_heading,
        list_heading=list_heading.upper()
    )
    window.doModal()
    del window


def _source_item(row):
    return {
        'label': row.get('name') or 'Source',
        'title': row.get('name') or 'Source',
        'meta': 'Source',
        'overview': 'Open this source to browse its categories.',
        'source_id': row.get('id') or '',
    }


def _category_item(source_id, row):
    count = int(row.get('count') or 0)
    label = '%s    %s' % (row.get('name') or 'Category', count)
    return {
        'label': label,
        'title': row.get('name') or 'Category',
        'meta': '%s channels' % count,
        'overview': 'Open this category to see its channels.',
        'source_id': source_id,
        'category_id': row.get('id') or '',
    }


def _channel_item(source_id, row):
    name = row.get('name') or 'Channel'
    now = row.get('now') or ''
    guide = _guide_text(row.get('now') or '', row.get('upcoming') or [])
    return {
        'label': '%s    %s' % (name, now) if now else name,
        'title': name,
        'meta': now or 'Channel',
        'overview': guide or 'Select to play this channel.',
        'image': row.get('logo') or '',
        'source_id': source_id,
        'channel_id': row.get('id') or '',
    }


def _guide_text(now, upcoming):
    lines = []
    if now:
        lines.append('Now: %s' % now)
    for item in upcoming or []:
        if not isinstance(item, dict):
            continue
        title = item.get('title') or ''
        if not title:
            continue
        clock = _local_clock(item.get('start') or '')
        lines.append('%s  %s' % (clock, title) if clock else title)
        if len(lines) >= 6:
            break
    return '\n'.join(lines)


def _local_clock(value):
    text = str(value or '').strip().replace('Z', '+00:00')
    if not text:
        return ''
    try:
        moment = datetime.fromisoformat(text)
    except Exception:
        return ''
    try:
        return moment.astimezone().strftime('%H:%M')
    except Exception:
        return ''


IPTV_LISTS_PATH = os.path.join(paths.PROFILE_PATH, 'iptv_lists.json')


def _iptv_key(item):
    item = item or {}
    source_id = str(item.get('source_id') or '').strip()
    channel_id = str(item.get('channel_id') or '').strip()
    if source_id and channel_id:
        return '%s\n%s' % (source_id, channel_id)
    return ''


def _iptv_record(item):
    item = item or {}
    record = {}
    for key in ('title', 'meta', 'overview', 'image', 'source_id', 'channel_id'):
        value = item.get(key)
        if value is None:
            continue
        record[key] = str(value)
    clean = item.get('plain_label') or item.get('label') or record.get('title') or 'Channel'
    record['label'] = str(clean)
    record['plain_label'] = str(clean)
    if not record.get('title'):
        record['title'] = 'Channel'
    return record


def _same_iptv(left, right):
    key = _iptv_key(left)
    return bool(key) and key == _iptv_key(right)


def _unique_iptv(records):
    kept = []
    for record in records or []:
        if not isinstance(record, dict) or not _iptv_key(record):
            continue
        if any(_same_iptv(record, existing) for existing in kept):
            continue
        kept.append(_iptv_record(record))
    return kept


def load_iptv_lists():
    data = {'favs': [], 'playlists': []}
    try:
        if not os.path.exists(IPTV_LISTS_PATH):
            return data
        with open(IPTV_LISTS_PATH, 'r', encoding='utf-8') as handle:
            raw = json.load(handle)
    except Exception:
        return data
    if not isinstance(raw, dict):
        return data
    data['favs'] = _unique_iptv(raw.get('favs') or [])
    seen_names = set()
    for playlist in raw.get('playlists') or []:
        if not isinstance(playlist, dict):
            continue
        name = ' '.join(str(playlist.get('name') or '').split())
        if not name or name.lower() in seen_names:
            continue
        seen_names.add(name.lower())
        data['playlists'].append({
            'name': name[:40],
            'channels': _unique_iptv(playlist.get('channels') or []),
        })
    return data


def save_iptv_lists(data):
    try:
        folder = os.path.dirname(IPTV_LISTS_PATH)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(IPTV_LISTS_PATH, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except Exception:
        pass


class _IptvWindow(SportsBrowseWindow):
    def set_controls(self):
        self.library = load_iptv_lists()
        self.view = 'all'
        self.playlist_name = ''
        self._ready = False
        self._editing_layout = None
        self._absorb()
        super(_IptvWindow, self).set_controls()
        self.fav_button = text_button('Favourite')
        self.placeControl(self.fav_button, 62, 2, 5, 22)
        self.connect(self.fav_button, self.toggle_favourite)
        self.favs_button = text_button('Favs')
        self.placeControl(self.favs_button, 67, 2, 5, 22)
        self.connect(self.favs_button, self.show_favs)
        self.add_button = text_button('Add to playlist')
        self.placeControl(self.add_button, 72, 2, 5, 22)
        self.connect(self.add_button, self.add_or_remove)
        self.playlists_button = text_button('Playlists')
        self.placeControl(self.playlists_button, 77, 2, 5, 22)
        self.connect(self.playlists_button, self.open_playlists)
        self.move_up_button = text_button('Move up')
        self.placeControl(self.move_up_button, 82, 2, 5, 22)
        self.connect(self.move_up_button, lambda: self._move_channel(-1))
        self.move_down_button = text_button('Move down')
        self.placeControl(self.move_down_button, 87, 2, 5, 22)
        self.connect(self.move_down_button, lambda: self._move_channel(1))
        self._layout_edit_buttons()

    def _show_add_button(self):
        items = self.visible_items if getattr(self, '_ready', False) else self.all_items
        return any(_iptv_key(item) for item in (items or []))

    def _hide_button(self, control):
        try:
            control.setVisible(False)
        except Exception:
            pass
        try:
            control.setPosition(-1000, -1000)
        except Exception:
            pass

    def _layout_edit_buttons(self):
        editing = self.view == 'playlist'
        show_add = self._show_add_button()
        signature = (editing, show_add)
        if self._editing_layout == signature:
            return
        self._editing_layout = signature
        row = 72
        if show_add:
            self.move_control(self.add_button, row, 2, 5, 22)
            self.add_button.setVisible(True)
            row += 5
        else:
            self._hide_button(self.add_button)
        self.move_control(self.playlists_button, row, 2, 5, 22)
        row += 5
        if editing:
            self.move_control(self.move_up_button, row, 2, 5, 22)
            self.move_up_button.setVisible(True)
            row += 5
            self.move_control(self.move_down_button, row, 2, 5, 22)
            self.move_down_button.setVisible(True)
            row += 5
        else:
            self._hide_button(self.move_up_button)
            self._hide_button(self.move_down_button)
        if self.search_button is not None:
            self.move_control(self.search_button, row, 2, 6, 22)
            self.search_button.setVisible(True)

    def set_navigation(self):
        buttons = [
            self.fav_button,
            self.favs_button,
        ]
        if self._show_add_button():
            buttons.append(self.add_button)
        buttons.append(self.playlists_button)
        if self.view == 'playlist':
            buttons.extend((self.move_up_button, self.move_down_button))
        if self.search_button is not None:
            buttons.append(self.search_button)
        self.back_button.controlDown(buttons[0])
        self.back_button.controlRight(self.results_list)
        for index, button in enumerate(buttons):
            button.controlUp(self.back_button if index == 0 else buttons[index - 1])
            if index + 1 < len(buttons):
                button.controlDown(buttons[index + 1])
            else:
                button.controlDown(self.results_list)
            button.controlRight(self.results_list)
            button.controlLeft(self.back_button)
        self.results_list.controlLeft(buttons[0])
        self.results_list.controlUp(self.back_button)

    def _absorb(self):
        fresh = {}
        for item in self.all_items:
            key = _iptv_key(item)
            if key:
                fresh[key] = _iptv_record(item)
        if not fresh:
            return

        def refresh(records):
            updated = []
            local_changed = False
            for record in records:
                newer = fresh.get(_iptv_key(record))
                if newer and newer != record:
                    updated.append(newer)
                    local_changed = True
                else:
                    updated.append(record)
            return updated, local_changed

        changed = False
        favs, favs_changed = refresh(self.library.get('favs') or [])
        changed = changed or favs_changed
        self.library['favs'] = favs
        for playlist in self.library.get('playlists') or []:
            channels, playlist_changed = refresh(playlist.get('channels') or [])
            playlist['channels'] = channels
            changed = changed or playlist_changed
        if changed:
            save_iptv_lists(self.library)

    def _home_label(self):
        heading = (self.list_heading_text or 'List').replace('_', ' ').strip()
        if heading.upper() == 'CHANNELS':
            return 'All channels'
        return heading.title()

    def _is_fav(self, item):
        return any(_same_iptv(item, record) for record in (self.library.get('favs') or []))

    def _playlist_names_for(self, item):
        if not _iptv_key(item):
            return []
        names = []
        for playlist in self.library.get('playlists') or []:
            for record in playlist.get('channels') or []:
                if _same_iptv(item, record):
                    names.append(playlist.get('name') or '')
                    break
        return [name for name in names if name]

    def _decorate(self, item):
        if 'plain_label' not in item:
            item['plain_label'] = item.get('label') or item.get('title') or ''
        base = item.get('plain_label') or item.get('title') or 'Channel'
        marks = []
        if _iptv_key(item) and self._is_fav(item):
            marks.append('[COLOR FF7EE0FF]*[/COLOR]')
        if self._playlist_names_for(item):
            marks.append('[COLOR FF7EE0FF]![/COLOR]')
        item['label'] = '%s  %s' % (' '.join(marks), base) if marks else base
        return item

    def _merge_saved(self, records):
        fresh = {}
        for item in self.all_items:
            key = _iptv_key(item)
            if key:
                fresh[key] = item
        merged = []
        for record in records or []:
            if not _iptv_key(record):
                continue
            if any(_same_iptv(record, existing) for existing in merged):
                continue
            merged.append(fresh.get(_iptv_key(record)) or record)
        return merged

    def _pool(self):
        if self.view == 'favs':
            records = self._merge_saved(self.library.get('favs') or [])
        elif self.view == 'playlist':
            records = []
            for playlist in self.library.get('playlists') or []:
                if playlist.get('name') == self.playlist_name:
                    records = self._merge_saved(playlist.get('channels') or [])
                    break
        else:
            records = list(self.all_items)
        return [self._decorate(item) for item in records]

    def _current_item(self):
        if not self.visible_items:
            return None
        index = self.current_index
        if index < 0 or index >= len(self.visible_items):
            try:
                index = self.results_list.getSelectedPosition()
            except Exception:
                return None
        if index < 0 or index >= len(self.visible_items):
            return None
        return self.visible_items[index]

    def _heading(self):
        if self.view == 'favs':
            return 'FAVS'
        if self.view == 'playlist':
            return (self.playlist_name or 'Playlist').upper()
        return self.list_heading_text

    def _empty_message(self):
        if self.view == 'favs':
            return (
                'No favourites yet',
                'Highlight a channel and press Favourite. Favs then shows only those channels.',
            )
        if self.view == 'playlist':
            return (
                'Playlist is empty',
                'Open a category or search, highlight a channel, and press Add to playlist. '
                'Inside a playlist, Remove takes a channel out. Move up and Move down change the order. '
                'Playlists can rename or delete the whole list.',
            )
        return ('No channels', 'No channels are available right now.')

    def populate_list(self, query=''):
        pool = self._pool()
        self._sync_buttons()
        if self.view != 'all' and not pool:
            title, overview = self._empty_message()
            self.visible_items = []
            self.current_index = -1
            self._repaint_list([title])
            self.status_label.setLabel(title)
            self.title_label.setLabel('[B]%s[/B]' % title)
            self.meta_label.setLabel('')
            self.overview_box.setText(overview)
            try:
                self.list_heading.setLabel('[B]%s[/B]' % self._heading())
            except Exception:
                pass
            self._sync_buttons()
            return
        saved_items = self.all_items
        saved_source = self.search_source
        self.all_items = pool
        if self.view != 'all':
            self.search_source = None
        try:
            super(_IptvWindow, self).populate_list(query)
        finally:
            self.all_items = saved_items
            self.search_source = saved_source
        for item in self.visible_items:
            self._decorate(item)
        self._repaint_list([item.get('label') or '' for item in self.visible_items])
        searched = bool((query or '').strip()) and self.view == 'all' and saved_source
        if not searched:
            try:
                self.list_heading.setLabel('[B]%s[/B]' % self._heading())
            except Exception:
                pass
        if self.visible_items and not (query or '').strip():
            if self.view == 'favs':
                self.status_label.setLabel('%s favs  |  Select a channel to play.' % len(self.visible_items))
            elif self.view == 'playlist':
                self.status_label.setLabel(
                    '%s in %s  |  Play, Remove, or Move up and Move down.' % (len(self.visible_items), self.playlist_name)
                )
            elif _iptv_key(self.visible_items[0]):
                self.status_label.setLabel('%s channels  |  Select a channel to play.' % len(self.visible_items))
        self._sync_buttons()

    def update_preview(self, force=False):
        super(_IptvWindow, self).update_preview(force=force)
        item = self._current_item()
        if not item:
            self._sync_buttons()
            return
        image = item.get('image') or self.art_path
        try:
            self.poster.setImage(image)
        except Exception:
            pass
        if _iptv_key(item):
            notes = []
            if self._is_fav(item):
                notes.append('This channel is saved in favs.')
            names = self._playlist_names_for(item)
            if names:
                notes.append('This channel is added to a playlist: %s.' % ', '.join(names))
            if notes:
                text = item.get('overview') or ''
                self.overview_box.setText(text + '\n\n' + '\n'.join(notes))
        self._sync_buttons()

    def _repaint_list(self, labels):
        if not getattr(self, '_ready', False):
            self._ready = True
            return
        try:
            self.removeControl(self.results_list)
        except Exception:
            pass
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)
        for label in labels:
            self.results_list.addItem(label)
        try:
            self.set_navigation()
        except Exception:
            pass

    def _sync_buttons(self):
        item = self._current_item()
        self.fav_button.setLabel('Unfavourite' if item and self._is_fav(item) else 'Favourite')
        self.favs_button.setLabel(self._home_label() if self.view != 'all' else 'Favs')
        self.add_button.setLabel('Remove' if self.view == 'playlist' else 'Add to playlist')
        previous = self._editing_layout
        self._layout_edit_buttons()
        if previous != self._editing_layout:
            try:
                self.set_navigation()
            except Exception:
                pass

    def _reselect(self, key):
        if not key:
            return
        for index, item in enumerate(self.visible_items):
            if _iptv_key(item) == key:
                try:
                    self.results_list.selectItem(index)
                except Exception:
                    pass
                self.update_preview(force=True)
                return

    def _require_channel(self):
        item = self._current_item()
        key = _iptv_key(item)
        if not key:
            notify('Highlight a channel first.')
            return None, ''
        return item, key

    def toggle_favourite(self):
        item, key = self._require_channel()
        if not key:
            return
        favs = list(self.library.get('favs') or [])
        if any(_same_iptv(item, record) for record in favs):
            favs = [record for record in favs if not _same_iptv(item, record)]
            notify('Removed from favs.')
        else:
            favs.append(_iptv_record(item))
            notify('Added to favs.')
        self.library['favs'] = favs
        save_iptv_lists(self.library)
        self.populate_list()
        self._reselect(key)
        self.setFocus(self.results_list)

    def show_favs(self):
        if self.view != 'all':
            self.view = 'all'
            self.playlist_name = ''
        else:
            self.view = 'favs'
            self.playlist_name = ''
        self.populate_list()
        self.setFocus(self.results_list)

    def _ask_playlist_name(self, current='', ignore=''):
        keyboard = xbmc.Keyboard(current or '', 'Playlist name')
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return ''
        name = ' '.join(keyboard.getText().split())[:40].strip()
        if not name:
            notify('Enter a playlist name.')
            return ''
        folded_ignore = (ignore or '').lower()
        for playlist in self.library.get('playlists') or []:
            existing = str(playlist.get('name') or '')
            if folded_ignore and existing.lower() == folded_ignore:
                continue
            if existing.lower() == name.lower():
                notify('You already have a playlist with that name.')
                return ''
        return name

    def _pick_playlist(self, heading):
        names = []
        for playlist in self.library.get('playlists') or []:
            label = playlist.get('name') or ''
            if label:
                names.append(label)
        if self.view == 'playlist' and self.playlist_name in names:
            names = [self.playlist_name] + [label for label in names if label != self.playlist_name]
        if not names:
            notify('No playlists yet.')
            return ''
        choice = dialogs.select(heading, names)
        if choice < 0:
            return ''
        return names[choice]

    def _rename_playlist(self, name):
        playlist = self._playlist_by_name(name)
        if playlist is None:
            notify('That playlist is gone.')
            return False
        new_name = self._ask_playlist_name(current=name, ignore=name)
        if not new_name or new_name == name:
            return False
        playlist['name'] = new_name
        save_iptv_lists(self.library)
        if self.playlist_name == name:
            self.playlist_name = new_name
        notify('Renamed to %s.' % new_name)
        return True

    def _delete_playlist(self, name):
        if not dialogs.yesno(paths.ADDON_NAME, 'Delete the playlist "%s"?' % name):
            return False
        self.library['playlists'] = [
            playlist for playlist in (self.library.get('playlists') or [])
            if playlist.get('name') != name
        ]
        save_iptv_lists(self.library)
        notify('Playlist deleted.')
        if self.view == 'playlist' and self.playlist_name == name:
            self.view = 'all'
            self.playlist_name = ''
        return True

    def _playlist_by_name(self, name):
        for playlist in self.library.get('playlists') or []:
            if playlist.get('name') == name:
                return playlist
        return None

    def add_or_remove(self):
        if self.view == 'playlist':
            self._remove_from_playlist()
            return
        self._add_to_playlist()

    def _add_to_playlist(self):
        item, key = self._require_channel()
        if not key:
            return
        playlists = self.library.setdefault('playlists', [])
        options = ['New playlist'] + [playlist.get('name') or 'Playlist' for playlist in playlists]
        choice = dialogs.select('Add to playlist', options)
        if choice < 0:
            return
        if choice == 0:
            name = self._ask_playlist_name()
            if not name:
                return
            playlist = {'name': name, 'channels': []}
            playlists.append(playlist)
        else:
            playlist = playlists[choice - 1]
            name = playlist.get('name') or 'Playlist'
        channels = playlist.setdefault('channels', [])
        if any(_same_iptv(item, record) for record in channels):
            notify('Already in %s.' % name)
            return
        channels.append(_iptv_record(item))
        playlist['channels'] = _unique_iptv(channels)
        save_iptv_lists(self.library)
        notify('Added to %s.' % name)
        self.populate_list()
        self._reselect(key)
        self.setFocus(self.results_list)

    def _remove_from_playlist(self):
        item, key = self._require_channel()
        playlist = self._playlist_by_name(self.playlist_name)
        if not key or not playlist:
            notify('Highlight a channel first.')
            return
        playlist['channels'] = [
            record for record in (playlist.get('channels') or [])
            if not _same_iptv(item, record)
        ]
        save_iptv_lists(self.library)
        notify('Removed from %s.' % self.playlist_name)
        self.populate_list()
        self.setFocus(self.results_list)

    def _move_channel(self, direction):
        if self.view != 'playlist':
            notify('Open a playlist to change the order.')
            return
        item, key = self._require_channel()
        playlist = self._playlist_by_name(self.playlist_name)
        if not key or not playlist:
            notify('Highlight a channel first.')
            return
        channels = list(playlist.get('channels') or [])
        index = None
        for position, record in enumerate(channels):
            if _same_iptv(item, record):
                index = position
                break
        if index is None:
            notify('That channel is not in this playlist.')
            return
        target = index + direction
        if target < 0:
            notify('Already at the top.')
            return
        if target >= len(channels):
            notify('Already at the bottom.')
            return
        channels[index], channels[target] = channels[target], channels[index]
        playlist['channels'] = channels
        save_iptv_lists(self.library)
        self.populate_list()
        self._reselect(key)
        self.setFocus(self.results_list)

    def open_playlists(self):
        playlists = self.library.get('playlists') or []
        options = []
        actions = []
        if self.view != 'all':
            options.append(self._home_label())
            actions.append('all')
        options.append('New playlist')
        actions.append('new')
        if playlists:
            options.append('Rename a playlist')
            actions.append('rename')
            options.append('Delete a playlist')
            actions.append('delete')
        for playlist in playlists:
            count = len(playlist.get('channels') or [])
            options.append('%s    (%s)' % (playlist.get('name') or 'Playlist', count))
            actions.append(('open', playlist.get('name') or ''))
        choice = dialogs.select('Playlists', options)
        if choice < 0:
            return
        action = actions[choice]
        if action == 'all':
            self.view = 'all'
            self.playlist_name = ''
        elif action == 'new':
            name = self._ask_playlist_name()
            if not name:
                return
            self.library.setdefault('playlists', []).append({'name': name, 'channels': []})
            save_iptv_lists(self.library)
            notify('Playlist created. Highlight a channel and press Add to playlist.')
        elif action == 'rename':
            name = self._pick_playlist('Rename a playlist')
            if not name or not self._rename_playlist(name):
                return
        elif action == 'delete':
            name = self._pick_playlist('Delete a playlist')
            if not name or not self._delete_playlist(name):
                return
        elif isinstance(action, tuple) and action[0] == 'open':
            self.view = 'playlist'
            self.playlist_name = action[1]
        self.populate_list()
        self.setFocus(self.results_list)
