"""Saved movies and shows. The lists stay in the addon profile."""

from __future__ import absolute_import

import json
import os

import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.core import tmdb
from resources.lib.gui import dialogs


LISTS_PATH = os.path.join(paths.PROFILE_PATH, 'media_lists.json')


def notify(message):
    xbmcgui.Dialog().notification(paths.ADDON_NAME, message, paths.ICON_PATH, 3000)


def media_key(media):
    media = media or {}
    kind = media.get('media_type') or media.get('type') or ''
    try:
        number = int(media.get('id') or 0)
    except (TypeError, ValueError):
        number = 0
    if kind not in ('movie', 'tv') or number < 1:
        return ''
    return '%s:%s' % (kind, number)


def _record(media):
    return {
        'id': int(media.get('id') or 0),
        'media_type': media.get('media_type') or media.get('type') or '',
        'title': media.get('title') or 'Unknown',
        'year': str(media.get('year') or ''),
        'overview': media.get('overview') or '',
        'poster': media.get('poster') or '',
        'backdrop': media.get('backdrop') or '',
    }


def _same(left, right):
    key = media_key(left)
    return bool(key) and key == media_key(right)


def _unique(records):
    kept = []
    for record in records or []:
        if not isinstance(record, dict) or not media_key(record):
            continue
        if any(_same(record, existing) for existing in kept):
            continue
        kept.append(_record(record))
    return kept


def load_lists():
    data = {'favs': [], 'playlists': [], 'progress': {}}
    try:
        if not os.path.exists(LISTS_PATH):
            return data
        with open(LISTS_PATH, 'r', encoding='utf-8') as handle:
            raw = json.load(handle)
    except Exception:
        return data
    if not isinstance(raw, dict):
        return data
    data['favs'] = _unique(raw.get('favs') or [])
    seen_names = set()
    for playlist in raw.get('playlists') or []:
        if not isinstance(playlist, dict):
            continue
        name = ' '.join(str(playlist.get('name') or '').split())
        if not name or name.lower() in seen_names:
            continue
        seen_names.add(name.lower())
        data['playlists'].append({
            'name': name[:40],
            'items': _unique(playlist.get('items') or []),
        })
    progress = {}
    for key, item in (raw.get('progress') or {}).items():
        if not isinstance(item, dict):
            continue
        try:
            season = int(item.get('season') or 0)
            episode = int(item.get('episode') or 0)
        except (TypeError, ValueError):
            continue
        if season < 1 or episode < 1:
            continue
        progress[str(key)] = {
            'season': season,
            'episode': episode,
            'name': str(item.get('name') or ''),
        }
    data['progress'] = progress
    return data


def save_lists(data):
    try:
        folder = os.path.dirname(LISTS_PATH)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        payload = {
            'favs': data.get('favs') or [],
            'playlists': data.get('playlists') or [],
            'progress': data.get('progress') or {},
        }
        with open(LISTS_PATH, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle)
    except Exception:
        pass


def is_favourite(media):
    return any(_same(media, record) for record in load_lists().get('favs') or [])


def playlist_names(media):
    names = []
    for playlist in load_lists().get('playlists') or []:
        for record in playlist.get('items') or []:
            if _same(media, record):
                names.append(playlist.get('name') or '')
                break
    return [name for name in names if name]


def progress_for(media):
    item = (load_lists().get('progress') or {}).get(media_key(media))
    return item or None


def toggle_favourite(media):
    if not media_key(media):
        notify('This title cannot be saved.')
        return False
    data = load_lists()
    favs = list(data.get('favs') or [])
    if any(_same(media, record) for record in favs):
        data['favs'] = [record for record in favs if not _same(media, record)]
        save_lists(data)
        notify('Removed from favs.')
        return False
    favs.append(_record(media))
    data['favs'] = favs
    save_lists(data)
    notify('Added to favs.')
    return True


def _ask_name(playlists, current='', ignore=''):
    keyboard = xbmc.Keyboard(current or '', 'Playlist name')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return ''
    name = ' '.join(keyboard.getText().split())[:40].strip()
    if not name:
        notify('Enter a playlist name.')
        return ''
    folded_ignore = (ignore or '').lower()
    for playlist in playlists:
        existing = str(playlist.get('name') or '')
        if folded_ignore and existing.lower() == folded_ignore:
            continue
        if existing.lower() == name.lower():
            notify('You already have a playlist with that name.')
            return ''
    return name


def add_to_playlist(media):
    if not media_key(media):
        notify('This title cannot be saved.')
        return ''
    data = load_lists()
    playlists = data.setdefault('playlists', [])
    options = ['New playlist'] + [playlist.get('name') or 'Playlist' for playlist in playlists]
    choice = dialogs.select('Add to playlist', options)
    if choice < 0:
        return ''
    if choice == 0:
        name = _ask_name(playlists)
        if not name:
            return ''
        playlist = {'name': name, 'items': []}
        playlists.append(playlist)
    else:
        playlist = playlists[choice - 1]
        name = playlist.get('name') or 'Playlist'
    items = playlist.setdefault('items', [])
    if any(_same(media, record) for record in items):
        notify('Already in %s.' % name)
        return name
    items.append(_record(media))
    playlist['items'] = _unique(items)
    save_lists(data)
    notify('Added to %s.' % name)
    return name


def remember_episode(media, episode):
    if not media_key(media):
        return
    episode = episode or {}
    try:
        season = int(episode.get('season_number') or 0)
        number = int(episode.get('episode_number') or 0)
    except (TypeError, ValueError):
        return
    if season < 1 or number < 1:
        return
    data = load_lists()
    data.setdefault('progress', {})[media_key(media)] = {
        'season': season,
        'episode': number,
        'name': episode.get('name') or episode.get('title') or '',
    }
    save_lists(data)


def next_episode(media, season, episode):
    tv_id = int(media.get('id') or 0)
    season = int(season or 0)
    episode = int(episode or 0)
    if tv_id < 1 or season < 1 or episode < 1:
        return None
    current = tmdb.episodes(tv_id, season)
    upcoming = [
        item for item in current
        if int(item.get('episode_number') or 0) > episode
    ]
    if upcoming:
        upcoming.sort(key=lambda item: int(item.get('episode_number') or 0))
        return upcoming[0]
    following = [
        item for item in tmdb.seasons(tv_id)
        if int(item.get('season_number') or 0) > season
    ]
    following.sort(key=lambda item: int(item.get('season_number') or 0))
    for item in following:
        episodes = tmdb.episodes(tv_id, item.get('season_number'))
        if not episodes:
            continue
        episodes.sort(key=lambda row: int(row.get('episode_number') or 0))
        return episodes[0]
    return None
