from __future__ import absolute_import

import os
import threading
import time

import pyxbmct
import xbmc

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.buttons import text_button
from resources.lib.sources.webcams import api
from resources.lib.sources.webcams.api import WebcamError


def _load_message(mode):
    return {
        'top': 'Loading the top cameras...',
        'new': 'Loading new cameras...',
        'places': 'Loading places...',
        'topics': 'Loading topics...',
        'featured': 'Loading featured cameras...',
        'sections': 'Loading sections...',
        'section': 'Loading that section...',
        'latest': 'Loading the latest cameras...',
        'countries': 'Loading countries...',
        'interests': 'Loading interests...',
        'rolling': 'Loading rolling cameras...',
        'category': 'Loading that section...',
        'search': 'Searching...',
    }.get(mode or '', 'Loading cameras...')


def _plain(text):
    return ' '.join((text or '').replace('[CR]', ' ').split())


def _art(path):
    text = (path or '').strip()
    if text.startswith('//'):
        text = 'https:' + text
    if text.lower().startswith('http://') or text.lower().startswith('https://'):
        return text
    if text and os.path.exists(text):
        return text
    if os.path.exists(paths.WEBCAM_PATH):
        return paths.WEBCAM_PATH
    return paths.ICON_PATH


SITES = (
    {
        'id': 'skyline',
        'title': 'SkylineWebcams',
        'meta': 'Top  |  New  |  Places  |  Topics',
        'overview': 'Live cameras from SkylineWebcams, sorted the way the site sorts them.',
        'actions': [
            {'id': 'top', 'label': 'Top'},
            {'id': 'new', 'label': 'New'},
            {'id': 'places', 'label': 'Places'},
            {'id': 'topics', 'label': 'Topics'},
            {'id': 'search', 'label': 'Search'},
        ],
    },
    {
        'id': 'earthcam',
        'title': 'EarthCam',
        'meta': 'Featured  |  Sections  |  Search',
        'overview': 'Live EarthCam cameras. Featured, the homepage sections, and search.',
        'actions': [
            {'id': 'featured', 'label': 'Featured'},
            {'id': 'sections', 'label': 'Sections'},
            {'id': 'search', 'label': 'Search'},
        ],
    },
    {
        'id': 'taxi',
        'title': 'Webcamtaxi',
        'meta': 'Latest  |  Most viewed  |  Countries',
        'overview': 'Live cameras from Webcamtaxi, including countries, interests, and search.',
        'actions': [
            {'id': 'latest', 'label': 'Latest'},
            {'id': 'top', 'label': 'Most viewed'},
            {'id': 'countries', 'label': 'Countries'},
            {'id': 'interests', 'label': 'Interests'},
            {'id': 'rolling', 'label': 'Rolling'},
            {'id': 'search', 'label': 'Search'},
        ],
    },
)


def open_webcams():
    window = WebcamSitesWindow()
    window.doModal()
    del window


class WebcamSitesWindow(ColossusFullWindow):
    def __init__(self):
        super(WebcamSitesWindow, self).__init__('')
        self.sites = list(SITES)
        self.current_index = -1
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.populate()
        try:
            self.setFocus(self.results_list)
        except Exception:
            self.setFocus(self.back_button)

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]WEBCAMS[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 14, 6, 50)
        self.status_label = pyxbmct.Label(
            'Choose a site.',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 64, 6, 32)
        self.poster = pyxbmct.Image(_art(paths.WEBCAM_PATH), aspectRatio=0)
        self.placeControl(self.poster, 12, 3, 36, 22)
        self.title_label = pyxbmct.Label(
            '[B]Webcams[/B]',
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.title_label, 12, 28, 10, 36)
        self.meta_label = pyxbmct.Label(
            '',
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.meta_label, 23, 28, 6, 36)
        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 30, 28, 20, 36)
        self.overview_box.setText('Choose a site, then browse its sections or search.')
        self.list_heading = pyxbmct.Label(
            '[B]SITES[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)

    def set_navigation(self):
        self.back_button.controlDown(self.results_list)
        self.back_button.controlRight(self.results_list)
        self.results_list.controlLeft(self.back_button)
        self.results_list.controlUp(self.back_button)

    def populate(self):
        self.results_list.reset()
        for site in self.sites:
            self.results_list.addItem(site.get('title') or 'Site')
        self.status_label.setLabel('%s sites  |  Select a site.' % len(self.sites))
        self.update_preview(force=True)

    def onAction(self, action):
        super(WebcamSitesWindow, self).onAction(action)
        self.update_preview()

    def _current(self):
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return None
        if index < 0 or index >= len(self.sites):
            return None
        return self.sites[index]

    def update_preview(self, force=False):
        site = self._current()
        if site is None:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        self.title_label.setLabel('[B]%s[/B]' % (site.get('title') or 'Site'))
        self.meta_label.setLabel(site.get('meta') or '')
        self.overview_box.setText(site.get('overview') or '')

    def select_current(self):
        site = self._current()
        if site is None:
            return
        window = WebcamBrowseWindow(site)
        window.doModal()
        del window


class WebcamBrowseWindow(ColossusFullWindow):
    def __init__(self, site):
        super(WebcamBrowseWindow, self).__init__('')
        self.site = site or {}
        self.items = []
        self.current_index = -1
        self.mode = 'latest'
        self.page = 1
        self.query = ''
        self.page_url = ''
        self.list_name = 'CAMERAS'
        self.action_buttons = []
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        actions = self.site.get('actions') or []
        first = (actions[0].get('id') if actions else '') or 'latest'
        self.load_mode(first)
        try:
            self.setFocus(self.results_list)
        except Exception:
            if self.action_buttons:
                self.setFocus(self.action_buttons[0])

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]%s[/B]' % (self.site.get('title') or 'WEBCAMS').upper()[:42],
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 14, 6, 48)
        self.status_label = pyxbmct.Label(
            '',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 64, 6, 32)
        actions = self.site.get('actions') or []
        poster_h = max(16, min(28, 62 - (8 * len(actions))))
        self.poster = pyxbmct.Image(_art(''), aspectRatio=0)
        self.placeControl(self.poster, 12, 3, poster_h, 20)
        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % (self.site.get('title') or 'Webcams'),
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.title_label, 12, 26, 10, 38)
        self.meta_label = pyxbmct.Label(
            self.site.get('meta') or '',
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.meta_label, 23, 26, 6, 38)
        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 30, 26, 16, 38)
        self.overview_box.setText(self.site.get('overview') or '')
        row = 12 + poster_h + 2
        for action in actions:
            button = text_button(action.get('label') or 'Open')
            self.placeControl(button, row, 2, 8, 22)
            mode = action.get('id') or 'latest'
            self.connect(button, (lambda current=mode: self.load_mode(current)))
            self.action_buttons.append(button)
            row += 8
        self.list_heading = pyxbmct.Label(
            '[B]CAMERAS[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)

    def set_navigation(self):
        if not self.action_buttons:
            self.back_button.controlDown(self.results_list)
            self.back_button.controlRight(self.results_list)
            self.results_list.controlLeft(self.back_button)
            self.results_list.controlUp(self.back_button)
            return
        first = self.action_buttons[0]
        last = self.action_buttons[-1]
        self.back_button.controlDown(first)
        self.back_button.controlRight(first)
        first.controlUp(self.back_button)
        first.controlLeft(self.back_button)
        for index, control in enumerate(self.action_buttons):
            control.controlRight(self.results_list)
            control.controlLeft(self.back_button)
            if index > 0:
                control.controlUp(self.action_buttons[index - 1])
            if index < len(self.action_buttons) - 1:
                control.controlDown(self.action_buttons[index + 1])
            else:
                control.controlDown(self.results_list)
        self.results_list.controlLeft(last)
        self.results_list.controlUp(last)

    def onAction(self, action):
        super(WebcamBrowseWindow, self).onAction(action)
        self.update_preview()

    def load_mode(self, mode, page=1, query='', url=''):
        if mode == 'search' and not query:
            keyboard = xbmc.Keyboard('', 'Search webcams')
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = (keyboard.getText() or '').strip()
            if not query:
                return
        self.mode = mode
        self.page = page
        self.query = query
        self.page_url = url
        result = _with_progress(
            lambda on_progress: api.browse({
                'site': self.site.get('id') or '',
                'mode': mode,
                'page': page,
                'query': query,
                'url': url,
            }, on_progress),
            _load_message(mode),
        )
        if result is None or result.get('cancelled'):
            return
        self.items = result.get('items') or []
        self.list_name = result.get('heading') or mode.upper()
        try:
            self.list_heading.setLabel('[B]%s[/B]' % self.list_name)
        except Exception:
            pass
        self.results_list.reset()
        self.current_index = -1
        if not self.items:
            self.results_list.addItem('Nothing found')
            self.status_label.setLabel('Nothing found.')
            self.title_label.setLabel('[B]Nothing found[/B]')
            self.meta_label.setLabel('')
            self.overview_box.setText('Try another section or search.')
            return
        for item in self.items:
            self.results_list.addItem(_plain(item.get('title') or ''))
        noun = 'sections' if mode in ('places', 'topics', 'sections', 'countries', 'interests') else 'cameras'
        self.status_label.setLabel('%s %s  |  Select one.' % (len(self.items), noun))
        self.update_preview(force=True)
        try:
            self.setFocus(self.results_list)
        except Exception:
            pass

    def _current(self):
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return None
        if index < 0 or index >= len(self.items):
            return None
        return self.items[index]

    def update_preview(self, force=False):
        item = self._current()
        if item is None:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or ''))
        self.meta_label.setLabel(item.get('meta') or '')
        self.overview_box.setText(item.get('overview') or '')
        try:
            self.poster.setImage(_art(item.get('image')))
        except Exception:
            pass

    def select_current(self):
        item = self._current()
        if item is None:
            return
        kind = item.get('kind') or ''
        if kind == 'page':
            self.load_mode(
                item.get('mode') or self.mode,
                page=int(item.get('page') or 1),
                query=item.get('query') or self.query,
                url=item.get('url') or self.page_url,
            )
            return
        if kind == 'category':
            self.load_mode(
                item.get('mode') or 'category',
                query=item.get('query') or '',
                url=item.get('url') or '',
            )
            return
        if kind == 'video':
            _play_item(item)


def _with_progress(func, message):
    holder = {
        'data': None,
        'error': None,
        'done': False,
        'cancel': False,
        'percent': 8,
        'text': message or 'Loading cameras...',
    }

    def on_progress(percent, text):
        try:
            holder['percent'] = max(int(holder.get('percent') or 0), int(percent or 0))
        except (TypeError, ValueError):
            pass
        if text:
            holder['text'] = text
        return bool(holder.get('cancel'))

    def work():
        try:
            holder['data'] = func(on_progress)
        except Exception as exc:
            holder['error'] = exc
        finally:
            holder['done'] = True

    threading.Thread(target=work, daemon=True).start()
    progress = dialogs.Progress()
    started = time.time()
    progress.create(paths.ADDON_NAME, holder['text'])
    shown = None
    while not holder['done']:
        if progress.iscanceled():
            holder['cancel'] = True
            try:
                progress.close()
            except Exception:
                pass
            return None
        elapsed = max(0, int(time.time() - started))
        percent = min(92, int(holder.get('percent') or 8) + min(6, elapsed))
        text = holder.get('text') or message or 'Loading cameras...'
        if elapsed >= 1:
            unit = 'second' if elapsed == 1 else 'seconds'
            text = '%s  |  %s %s' % (text, elapsed, unit)
        key = (percent, text)
        if key != shown:
            shown = key
            progress.update(percent, text)
        xbmc.sleep(200)
    try:
        progress.update(100, 'Ready.')
        progress.close()
    except Exception:
        pass
    if holder.get('cancel'):
        return None
    if holder.get('error') is not None:
        dialogs.ok(paths.ADDON_NAME, 'Could not load that list.\n%s' % holder['error'])
        return None
    return holder.get('data') or {}


def _play_item(item):
    result = _with_progress(
        lambda on_progress: api.resolve(item.get('url') or '', on_progress),
        'Opening the camera...',
    )
    if result is None or result.get('cancelled'):
        return
    streams = result.get('streams') or []
    if not streams:
        dialogs.ok(paths.ADDON_NAME, 'No live stream on that camera.')
        return
    stream = streams[0]
    if len(streams) > 1:
        choice = dialogs.select(
            'Choose a quality',
            [row.get('label') or 'Play' for row in streams],
        )
        if choice < 0 or choice >= len(streams):
            return
        stream = streams[choice]
    title = item.get('title') or 'Webcam'
    if stream.get('audio_url'):
        from resources.lib.gui.documentaries import _adaptive_ready, _mpd_text, _serve_mpd
        if not _adaptive_ready():
            dialogs.ok(
                paths.ADDON_NAME,
                'This quality needs InputStream Adaptive.\nInstall it, then try again.',
            )
            return
        player.play_stream(title, _serve_mpd(_mpd_text(stream)), stream.get('headers') or {})
        return
    player.play_stream(
        title,
        stream.get('url') or '',
        stream.get('headers') or {},
        passthrough=True,
        adaptive=False,
    )
