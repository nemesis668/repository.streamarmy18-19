from __future__ import absolute_import

import struct
import zlib

# White Arial glyphs, codes 32-126, packed left to right. Height is 80.
FONT_HEIGHT = 80
FONT_FIRST = 32
FONT_WIDTHS = (
    22, 26, 31, 44, 44, 65, 51, 20, 29, 29, 33, 45, 26, 29, 26, 26,
    44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 26, 26, 45, 45, 45, 44,
    73, 52, 51, 54, 54, 51, 47, 58, 54, 26, 40, 51, 44, 61, 54, 58,
    51, 58, 54, 51, 47, 54, 51, 68, 51, 51, 47, 26, 26, 26, 38, 46,
    29, 44, 44, 40, 44, 44, 28, 44, 44, 22, 25, 40, 22, 61, 44, 44,
    44, 44, 31, 40, 26, 44, 40, 54, 40, 40, 40, 29, 25, 29, 45,
)
# Keep the words inside the rounded shape. The art has a black margin.
SAFE = (150, 128, 950, 432)
TIME_COLOR = (126, 224, 255)
TITLE_COLOR = (255, 255, 255)


def _paeth(left, up, up_left):
    estimate = left + up - up_left
    nearest = left
    best = abs(estimate - left)
    if abs(estimate - up) < best:
        nearest = up
        best = abs(estimate - up)
    if abs(estimate - up_left) < best:
        nearest = up_left
    return nearest


def decode_rgba(path):
    data = open(path, 'rb').read()
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('Not a PNG')
    index = 8
    width = height = 0
    color_type = 0
    idat = []
    while index < len(data):
        length = struct.unpack('>I', data[index:index + 4])[0]
        kind = data[index + 4:index + 8]
        chunk = data[index + 8:index + 8 + length]
        if kind == b'IHDR':
            width, height, bit, color_type = struct.unpack('>IIBB', chunk[:10])
            if bit != 8 or color_type not in (2, 6):
                raise ValueError('Unsupported PNG')
        elif kind == b'IDAT':
            idat.append(chunk)
        elif kind == b'IEND':
            break
        index += 12 + length
    channels = 4 if color_type == 6 else 3
    stride = width * channels
    raw = zlib.decompress(b''.join(idat))
    rows = []
    cursor = 0
    previous = bytearray(stride)
    for _y in range(height):
        filter_type = raw[cursor]
        cursor += 1
        row = bytearray(raw[cursor:cursor + stride])
        cursor += stride
        if filter_type == 1:
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                row[x] = (row[x] + left) & 255
        elif filter_type == 2:
            for x in range(stride):
                row[x] = (row[x] + previous[x]) & 255
        elif filter_type == 3:
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                row[x] = (row[x] + ((left + previous[x]) // 2)) & 255
        elif filter_type == 4:
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                up_left = previous[x - channels] if x >= channels else 0
                row[x] = (row[x] + _paeth(left, previous[x], up_left)) & 255
        if channels == 3:
            expanded = bytearray(width * 4)
            for x in range(width):
                expanded[x * 4:x * 4 + 3] = row[x * 3:x * 3 + 3]
                expanded[x * 4 + 3] = 255
            row = expanded
        previous = row
        rows.append(row)
    return width, height, rows


def encode_rgba(path, width, height, rows):
    stride = width * 4
    raw = bytearray()
    for row in rows:
        raw.append(0)
        raw.extend(row[:stride])
    compressed = zlib.compress(bytes(raw), 9)
    def chunk(kind, payload):
        body = kind + payload
        return struct.pack('>I', len(payload)) + body + struct.pack('>I', zlib.crc32(body) & 0xFFFFFFFF)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', compressed) + chunk(b'IEND', b'')
    with open(path, 'wb') as handle:
        handle.write(png)


def _glyph_table():
    table = []
    origin = 0
    for width in FONT_WIDTHS:
        table.append((origin, width))
        origin += width
    return table


_GLYPHS = _glyph_table()


def _glyph(char):
    code = ord(char)
    if FONT_FIRST <= code < FONT_FIRST + len(_GLYPHS):
        return _GLYPHS[code - FONT_FIRST]
    return _GLYPHS[0]


def _text_width(text, scale):
    total = 0
    for char in text:
        _origin, width = _glyph(char)
        total += width * scale
    return total


def _wrap(text, scale, max_width):
    words = (text or '').split()
    if not words:
        return []
    lines = []
    current = ''
    for word in words:
        trial = (current + ' ' + word).strip()
        if current and _text_width(trial, scale) > max_width:
            lines.append(current)
            current = word
        else:
            current = trial
    if current:
        lines.append(current)
    return lines


def _fits(title, clock, scale, max_width, max_height):
    line_height = max(10, int(FONT_HEIGHT * scale))
    gap = max(2, int(line_height * 0.16))
    title_lines = _wrap(title, scale, max_width)
    if not title_lines:
        title_lines = ['Live']
    for line in title_lines:
        if _text_width(line, scale) > max_width:
            return None
    if clock and _text_width(clock, scale) > max_width:
        return None
    count = len(title_lines) + (1 if clock else 0)
    block = (count * line_height) + ((count - 1) * gap)
    if block > max_height:
        return None
    return title_lines, line_height, gap, block


def _choose(title, clock, max_width, max_height):
    scale = 0.9
    while scale >= 0.16:
        fitted = _fits(title, clock, scale, max_width, max_height)
        if fitted:
            return scale, fitted
        scale = round(scale - 0.04, 2)
    fitted = _fits(title, clock, 0.16, max_width * 4, max_height * 4)
    if not fitted:
        line_height = max(10, int(FONT_HEIGHT * 0.16))
        return 0.16, (_wrap(title, 0.16, max_width) or ['Live'], line_height, 2, line_height)
    return 0.16, fitted


def _blend(rows, width, x, y, red, green, blue, alpha):
    if x < 0 or y < 0 or x >= width or y >= len(rows) or alpha <= 0:
        return
    row = rows[y]
    index = x * 4
    dest_a = row[index + 3]
    src_a = alpha / 255.0
    dest_af = dest_a / 255.0
    out_a = src_a + dest_af * (1.0 - src_a)
    if out_a <= 0:
        return
    for channel, value in enumerate((red, green, blue)):
        mixed = (value * src_a + row[index + channel] * dest_af * (1.0 - src_a)) / out_a
        row[index + channel] = int(max(0, min(255, mixed)))
    row[index + 3] = int(max(0, min(255, out_a * 255)))


def _sample(font_rows, origin, glyph_w, dx, dest_w, dy, dest_h):
    x0 = origin + int(dx * glyph_w / dest_w)
    x1 = origin + int((dx + 1) * glyph_w / dest_w)
    y0 = int(dy * FONT_HEIGHT / dest_h)
    y1 = int((dy + 1) * FONT_HEIGHT / dest_h)
    if x1 <= x0:
        x1 = x0 + 1
    if y1 <= y0:
        y1 = y0 + 1
    x1 = min(origin + glyph_w, x1)
    y1 = min(FONT_HEIGHT, y1)
    total = 0
    count = 0
    for sy in range(y0, y1):
        source = font_rows[sy]
        for sx in range(x0, x1):
            total += source[sx * 4 + 3]
            count += 1
    if not count:
        return 0
    return total // count


def _paint(rows, width, font_rows, font_width, text, left, top, scale, color):
    cursor = left
    dest_h = max(1, int(FONT_HEIGHT * scale))
    for char in text:
        origin, glyph_w = _glyph(char)
        dest_w = max(1, int(round(glyph_w * scale)))
        for dy in range(dest_h):
            for dx in range(dest_w):
                alpha = _sample(font_rows, origin, glyph_w, dx, dest_w, dy, dest_h)
                if alpha:
                    _blend(rows, width, int(cursor) + dx, top + dy, color[0], color[1], color[2], alpha)
        cursor += glyph_w * scale
    return cursor


def draw_fitted_card(fill_path, font_path, dest, title, clock):
    width, height, rows = decode_rgba(fill_path)
    font_w, _font_h, font_rows = decode_rgba(font_path)
    safe_x, safe_y, safe_right, safe_bottom = SAFE
    max_width = safe_right - safe_x
    max_height = safe_bottom - safe_y
    title = ' '.join((title or 'Live').split()) or 'Live'
    clock = (clock or '').strip()
    scale, fitted = _choose(title, clock, max_width, max_height)
    title_lines, line_height, gap, block = fitted
    y = safe_y + max(0, (max_height - block) // 2)
    if clock:
        used = _text_width(clock, scale)
        _paint(rows, width, font_rows, font_w, clock, safe_x + (max_width - used) / 2.0, int(y), scale, TIME_COLOR)
        y += line_height + gap
    for line in title_lines:
        used = _text_width(line, scale)
        _paint(rows, width, font_rows, font_w, line, safe_x + (max_width - used) / 2.0, int(y), scale, TITLE_COLOR)
        y += line_height + gap
    encode_rgba(dest, width, height, rows)
    return dest
