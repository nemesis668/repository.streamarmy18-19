from __future__ import absolute_import

import os
import threading
import time

import pyxbmct
import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.gui.buttons import text_button


_BACK_ACTIONS = (9, 10, 92)


def ok(heading, message='', *lines):
    text = _message(message, lines)
    try:
        window = _MessageWindow(heading, text, (('OK', True),))
        window.doModal()
        del window
    except Exception:
        xbmcgui.Dialog().ok(heading, text)


def yesno(heading, message='', nolabel='No', yeslabel='Yes', **_unused):
    try:
        window = _MessageWindow(
            heading,
            _message(message, ()),
            ((nolabel or 'No', False), (yeslabel or 'Yes', True)),
            focus_last=False
        )
        window.doModal()
        result = window.result
        del window
        return bool(result)
    except Exception:
        return xbmcgui.Dialog().yesno(
            heading,
            _message(message, ()),
            nolabel=nolabel or 'No',
            yeslabel=yeslabel or 'Yes'
        )


def busy(func, message):
    """Run func on a worker and keep the progress dialog moving until it finishes.

    Returns (data, error, canceled).
    """
    holder = {'data': None, 'error': None, 'done': False}

    def worker():
        try:
            holder['data'] = func()
        except Exception as exc:
            holder['error'] = exc
        except SystemExit as exc:
            holder['error'] = exc
        finally:
            holder['done'] = True

    threading.Thread(target=worker, daemon=True).start()
    progress = Progress()
    started = time.time()
    progress.create(paths.ADDON_NAME, message or 'Working...')
    shown = None
    while not holder['done']:
        if progress.iscanceled():
            try:
                progress.close()
            except Exception:
                pass
            return None, None, True
        elapsed = max(0, int(time.time() - started))
        percent = min(92, 8 + (elapsed * 6))
        text = message or 'Working...'
        if elapsed >= 1:
            unit = 'second' if elapsed == 1 else 'seconds'
            text = '%s  |  %s %s' % (text, elapsed, unit)
        key = (percent, text)
        if key != shown:
            shown = key
            progress.update(percent, text)
        xbmc.sleep(200)
    try:
        progress.update(100, message or 'Done.')
        progress.close()
    except Exception:
        pass
    return holder['data'], holder['error'], False


def select(heading, options):
    choices = [str(item) for item in (options or [])]
    if not choices:
        return -1
    try:
        window = _SelectWindow(heading, choices)
        window.doModal()
        result = window.result
        del window
        return result
    except Exception:
        return xbmcgui.Dialog().select(heading, choices)


class Progress(object):
    def __init__(self):
        self._window = None
        self._fallback = None
        self._canceled = False

    def create(self, heading, message=''):
        self.close()
        self._canceled = False
        try:
            self._window = _ProgressWindow(str(heading or ''), str(message or ''), self)
            self._window._focus = None
            self._window.show()
            try:
                self._window.set_progress(8, message)
            except Exception:
                pass
            xbmc.sleep(1000)
            self._window._clicks_live = True
            self._window._focus = self._window.cancel_button
            self._window._apply_focus()
        except Exception:
            self._window = None
            self._fallback = xbmcgui.DialogProgress()
            self._fallback.create(heading, message)

    def update(self, percent, message=''):
        if self._fallback is not None:
            try:
                self._fallback.update(int(percent or 0), message or '')
            except Exception:
                pass
            return
        window = self._window
        if window is None:
            return
        try:
            window.set_progress(percent, message)
        except Exception:
            pass

    def iscanceled(self):
        if self._fallback is not None:
            try:
                return self._fallback.iscanceled()
            except Exception:
                return self._canceled
        return self._canceled

    def close(self):
        window = self._window
        self._window = None
        if window is not None:
            try:
                window.close()
            except Exception:
                pass
        if self._fallback is not None:
            try:
                self._fallback.close()
            except Exception:
                pass
            self._fallback = None


def _ignore_focus(control):
    try:
        control.setEnabled(False)
    except Exception:
        pass


def _message(message, lines):
    parts = [str(message or '')]
    parts.extend(str(line) for line in lines if line)
    return '\n'.join(part for part in parts if part)


class _StyledDialog(pyxbmct.BlankDialogWindow):
    def __init__(self, width, height):
        super(_StyledDialog, self).__init__()
        self.setGeometry(width, height, 100, 100)
        image = paths.DIALOG_BG_PATH if os.path.exists(paths.DIALOG_BG_PATH) else paths.BACKDROP_PATH
        self.backdrop = pyxbmct.Image(image)
        self.placeControl(self.backdrop, 0, 0, 100, 100, pad_x=0, pad_y=0)
        try:
            self.backdrop.setColorDiffuse(paths.DIALOG_BG_DIFFUSE)
        except Exception:
            pass
        _ignore_focus(self.backdrop)
        self.frame = None
        if os.path.exists(paths.DIALOG_FRAME_PATH):
            self.frame = pyxbmct.Image(paths.DIALOG_FRAME_PATH)
            self.placeControl(self.frame, 0, 0, 100, 100, pad_x=0, pad_y=0)
            _ignore_focus(self.frame)
        self._focus = None
        self._open = False
        self._clicks_live = False

    def _apply_focus(self):
        control = self._focus
        if control is None:
            return
        try:
            control_id = control.getId()
        except Exception:
            return
        if not control_id:
            return
        try:
            self.setFocus(control)
        except Exception:
            pass

    def show(self):
        self._open = True
        super(_StyledDialog, self).show()
        self._apply_focus()

    def doModal(self):
        self._open = True
        self._clicks_live = False
        super(_StyledDialog, self).show()
        self._apply_focus()
        xbmc.sleep(200)
        self._clicks_live = True
        try:
            super(_StyledDialog, self).doModal()
        finally:
            self._open = False

    def close(self):
        self._open = False
        super(_StyledDialog, self).close()

    def onInit(self):
        self._apply_focus()

    def onControl(self, control):
        if not self._clicks_live:
            return
        super(_StyledDialog, self).onControl(control)

    def _add_title(self, heading, row=6, height=12):
        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % (heading or paths.ADDON_NAME),
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_CENTER
        )
        self.placeControl(self.title_label, row, 6, height, 88)

    def onAction(self, action):
        try:
            self.getFocus()
        except Exception:
            self._apply_focus()
        if action.getId() in _BACK_ACTIONS:
            self.close()
            return
        super(_StyledDialog, self).onAction(action)


class _MessageWindow(_StyledDialog):
    def __init__(self, heading, message, buttons, focus_last=True):
        super(_MessageWindow, self).__init__(920, 420)
        self.result = False
        self._buttons = []
        self._add_title(heading)
        self.body = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.body, 24, 8, 40, 84)
        self.body.setText(message or '')
        count = len(buttons)
        width = 28
        gap = 6
        total = count * width + (count - 1) * gap
        start = max(4, (100 - total) // 2)
        for index, (label, value) in enumerate(buttons):
            button = text_button(label)
            column = start + index * (width + gap)
            self.placeControl(button, 70, column, 14, width)
            self.connect(button, lambda value=value: self._choose(value))
            self._buttons.append(button)
        for index, button in enumerate(self._buttons):
            left = self._buttons[index - 1] if index else button
            right = self._buttons[index + 1] if index + 1 < count else button
            button.controlLeft(left)
            button.controlRight(right)
            button.controlUp(button)
            button.controlDown(button)
        self._focus = self._buttons[-1] if focus_last and self._buttons else (self._buttons[0] if self._buttons else None)
        if self._buttons:
            self.body.controlDown(self._buttons[0])
            self.body.controlUp(self._buttons[0])

    def _choose(self, value):
        self.result = value
        self.close()


class _SelectWindow(_StyledDialog):
    def __init__(self, heading, options):
        super(_SelectWindow, self).__init__(920, 560)
        self.result = -1
        self._add_title(heading, row=4, height=10)
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 16, 8, 60, 84)
        for option in options:
            self.list_control.addItem(option)
        self.cancel_button = text_button('Cancel')
        self.placeControl(self.cancel_button, 80, 36, 12, 28)
        self.connect(self.list_control, self._choose)
        self.connect(self.cancel_button, self.close)
        self.list_control.controlDown(self.cancel_button)
        self.list_control.controlUp(self.list_control)
        self.cancel_button.controlUp(self.list_control)
        self.cancel_button.controlDown(self.cancel_button)
        self.list_control.controlLeft(self.list_control)
        self.list_control.controlRight(self.list_control)
        try:
            self.list_control.selectItem(0)
        except Exception:
            pass
        self._focus = self.list_control

    def _choose(self):
        self.result = self.list_control.getSelectedPosition()
        self.close()


class _ProgressWindow(_StyledDialog):
    def __init__(self, heading, message, owner):
        super(_ProgressWindow, self).__init__(920, 340)
        self.owner = owner
        self._add_title(heading, row=8, height=14)
        self.message_label = pyxbmct.Label(
            message,
            font='font13',
            textColor='0xFFE8EEF4',
            alignment=pyxbmct.ALIGN_CENTER
        )
        self.placeControl(self.message_label, 28, 8, 14, 84)
        self.percent_label = pyxbmct.Label(
            '0%',
            font='font13',
            textColor='0xFF7EE0FF',
            alignment=pyxbmct.ALIGN_CENTER
        )
        self.placeControl(self.percent_label, 44, 8, 10, 84)
        self.bar_x = self.x + 90
        self.bar_y = self.y + 168
        self.bar_width = self.width - 180
        self.bar_height = 20
        self.track = xbmcgui.ControlImage(
            self.bar_x, self.bar_y, self.bar_width, self.bar_height, paths.PROGRESS_TRACK_PATH
        )
        self.addControl(self.track)
        _ignore_focus(self.track)
        cap = self.bar_height
        self.fill_left = xbmcgui.ControlImage(
            self.bar_x, self.bar_y, cap, self.bar_height, paths.PROGRESS_LEFT_PATH
        )
        self.fill_mid = xbmcgui.ControlImage(
            self.bar_x + cap, self.bar_y, 1, self.bar_height, paths.PROGRESS_MID_PATH
        )
        self.fill_right = xbmcgui.ControlImage(
            self.bar_x + cap, self.bar_y, cap, self.bar_height, paths.PROGRESS_RIGHT_PATH
        )
        for piece in (self.fill_left, self.fill_mid, self.fill_right):
            self.addControl(piece)
            _ignore_focus(piece)
            piece.setVisible(False)
        self.cancel_button = text_button('Cancel')
        self.placeControl(self.cancel_button, 68, 36, 16, 28)
        self.connect(self.cancel_button, self._cancel)
        self.cancel_button.controlUp(self.cancel_button)
        self.cancel_button.controlDown(self.cancel_button)
        self.cancel_button.controlLeft(self.cancel_button)
        self.cancel_button.controlRight(self.cancel_button)
        self._focus = None
        self._shown_percent = None
        self._shown_message = None

    def onInit(self):
        return

    def _cancel(self):
        if not self._clicks_live:
            return
        self.owner._canceled = True
        self.close()

    def onAction(self, action):
        if not self._clicks_live:
            return
        if action.getId() in _BACK_ACTIONS:
            self._cancel()
            return
        super(_ProgressWindow, self).onAction(action)

    def set_progress(self, percent, message):
        try:
            percent = int(percent or 0)
        except Exception:
            percent = 0
        if percent < 0:
            percent = 0
        if percent > 100:
            percent = 100
        text = str(message or '')
        if percent == self._shown_percent and text == self._shown_message:
            return
        percent_changed = percent != self._shown_percent
        self._shown_percent = percent
        self._shown_message = text
        if percent_changed:
            try:
                self.percent_label.setLabel('%s%%' % percent)
            except Exception:
                pass
            try:
                self._place_fill(percent)
            except Exception:
                pass
        if text:
            try:
                self.message_label.setLabel(text)
            except Exception:
                pass

    def _place_fill(self, percent):
        fill_w = int(self.bar_width * percent / 100.0)
        cap = self.bar_height
        pieces = (self.fill_left, self.fill_mid, self.fill_right)
        if fill_w < 2:
            for piece in pieces:
                piece.setVisible(False)
            return
        self.fill_left.setVisible(True)
        self.fill_left.setPosition(self.bar_x, self.bar_y)
        self.fill_left.setHeight(self.bar_height)
        if fill_w <= cap * 2:
            self.fill_left.setWidth(fill_w)
            self.fill_mid.setVisible(False)
            self.fill_right.setVisible(False)
            return
        self.fill_left.setWidth(cap)
        self.fill_mid.setVisible(True)
        self.fill_mid.setPosition(self.bar_x + cap, self.bar_y)
        self.fill_mid.setWidth(fill_w - (cap * 2))
        self.fill_mid.setHeight(self.bar_height)
        self.fill_right.setVisible(True)
        self.fill_right.setPosition(self.bar_x + fill_w - cap, self.bar_y)
        self.fill_right.setWidth(cap)
        self.fill_right.setHeight(self.bar_height)

