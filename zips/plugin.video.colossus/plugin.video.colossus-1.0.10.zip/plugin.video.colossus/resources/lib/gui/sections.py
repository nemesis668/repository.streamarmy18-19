from __future__ import absolute_import

import pyxbmct
import xbmcgui

from resources.lib.core import paths
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.buttons import text_button


SECTION_DESCRIPTIONS = {
    'IPTV': 'IPTV will be added here.',
    'Misc': 'Extra tools and lists will be added here.',
}


class SectionWindow(ColossusFullWindow):
    def __init__(self, section_name):
        super(SectionWindow, self).__init__('')
        self.section_name = section_name
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.setFocus(self.back_button)

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH)
        description = SECTION_DESCRIPTIONS.get(
            self.section_name,
            'This section will be added here.'
        )
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)

        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % self.section_name.upper(),
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.title_label, 14, 8, 10, 80)

        self.description_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.description_box, 28, 8, 16, 80)
        self.description_box.setText(description)

    def set_navigation(self):
        self.back_button.controlUp(self.back_button)
        self.back_button.controlDown(self.back_button)
        self.back_button.controlLeft(self.back_button)
        self.back_button.controlRight(self.back_button)


def open_section(section_name):
    if section_name == 'Sports':
        try:
            from resources.lib.gui.sports import open_sports
            open_sports()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'Sports failed to open.\n%s' % exc)
        return

    if section_name == 'Music':
        try:
            from resources.lib.gui.music import open_music
            open_music()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'Music failed to open.\n%s' % exc)
        return

    if section_name == 'Movies & Shows':
        from resources.lib.gui.movies import open_movies_window
        open_movies_window()
        return

    if section_name == 'XXX':
        try:
            from resources.lib.gui.adult import open_xxx
            open_xxx()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'Adult section failed to open.\n%s' % exc)
        return

    if section_name == 'Cartoons & Anime':
        try:
            from resources.lib.gui.anime import open_anime
            open_anime()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'Anime failed to open.\n%s' % exc)
        return

    if section_name == 'Community Lists':
        try:
            from resources.lib.gui.community import open_community
            open_community()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'Community Lists failed to open.\n%s' % exc)
        return

    if section_name == 'IPTV':
        try:
            from resources.lib.gui.iptv import open_iptv
            open_iptv()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'IPTV failed to open.\n%s' % exc)
        return

    if section_name == 'Misc':
        try:
            from resources.lib.gui.misc import open_misc
            open_misc()
        except Exception as exc:
            dialogs.ok(paths.ADDON_NAME, 'Misc failed to open.\n%s' % exc)
        return

    window = SectionWindow(section_name)
    window.doModal()
    del window
