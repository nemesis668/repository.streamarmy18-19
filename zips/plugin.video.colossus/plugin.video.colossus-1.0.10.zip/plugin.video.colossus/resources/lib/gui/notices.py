from __future__ import absolute_import

import json
import os
import re
import threading
import time
from urllib.request import Request, urlopen

import pyxbmct
import xbmc

from resources.lib.core import paths
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.buttons import text_button


REPO_XML = 'https://raw.githubusercontent.com/nemesis668/repository.streamarmy18-19/main/addons.xml'
NEWS_URL = 'https://nemzzy.info/colossus/whatsnew'
SEEN_PATH = os.path.join(paths.PROFILE_PATH, 'whats_new_seen')
_VERSION_TAG = re.compile(
    r'<addon\b(?=[^>]*\bid="plugin\.video\.colossus")(?=[^>]*\bversion="([^"]+)")[^>]*>',
    re.I,
)
_STATE = {'ready': False, 'outdated': False, 'announce': False, 'news': ''}


def _version_parts(value):
    parts = []
    for piece in str(value or '').split('.'):
        number = ''
        for char in piece:
            if char.isdigit():
                number += char
            else:
                break
        parts.append(int(number or 0))
    return parts


def _older(local_version, remote_version):
    left = _version_parts(local_version)
    right = _version_parts(remote_version)
    length = max(len(left), len(right))
    left.extend([0] * (length - len(left)))
    right.extend([0] * (length - len(right)))
    return left < right


def _read(url, timeout):
    request = Request(url, headers={'User-Agent': 'Colossus'})
    response = urlopen(request, timeout=timeout)
    try:
        return response.read().decode('utf-8', 'replace')
    finally:
        response.close()


def _published_version():
    text = _read(REPO_XML, 12)
    match = _VERSION_TAG.search(text or '')
    if not match:
        return ''
    return match.group(1).strip()


def _published_news():
    raw = _read(NEWS_URL, 12)
    data = json.loads(raw or '{}')
    if not isinstance(data, dict):
        return '', ''
    version = str(data.get('version') or '').strip()
    message = str(data.get('message') or '').replace('\\n', '\n').strip()
    return version, message


def _seen_version():
    try:
        with open(SEEN_PATH, 'r', encoding='utf-8') as handle:
            return handle.read().strip()
    except Exception:
        return ''


def _mark_seen(version):
    try:
        folder = os.path.dirname(SEEN_PATH)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(SEEN_PATH, 'w', encoding='utf-8') as handle:
            handle.write(version or '')
    except Exception:
        pass


def _collect():
    holder = {'version': '', 'news_version': '', 'news': ''}

    def published():
        try:
            holder['version'] = _published_version()
        except Exception:
            holder['version'] = ''

    def news():
        try:
            holder['news_version'], holder['news'] = _published_news()
        except Exception:
            holder['news_version'] = ''
            holder['news'] = ''

    workers = (
        threading.Thread(target=published),
        threading.Thread(target=news),
    )
    for worker in workers:
        worker.daemon = True
        worker.start()
    deadline = time.time() + 12
    while time.time() < deadline:
        if not any(worker.is_alive() for worker in workers):
            break
        xbmc.sleep(100)
    return holder


def apply_version_label(window):
    version = paths.ADDON.getAddonInfo('version') or ''
    if _STATE.get('outdated'):
        text = 'Version %s    Addon is out of date' % version
    else:
        text = 'Version %s' % version
    try:
        window.version_label.setLabel(text)
    except Exception:
        pass


def present(window):
    if not _STATE['ready']:
        installed = paths.ADDON.getAddonInfo('version') or ''
        info = _collect()
        published = info.get('version') or ''
        _STATE['outdated'] = bool(published) and _older(installed, published)
        news_version = info.get('news_version') or ''
        news = info.get('news') or ''
        _STATE['news'] = news if news_version == installed and news and _seen_version() != installed else ''
        _STATE['announce'] = True
        _STATE['ready'] = True
    apply_version_label(window)
    if not _STATE.get('announce'):
        return
    _STATE['announce'] = False
    if _STATE.get('outdated'):
        popup = UpdateWindow()
        popup.doModal()
        del popup
    if _STATE.get('news'):
        popup = WhatsNewWindow(_STATE['news'])
        popup.doModal()
        del popup
        _mark_seen(paths.ADDON.getAddonInfo('version') or '')
        _STATE['news'] = ''


def _backdrop():
    if os.path.exists(paths.BACKDROP2_PATH):
        return paths.BACKDROP2_PATH
    return paths.BACKDROP_PATH or paths.FANART_PATH


class _NoticeWindow(ColossusFullWindow):
    def __init__(self):
        super(_NoticeWindow, self).__init__('')
        self.setup_canvas()
        self.add_fanart(_backdrop())

    def add_icon(self):
        self.icon = pyxbmct.Image(paths.ICON_PATH, aspectRatio=2)
        self.placeControl(self.icon, 6, 45, 14, 10, pad_x=0, pad_y=0)

    def add_heading(self, title, row):
        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % title,
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_CENTER,
        )
        self.placeControl(self.title_label, row, 8, 8, 84, pad_x=0, pad_y=0)

    def add_line(self, text, row, text_color='0xFF7EE0FF', height=6):
        label = pyxbmct.Label(
            text,
            font='font13',
            textColor=text_color,
            alignment=pyxbmct.ALIGN_CENTER,
        )
        self.placeControl(label, row, 8, height, 84, pad_x=0, pad_y=0)
        return label

    def add_close(self, row):
        self.close_button = text_button('Close')
        self.placeControl(self.close_button, row, 42, 8, 16, pad_x=0, pad_y=0)
        self.connect(self.close_button, self.close)
        self.close_button.controlUp(self.close_button)
        self.close_button.controlDown(self.close_button)
        self.close_button.controlLeft(self.close_button)
        self.close_button.controlRight(self.close_button)
        self.setFocus(self.close_button)


class WhatsNewWindow(_NoticeWindow):
    def __init__(self, message):
        super(WhatsNewWindow, self).__init__()
        self.add_icon()
        self.add_heading("WHAT'S NEW", 22)
        self.add_line('New in this version', 31)
        self.message_box = pyxbmct.TextBox(font='font13', textColor='0xFFFFFFFF')
        self.placeControl(self.message_box, 40, 18, 38, 64, pad_x=0, pad_y=0)
        self.message_box.setText(message or '')
        try:
            self.message_box.autoScroll(2500, 2800, 4000)
        except Exception:
            pass
        self.add_close(86)


class SupportWindow(_NoticeWindow):
    def __init__(self):
        super(SupportWindow, self).__init__()
        self.add_icon()
        self.add_heading('SUPPORT', 22)
        qr_path = paths.TELEGRAM_QR_PATH if os.path.exists(paths.TELEGRAM_QR_PATH) else paths.ICON_PATH
        self.qr_image = pyxbmct.Image(qr_path, aspectRatio=2)
        self.placeControl(self.qr_image, 32, 38, 40, 24, pad_x=0, pad_y=0)
        self.add_line('[B]Scan the QR code to join our Telegram group.[/B]', 76)
        self.add_close(86)


class UpdateWindow(_NoticeWindow):
    def __init__(self):
        super(UpdateWindow, self).__init__()
        self.add_icon()
        self.add_heading('UPDATE', 28)
        self.add_line(
            '[B]Your Addon is out of date, please update[/B]',
            42,
            text_color='0xFFFFFFFF',
            height=8,
        )
        self.add_line('Install the latest version, then open Colossus again.', 52)
        self.add_close(68)


def open_support():
    window = SupportWindow()
    window.doModal()
    del window
