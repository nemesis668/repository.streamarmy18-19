from __future__ import absolute_import

import re
import threading
from datetime import datetime
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

import xbmc

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.core import remote
from resources.lib.gui import dialogs
from resources.lib.gui.sports import SportsBrowseWindow


def open_iptv():
    rows = _call('sources', {}, 'Loading IPTV...')
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'No IPTV sources are available.')
        return
    items = [_source_item(row) for row in rows]

    def choose(item):
        if item.get('channel_id'):
            _play(item)
            return
        _open_categories(item['source_id'], item['title'])

    _browse(
        'IPTV',
        'Sources',
        items,
        choose,
        'IPTV',
        'Choose a source',
        'Sources are supplied by Colossus. New ones show up here without an addon update.',
        allow_search=True,
        search_heading='Search all sources',
        search_source=_search_all,
        search_list_heading='CHANNELS'
    )


def _open_categories(source_id, source_name):
    rows = _call('categories', {'source_id': source_id}, 'Loading categories...')
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'No categories were found.')
        return
    items = [_category_item(source_id, row) for row in rows]

    def choose(item):
        if item.get('channel_id'):
            _play(item)
            return
        _open_channels(item['source_id'], item['category_id'], item['title'])

    _browse(
        source_name,
        'Categories',
        items,
        choose,
        source_name,
        'Choose a category',
        'Pick a category to see the channels in it.',
        allow_search=True,
        search_heading='Search channels' if source_id == 'guide' else 'Search categories',
        search_source=_search_guide if source_id == 'guide' else None,
        search_list_heading='CHANNELS' if source_id == 'guide' else 'CATEGORIES'
    )


def _open_channels(source_id, category_id, category_name):
    rows = _call(
        'channels',
        {'source_id': source_id, 'category_id': category_id},
        'Loading channels...'
    )
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'No channels were found.')
        return
    items = [_channel_item(source_id, row) for row in rows]

    def choose(item):
        _play(item)

    _browse(
        category_name,
        'Channels',
        items,
        choose,
        category_name,
        'Choose a channel',
        'Select a channel to play it.',
        allow_search=True,
        search_heading='Search channels'
    )


def _play(item):
    result = _call(
        'play',
        {'source_id': item['source_id'], 'channel_id': item['channel_id']},
        'Opening channel...'
    )
    if not result:
        return
    url = result.get('url') or ''
    streams = result.get('streams') or []
    if url and url not in streams:
        streams.insert(0, url)
    if not url and not streams:
        dialogs.ok(paths.ADDON_NAME, 'That channel did not return a stream.')
        return
    headers = result.get('headers') or {}
    options = _quality_choices(streams or [url], headers)
    if options is None:
        return
    if not options:
        dialogs.ok(
            paths.ADDON_NAME,
            'That channel did not start.\nThe stream is blocked or the link is no longer online.'
        )
        return
    title = result.get('title') or item.get('title') or 'Channel'
    if len(options) == 1:
        outcome = player.play_stream(title, options[0]['url'], headers)
        if outcome is not False:
            player.wait_until_playback_ends(outcome)
        return
    labels = [item['label'] for item in options]
    while True:
        choice = dialogs.select('Choose quality', labels)
        if choice < 0 or choice >= len(options):
            return
        outcome = player.play_stream(title, options[choice]['url'], headers)
        if outcome is False:
            continue
        player.wait_until_playback_ends(outcome)


def _quality_choices(urls, headers):
    progress = dialogs.Progress()
    progress.create(paths.ADDON_NAME, 'Checking quality...')
    holder = {'options': [], 'done': False}

    def worker():
        try:
            holder['options'] = _quality_options(urls, headers)
        except Exception:
            holder['options'] = []
        holder['done'] = True

    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
    while not holder['done']:
        if progress.iscanceled():
            try:
                progress.close()
            except Exception:
                pass
            return None
        xbmc.sleep(80)
    try:
        progress.close()
    except Exception:
        pass
    return holder['options'] or []


def _quality_options(urls, headers):
    found = []
    seen = set()
    for raw in urls:
        url = _open_stream(raw, headers)
        if not url or url in seen:
            continue
        seen.add(url)
        path = url.lower().split('?', 1)[0]
        if path.endswith('.mpd') or '.mpd' in path:
            found.append({'url': url, 'width': 0, 'height': 1, 'bandwidth': 1})
            continue
        playlist, base_url = _fetch_playlist(url, headers)
        variants = _hls_variants(playlist, base_url)
        if variants:
            found.extend(variants)
            continue
        if playlist and '#EXTM3U' in playlist:
            found.append({'url': url, 'width': 0, 'height': 0, 'bandwidth': 0})
    ranked = [item for item in found if item['height'] or item['bandwidth']]
    if ranked:
        found = ranked
    elif len(found) < 2:
        return found
    else:
        return []
    best = {}
    for item in found:
        key = (item['width'], item['height'], item['bandwidth'])
        current = best.get(key)
        if current is None or item['bandwidth'] > current['bandwidth']:
            best[key] = item
    options = list(best.values())
    options.sort(key=lambda item: (item['height'], item['bandwidth']), reverse=True)
    heights = {}
    for item in options:
        heights[item['height']] = heights.get(item['height'], 0) + 1
    for item in options:
        item['label'] = _quality_label(item, heights.get(item['height'], 0) > 1)
    return options


def _quality_label(item, crowded):
    path = (item.get('url') or '').lower().split('?', 1)[0]
    if path.endswith('.mpd') or '.mpd' in path:
        return 'DASH'
    height = item['height']
    bandwidth = item['bandwidth']
    if height and crowded:
        label = '%sx%s' % (item['width'], height)
    elif height:
        label = '%sp' % height
    elif bandwidth:
        label = '%s Mbps' % max(1, int(round(bandwidth / 1000000.0)))
    else:
        label = 'Standard'
    if height and bandwidth and crowded:
        label = '%s · %s Mbps' % (label, max(1, int(round(bandwidth / 1000000.0))))
    return label


def _hls_variants(playlist, base_url):
    if not playlist or '#EXT-X-STREAM-INF' not in playlist:
        return []
    variants = []
    pending = None
    for raw in playlist.splitlines():
        line = raw.strip()
        if line.startswith('#EXT-X-STREAM-INF'):
            pending = line
            continue
        if pending is None or not line or line.startswith('#'):
            continue
        resolution = re.search(r'RESOLUTION=(\d+)x(\d+)', pending, re.I)
        bandwidth = re.search(r'BANDWIDTH=(\d+)', pending, re.I)
        pending = None
        if resolution is None:
            continue
        variants.append({
            'url': _join_variant(base_url, line),
            'width': int(resolution.group(1)),
            'height': int(resolution.group(2)),
            'bandwidth': int(bandwidth.group(1)) if bandwidth else 0,
        })
    return variants


def _join_variant(base_url, uri):
    joined = urljoin(base_url, uri)
    base = urlparse(base_url)
    target = urlparse(joined)
    if base.query and not target.query:
        joined = '%s?%s' % (joined, base.query)
    return joined


def _open_stream(url, headers):
    """Follow the link and keep it only when it is a real stream."""
    url = str(url or '').strip()
    if not url.lower().startswith(('http://', 'https://')):
        return ''
    request_headers = {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
        ),
        'Accept': '*/*',
    }
    for key, value in (headers or {}).items():
        if value:
            request_headers[str(key)] = str(value)
    request = Request(url, headers=request_headers)
    try:
        response = urlopen(request, timeout=8)
        try:
            final = response.geturl() or url
            sample = response.read(12000)
            try:
                content_type = (response.headers.get('Content-Type') or '').lower()
            except Exception:
                content_type = ''
        finally:
            response.close()
    except Exception:
        return ''
    text = sample.decode('utf-8', 'ignore').lstrip().lower()
    if text.startswith('<!doctype html') or text.startswith('<html') or 'site suspended' in text:
        return ''
    path = (final or url).lower().split('?', 1)[0]
    if '#extm3u' in text or '.m3u8' in path or 'mpegurl' in content_type:
        return final
    if '<mpd' in text or path.endswith('.mpd') or '.mpd' in path or 'dash+xml' in content_type:
        return final
    if path.endswith(('.mp4', '.ts', '.mkv', '.m4v')) or content_type.startswith('video/'):
        return final
    return ''


def _fetch_playlist(url, headers):
    lowered = url.lower().split('?', 1)[0]
    if not lowered.endswith('.m3u8') and '.m3u8' not in lowered:
        return '', url
    request_headers = {
        'User-Agent': 'Mozilla/5.0',
        'Accept': '*/*',
    }
    for key, value in (headers or {}).items():
        if value:
            request_headers[str(key)] = str(value)
    request = Request(url, headers=request_headers)
    try:
        response = urlopen(request, timeout=8)
        try:
            # Follow the redirect. Source 4 answers on a different host, and
            # the quality paths in the playlist only exist on that host.
            final = response.geturl() or url
            return response.read(250000).decode('utf-8', 'ignore'), final
        finally:
            response.close()
    except Exception:
        return '', url


def _call(name, kwargs, message):
    progress = dialogs.Progress()
    progress.create(paths.ADDON_NAME, message)
    holder = {
        'data': None,
        'error': None,
        'done': False,
        'percent': 0,
        'text': message,
        'cancel': False,
    }

    def on_progress(percent, text):
        try:
            holder['percent'] = int(percent or 0)
        except Exception:
            holder['percent'] = 0
        if text:
            holder['text'] = text
        return holder['cancel']

    def worker():
        try:
            holder['data'] = remote.call('iptv', name, kwargs=kwargs, on_progress=on_progress)
        except Exception as exc:
            holder['error'] = exc
        holder['done'] = True

    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
    while not holder['done']:
        if progress.iscanceled():
            holder['cancel'] = True
            try:
                progress.close()
            except Exception:
                pass
            return None
        try:
            progress.update(holder['percent'], holder['text'])
        except Exception:
            pass
        xbmc.sleep(80)
    try:
        progress.close()
    except Exception:
        pass
    if holder['cancel']:
        return None
    if holder['error'] is not None:
        dialogs.ok(paths.ADDON_NAME, 'Request failed.\n%s' % holder['error'])
        return None
    return holder['data']


def _search_all(query):
    rows = _call('search', {'query': query}, 'Searching sources...')
    if rows is None:
        return None
    return [_search_item(row) for row in rows]


def _search_guide(query):
    rows = _call('search', {'query': query, 'source_id': 'guide'}, 'Searching Source 4...')
    if rows is None:
        return None
    return [_search_item(row) for row in rows]


def _search_item(row):
    source_name = row.get('source_name') or 'Source'
    category = row.get('category') or ''
    name = row.get('name') or 'Channel'
    now = row.get('now') or ''
    guide = _guide_text(now, row.get('upcoming') or [])
    return {
        'label': '%s    %s' % (name, source_name),
        'title': name,
        'meta': '%s  |  %s' % (source_name, now or category),
        'overview': guide or 'Select to play this channel.',
        'image': row.get('logo') or '',
        'source_id': row.get('source_id') or '',
        'channel_id': row.get('id') or '',
    }


def _browse(heading, list_heading, items, on_select, empty_title, empty_meta, empty_overview, allow_search=False, search_heading='Search', search_source=None, search_list_heading='CHANNELS'):
    window = _IptvWindow(
        heading=heading,
        status_text='%s %s' % (len(items), list_heading.lower()),
        items=items,
        on_select=on_select,
        art_path=paths.IPTV_BUTTON_PATH,
        empty_title=empty_title,
        empty_meta=empty_meta,
        empty_overview=empty_overview,
        allow_search=allow_search,
        search_heading=search_heading,
        search_source=search_source,
        search_list_heading=search_list_heading,
        list_heading=list_heading.upper()
    )
    window.doModal()
    del window


def _source_item(row):
    return {
        'label': row.get('name') or 'Source',
        'title': row.get('name') or 'Source',
        'meta': 'Source',
        'overview': 'Open this source to browse its categories.',
        'source_id': row.get('id') or '',
    }


def _category_item(source_id, row):
    count = int(row.get('count') or 0)
    label = '%s    %s' % (row.get('name') or 'Category', count)
    return {
        'label': label,
        'title': row.get('name') or 'Category',
        'meta': '%s channels' % count,
        'overview': 'Open this category to see its channels.',
        'source_id': source_id,
        'category_id': row.get('id') or '',
    }


def _channel_item(source_id, row):
    name = row.get('name') or 'Channel'
    now = row.get('now') or ''
    guide = _guide_text(row.get('now') or '', row.get('upcoming') or [])
    return {
        'label': '%s    %s' % (name, now) if now else name,
        'title': name,
        'meta': now or 'Channel',
        'overview': guide or 'Select to play this channel.',
        'image': row.get('logo') or '',
        'source_id': source_id,
        'channel_id': row.get('id') or '',
    }


def _guide_text(now, upcoming):
    lines = []
    if now:
        lines.append('Now: %s' % now)
    for item in upcoming or []:
        if not isinstance(item, dict):
            continue
        title = item.get('title') or ''
        if not title:
            continue
        clock = _local_clock(item.get('start') or '')
        lines.append('%s  %s' % (clock, title) if clock else title)
        if len(lines) >= 6:
            break
    return '\n'.join(lines)


def _local_clock(value):
    text = str(value or '').strip().replace('Z', '+00:00')
    if not text:
        return ''
    try:
        moment = datetime.fromisoformat(text)
    except Exception:
        return ''
    try:
        return moment.astimezone().strftime('%H:%M')
    except Exception:
        return ''


class _IptvWindow(SportsBrowseWindow):
    def update_preview(self, force=False):
        super(_IptvWindow, self).update_preview(force=force)
        if not self.visible_items or self.current_index < 0:
            return
        if self.current_index >= len(self.visible_items):
            return
        item = self.visible_items[self.current_index]
        image = item.get('image') or self.art_path
        try:
            self.poster.setImage(image)
        except Exception:
            pass
