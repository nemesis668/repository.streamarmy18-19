from __future__ import absolute_import

import random

import xbmcgui
import xbmc

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.core.remote import RemoteError, call
from resources.lib.gui import dialogs


USER_AGENTS = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 '
    '(KHTML, like Gecko) Version/18.1 Safari/605.1.15',
)

def random_headers(extra_headers=None):
    headers = {
        'User-Agent': random.choice(USER_AGENTS),
        'Accept': '*/*',
    }

    if extra_headers:
        headers.update(extra_headers)

    return headers


def request_type(media=None, media_type=None):
    if media_type:
        return media_type

    if media:
        if media.get('type'):
            return media.get('type')

        if media.get('media_type'):
            return media.get('media_type')

        if media.get('mediatype'):
            return media.get('mediatype')

    return 'movie'


def media_payload(media=None, media_type=None, media_id=None, extra=None, episode=None,
                  season=None, episode_number=None):
    payload = {}

    if extra:
        payload.update(extra)

    if 'type' not in payload:
        payload['type'] = request_type(
            media=media,
            media_type=media_type
        )

    if 'id' not in payload:
        resolved_id = media_id

        if resolved_id is None and media:
            resolved_id = media.get('id')

        if resolved_id not in (None, ''):
            payload['id'] = resolved_id

    if episode:
        if season is None:
            season = episode.get('season_number')

        if episode_number is None:
            episode_number = episode.get('episode_number')

    if season not in (None, ''):
        payload['season'] = season

    if episode_number not in (None, ''):
        payload['episode'] = episode_number

    return payload


def quality_value(source):
    quality = str(source.get('quality') or '').lower()

    if '2160' in quality or '4k' in quality:
        return 2160

    values = (
        ('1440', 1440),
        ('1080', 1080),
        ('720', 720),
        ('576', 576),
        ('480', 480),
        ('360', 360),
        ('240', 240),
    )

    for token, value in values:
        if token in quality:
            return value

    return 0


def open_play_window(media, episode=None):
    payload = media_payload(media, episode=episode)

    if payload.get('type') in ('movie', 'tv'):
        request_payload = {
            'type': payload.get('type'),
            'id': payload.get('id')
        }

        if payload.get('type') == 'tv':
            request_payload['season'] = payload.get('season')
            request_payload['episode'] = payload.get('episode')

        progress = dialogs.Progress()
        progress.create(paths.ADDON_NAME, 'Searching sources...')

        def on_progress(percent, text):
            try:
                progress.update(int(percent or 0), text or 'Searching sources...')
            except Exception:
                pass
            try:
                return progress.iscanceled()
            except Exception:
                return False

        try:
            get_sources = call(
                'streams',
                'sources',
                kwargs={
                    'media_type': request_payload.get('type'),
                    'media_id': request_payload.get('id'),
                    'season': request_payload.get('season'),
                    'episode': request_payload.get('episode'),
                },
                on_progress=on_progress,
            )
        except RemoteError:
            try:
                progress.close()
            except Exception:
                pass
            dialogs.ok(
                paths.ADDON_NAME,
                'Could not get a playable link. Try again in a moment.'
            )
            return

        try:
            cancelled = progress.iscanceled()
        except Exception:
            cancelled = False

        try:
            progress.close()
        except Exception:
            pass

        if cancelled:
            return

        if not isinstance(get_sources, dict):
            get_sources = {}

        sources = get_sources.get('sources', [])

        if not sources:
            dialogs.ok(
                paths.ADDON_NAME,
                'No playable sources found.'
            )
            return

        sources = sorted(
            sources,
            key=quality_value,
            reverse=True
        )

        xbmcgui.Dialog().notification(
            paths.ADDON_NAME,
            'Found %d links' % len(sources),
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        labels = []

        for index, source in enumerate(sources, 1):
            labels.append(
                'Link %d :: Quality %s' % (
                    index,
                    source.get('quality', 'Unknown')
                )
            )

        title = (media or {}).get('title') or 'Video'
        if episode:
            episode_name = episode.get('name') or episode.get('title') or ''
            if episode_name:
                title = '%s - %s' % (title, episode_name)

        while True:
            selected = dialogs.select(
                'Select Stream',
                labels
            )

            if selected < 0:
                return

            source = sources[selected]
            stream_url = source.get('url')

            if not stream_url:
                dialogs.ok(
                    paths.ADDON_NAME,
                    'Selected source has no URL.'
                )
                continue

            headers = source.get('headers') or {}
            started = player.play_stream(title, stream_url, headers)
            if started is False:
                continue

            xbmcgui.Dialog().notification(
                paths.ADDON_NAME,
                'Enjoy your stream!',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            player.wait_until_playback_ends(started)

    else:
        dialogs.ok(
            paths.ADDON_NAME,
            'Type: %s\nID: %s\nSeason: %s\nEpisode: %s' % (
                payload.get('type'),
                payload.get('id'),
                payload.get('season'),
                payload.get('episode')
            )
        )
