from __future__ import absolute_import

import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pyxbmct
import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.sports import busy_fetch, notify
from resources.lib.gui.buttons import text_button
from resources.lib.sources.documentaries import api
from resources.lib.sources.documentaries.api import DocumentaryError


def _load_message(mode):
    return {
        'latest': 'Loading latest titles...',
        'top': 'Loading the top list...',
        'best': 'Loading the best titles...',
        'categories': 'Loading categories...',
        'category': 'Loading that category...',
        'search': 'Searching...',
    }.get(mode or '', 'Loading titles...')


def _plain(text):
    return ' '.join((text or '').replace('[CR]', ' ').split())


def _art(path):
    text = (path or '').strip()
    if text.startswith('//'):
        text = 'https:' + text
    if text.lower().startswith('http://') or text.lower().startswith('https://'):
        return text
    return paths.ICON_PATH


SITES = (
    {
        'id': 'watch',
        'title': 'Watch Documentaries',
        'meta': 'Latest  |  Featured  |  Categories',
        'overview': 'Browse WatchDocumentaries, then play a title.',
        'actions': [
            {'id': 'latest', 'label': 'Latest'},
            {'id': 'top', 'label': 'Featured'},
            {'id': 'categories', 'label': 'Categories'},
            {'id': 'search', 'label': 'Search'},
        ],
    },
    {
        'id': 'top',
        'title': 'Top Documentary Films',
        'meta': 'Latest  |  Top 100  |  Categories',
        'overview': 'Browse Top Documentary Films, then play a title.',
        'actions': [
            {'id': 'latest', 'label': 'Latest'},
            {'id': 'top', 'label': 'Top 100'},
            {'id': 'categories', 'label': 'Categories'},
            {'id': 'search', 'label': 'Search'},
        ],
    },
    {
        'id': 'heaven',
        'title': 'Documentary Heaven',
        'meta': 'Latest  |  Top 100  |  Best',
        'overview': 'Browse Documentary Heaven, then play a title.',
        'actions': [
            {'id': 'latest', 'label': 'Latest'},
            {'id': 'top', 'label': 'Top 100'},
            {'id': 'best', 'label': 'Best'},
            {'id': 'categories', 'label': 'Categories'},
            {'id': 'search', 'label': 'Search'},
        ],
    },
)


def open_documentaries():
    window = DocumentarySitesWindow(SITES)
    window.doModal()
    del window


class DocumentarySitesWindow(ColossusFullWindow):
    def __init__(self, sites):
        super(DocumentarySitesWindow, self).__init__('')
        self.sites = list(sites or [])
        self.current_index = -1
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.populate()
        try:
            self.setFocus(self.results_list)
        except Exception:
            self.setFocus(self.back_button)

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]DOCUMENTARIES[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 14, 6, 50)
        self.status_label = pyxbmct.Label(
            'Choose a site.',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 64, 6, 32)
        self.poster = pyxbmct.Image(paths.DOC_PATH if os.path.exists(paths.DOC_PATH) else paths.ICON_PATH, aspectRatio=0)
        self.placeControl(self.poster, 12, 3, 36, 22)
        self.title_label = pyxbmct.Label(
            '[B]Documentaries[/B]',
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.title_label, 12, 28, 10, 36)
        self.meta_label = pyxbmct.Label(
            '',
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.meta_label, 23, 28, 6, 36)
        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 30, 28, 20, 36)
        self.overview_box.setText('Choose a site, then browse latest, top, categories, or search.')
        self.list_heading = pyxbmct.Label(
            '[B]SITES[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)

    def set_navigation(self):
        self.back_button.controlDown(self.results_list)
        self.back_button.controlRight(self.results_list)
        self.results_list.controlLeft(self.back_button)
        self.results_list.controlUp(self.back_button)

    def populate(self):
        self.results_list.reset()
        for site in self.sites:
            self.results_list.addItem(site.get('title') or 'Site')
        self.status_label.setLabel('%s sites  |  Select a site.' % len(self.sites))
        self.update_preview(force=True)

    def onAction(self, action):
        super(DocumentarySitesWindow, self).onAction(action)
        self.update_preview()

    def _current(self):
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return None
        if index < 0 or index >= len(self.sites):
            return None
        return self.sites[index]

    def update_preview(self, force=False):
        site = self._current()
        if site is None:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        self.title_label.setLabel('[B]%s[/B]' % (site.get('title') or 'Site'))
        self.meta_label.setLabel(site.get('meta') or '')
        self.overview_box.setText(site.get('overview') or '')

    def select_current(self):
        site = self._current()
        if site is None:
            return
        window = DocumentaryBrowseWindow(site)
        window.doModal()
        del window


class DocumentaryBrowseWindow(ColossusFullWindow):
    def __init__(self, site):
        super(DocumentaryBrowseWindow, self).__init__('')
        self.site = site or {}
        self.items = []
        self.current_index = -1
        self.mode = 'latest'
        self.page = 1
        self.category = 0
        self.query = ''
        self.list_name = 'LATEST'
        self.action_buttons = []
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.load_mode('latest')
        try:
            self.setFocus(self.results_list)
        except Exception:
            if self.action_buttons:
                self.setFocus(self.action_buttons[0])

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)
        self.header_label = pyxbmct.Label(
            '[B]%s[/B]' % (self.site.get('title') or 'DOCUMENTARIES').upper()[:42],
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.header_label, 2, 14, 6, 48)
        self.status_label = pyxbmct.Label(
            '',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.status_label, 2, 64, 6, 32)
        actions = self.site.get('actions') or []
        poster_h = max(18, min(36, 70 - (8 * len(actions))))
        self.poster = pyxbmct.Image(paths.ICON_PATH, aspectRatio=0)
        self.placeControl(self.poster, 12, 3, poster_h, 20)
        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % (self.site.get('title') or 'Documentaries'),
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.title_label, 12, 26, 10, 38)
        self.meta_label = pyxbmct.Label(
            self.site.get('meta') or '',
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.meta_label, 23, 26, 6, 38)
        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 30, 26, 22, 38)
        self.overview_box.setText(self.site.get('overview') or '')
        row = 12 + poster_h + 2
        for action in actions:
            button = text_button(action.get('label') or 'Open')
            self.placeControl(button, row, 2, 8, 22)
            mode = action.get('id') or 'latest'
            self.connect(button, (lambda current=mode: self.load_mode(current)))
            self.action_buttons.append(button)
            row += 8
        self.list_heading = pyxbmct.Label(
            '[B]LATEST[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT,
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)

    def set_navigation(self):
        if not self.action_buttons:
            self.back_button.controlDown(self.results_list)
            self.back_button.controlRight(self.results_list)
            self.results_list.controlLeft(self.back_button)
            self.results_list.controlUp(self.back_button)
            return
        first = self.action_buttons[0]
        last = self.action_buttons[-1]
        self.back_button.controlDown(first)
        self.back_button.controlRight(first)
        first.controlUp(self.back_button)
        first.controlLeft(self.back_button)
        for index, control in enumerate(self.action_buttons):
            control.controlRight(self.results_list)
            control.controlLeft(self.back_button)
            if index > 0:
                control.controlUp(self.action_buttons[index - 1])
            if index < len(self.action_buttons) - 1:
                control.controlDown(self.action_buttons[index + 1])
            else:
                control.controlDown(self.results_list)
        self.results_list.controlLeft(last)
        self.results_list.controlUp(last)

    def onAction(self, action):
        super(DocumentaryBrowseWindow, self).onAction(action)
        self.update_preview()

    def load_mode(self, mode, page=1, category=0, query=''):
        if mode == 'search' and not query:
            keyboard = xbmc.Keyboard('', 'Search documentaries')
            keyboard.doModal()
            if not keyboard.isConfirmed():
                return
            query = (keyboard.getText() or '').strip()
            if not query:
                return
        self.mode = mode
        self.page = page
        self.category = category
        self.query = query
        try:
            result = busy_fetch(
                lambda: api.browse({
                    'site': self.site.get('id') or '',
                    'mode': mode,
                    'page': page,
                    'category': category,
                    'query': query,
                }),
                _load_message(mode),
            )
        except DocumentaryError as exc:
            dialogs.ok(paths.ADDON_NAME, 'Could not load that list.\n%s' % exc)
            return
        if result is None:
            return
        self.items = result.get('items') or []
        self.list_name = result.get('heading') or mode.upper()
        try:
            self.list_heading.setLabel('[B]%s[/B]' % self.list_name)
        except Exception:
            pass
        self.results_list.reset()
        self.current_index = -1
        if not self.items:
            self.results_list.addItem('Nothing found')
            self.status_label.setLabel('Nothing found.')
            self.title_label.setLabel('[B]Nothing found[/B]')
            self.meta_label.setLabel('')
            self.overview_box.setText('Try another category or search.')
            return
        for item in self.items:
            self.results_list.addItem(_plain(item.get('title') or ''))
        noun = 'categories' if mode == 'categories' else 'titles'
        self.status_label.setLabel('%s %s  |  Select one.' % (len(self.items), noun))
        self.update_preview(force=True)
        try:
            self.setFocus(self.results_list)
        except Exception:
            pass

    def _current(self):
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return None
        if index < 0 or index >= len(self.items):
            return None
        return self.items[index]

    def update_preview(self, force=False):
        item = self._current()
        if item is None:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or ''))
        self.meta_label.setLabel(item.get('meta') or '')
        self.overview_box.setText(item.get('overview') or '')
        try:
            self.poster.setImage(_art(item.get('image')))
        except Exception:
            pass

    def select_current(self):
        item = self._current()
        if item is None:
            return
        kind = item.get('kind') or ''
        if kind == 'page':
            self.load_mode(
                item.get('mode') or self.mode,
                page=int(item.get('page') or 1),
                category=int(item.get('category') or 0),
                query=item.get('query') or '',
            )
            return
        if kind == 'category':
            self.load_mode('category', category=int(item.get('category') or 0))
            return
        if kind == 'video':
            _play_item(item)


def _play_item(item):
    holder = {
        'data': None,
        'error': None,
        'done': False,
        'cancel': False,
        'percent': 8,
        'text': 'Opening the film page...',
    }

    def on_progress(percent, text):
        try:
            holder['percent'] = max(int(holder.get('percent') or 0), int(percent or 0))
        except (TypeError, ValueError):
            pass
        if text:
            holder['text'] = text
        return bool(holder.get('cancel'))

    def work():
        try:
            holder['data'] = api.resolve(item.get('url') or '', on_progress)
        except Exception as exc:
            holder['error'] = exc
        finally:
            holder['done'] = True

    threading.Thread(target=work, daemon=True).start()
    progress = dialogs.Progress()
    started = time.time()
    progress.create(paths.ADDON_NAME, holder['text'])
    shown = None
    while not holder['done']:
        if progress.iscanceled():
            holder['cancel'] = True
            try:
                progress.close()
            except Exception:
                pass
            return
        elapsed = max(0, int(time.time() - started))
        percent = min(92, int(holder.get('percent') or 8) + min(6, elapsed))
        text = holder.get('text') or 'Getting the video...'
        if elapsed >= 1:
            unit = 'second' if elapsed == 1 else 'seconds'
            text = '%s  |  %s %s' % (text, elapsed, unit)
        key = (percent, text)
        if key != shown:
            shown = key
            progress.update(percent, text)
        xbmc.sleep(200)
    try:
        progress.update(100, 'Ready to play.')
        progress.close()
    except Exception:
        pass
    if holder.get('cancel'):
        return
    result = holder.get('data') or {}
    if result.get('cancelled'):
        return
    if holder.get('error') is not None:
        dialogs.ok(paths.ADDON_NAME, 'Playback failed.\n%s' % holder['error'])
        return
    streams = result.get('streams') or []
    if not streams:
        dialogs.ok(paths.ADDON_NAME, 'No video on that page. It may be a news article.')
        return
    stream = streams[0]
    if len(streams) > 1:
        choice = dialogs.select(
            'Choose a quality',
            [row.get('label') or 'Play' for row in streams],
        )
        if choice < 0 or choice >= len(streams):
            return
        stream = streams[choice]
    title = item.get('title') or 'Documentary'
    if stream.get('audio_url'):
        if not _adaptive_ready():
            dialogs.ok(
                paths.ADDON_NAME,
                'This quality is a split video and audio stream.\n\n'
                'Install InputStream Adaptive, then try it again.\n'
                'The 360p file plays without it.',
            )
            return
        path = _serve_mpd(_mpd_text(stream))
        player.play_stream(title, path, stream.get('headers') or {})
        return
    player.play_stream(title, stream.get('url') or '', stream.get('headers') or {})


def _adaptive_ready():
    try:
        return xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)') == 1
    except Exception:
        return False


def _xml(value):
    text = str(value or '')
    return (
        text.replace('&', '&amp;')
        .replace('<', '&lt;')
        .replace('>', '&gt;')
        .replace('"', '&quot;')
    )


def _duration(seconds):
    try:
        seconds = int(seconds or 0)
    except (TypeError, ValueError):
        seconds = 0
    if seconds < 1:
        seconds = 1
    hours, remain = divmod(seconds, 3600)
    minutes, secs = divmod(remain, 60)
    return 'PT%dH%dM%dS' % (hours, minutes, secs)


def _segment(init_range, index_range):
    if not init_range or not index_range:
        return ''
    return (
        '<SegmentBase indexRange="%s"><Initialization range="%s"/></SegmentBase>'
        % (_xml(index_range), _xml(init_range))
    )


class _Manifest(object):
    def __init__(self):
        self.body = b''
        self.httpd = None
        self.thread = None

    def url(self, xml_text):
        self.body = (xml_text or '').encode('utf-8')
        if self.httpd is None:
            owner = self

            class _Handler(BaseHTTPRequestHandler):
                def do_GET(self):
                    data = owner.body
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/dash+xml')
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    self.wfile.write(data)

                def log_message(self, fmt, *args):
                    return

            self.httpd = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
            self.thread = threading.Thread(target=self.httpd.serve_forever)
            self.thread.daemon = True
            self.thread.start()
        return 'http://127.0.0.1:%s/play.mpd' % self.httpd.server_address[1]


_MANIFEST = _Manifest()


def _serve_mpd(xml_text):
    return _MANIFEST.url(xml_text)


def _mpd_text(stream):
    video = (
        '<AdaptationSet contentType="video" mimeType="video/mp4">'
        '<Representation id="video" bandwidth="%s" width="%s" height="%s" codecs="%s">'
        '<BaseURL>%s</BaseURL>%s'
        '</Representation></AdaptationSet>'
    ) % (
        int(stream.get('bandwidth') or 1000000),
        int(stream.get('width') or 0),
        int(stream.get('height') or 0),
        _xml(stream.get('codecs') or 'avc1.4D401F'),
        _xml(stream.get('url') or ''),
        _segment(stream.get('init'), stream.get('index')),
    )
    audio = (
        '<AdaptationSet contentType="audio" mimeType="audio/mp4">'
        '<Representation id="audio" bandwidth="%s" codecs="%s">'
        '<BaseURL>%s</BaseURL>%s'
        '</Representation></AdaptationSet>'
    ) % (
        int(stream.get('audio_bandwidth') or 128000),
        _xml(stream.get('audio_codecs') or 'mp4a.40.2'),
        _xml(stream.get('audio_url') or ''),
        _segment(stream.get('audio_init'), stream.get('audio_index')),
    )
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" '
        'profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" '
        'mediaPresentationDuration="%s"><Period>%s%s</Period></MPD>'
    ) % (_duration(stream.get('duration')), video, audio)
    return body
