from __future__ import absolute_import

import os

import pyxbmct

from resources.lib.core import paths


def text_button(label):
    normal = paths.TEXT_BUTTON_PATH if os.path.exists(paths.TEXT_BUTTON_PATH) else ''
    focused = paths.TEXT_BUTTON_FOCUS_PATH if os.path.exists(paths.TEXT_BUTTON_FOCUS_PATH) else normal
    return pyxbmct.Button(
        label,
        noFocusTexture=normal,
        focusTexture=focused,
        textColor='0xFFFFFFFF',
        focusedColor='0xFFFFFFFF',
        font='font12',
        textOffsetX=20
    )
