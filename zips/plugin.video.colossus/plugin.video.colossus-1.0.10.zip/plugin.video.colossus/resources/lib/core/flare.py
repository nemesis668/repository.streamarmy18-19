from __future__ import absolute_import

import json
import threading
import time

import requests


FLARE_URL = 'http://217.154.17.37:8191/v1'
# One session is one Chrome. Share a handful, and close any that sit idle.
_SLOTS = 4
_IDLE_SECONDS = 60
_SEM = threading.Semaphore(_SLOTS)
_POOL = []
_POOL_LOCK = threading.Lock()
_NOTICE = {'at': 0}

_MARKERS = (
    'just a moment',
    'cf-browser-verification',
    'attention required',
    'cf-challenge',
    'challenge-platform',
    'enable javascript and cookies',
    'checking your browser',
    'cf-mitigated',
)


class FlareError(Exception):
    def __init__(self, message, broken=False):
        Exception.__init__(self, message)
        self.broken = broken


class Page(object):
    def __init__(self, text, url, status_code=200):
        self.text = text or ''
        self.url = url
        self.status_code = int(status_code or 200)
        self.headers = {}
        self.encoding = 'utf-8'
        self.content = self.text.encode('utf-8', 'replace')

    def json(self):
        return json.loads(self.text)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError('HTTP %s' % self.status_code)


def _log(message):
    try:
        import xbmc
        xbmc.log('[Colossus] %s' % message, xbmc.LOGINFO)
    except Exception:
        pass


def _sample(body):
    if body is None:
        return ''
    if isinstance(body, bytes):
        body = body[:5000].decode('utf-8', 'ignore')
    else:
        body = str(body)[:5000]
    return body.lower()


def body_is_challenge(status, body, headers=None):
    headers = headers or {}
    mitigated = ''
    server = ''
    for key, value in headers.items():
        name = str(key).lower()
        if name == 'cf-mitigated':
            mitigated = str(value).lower()
        elif name == 'server':
            server = str(value).lower()
    if mitigated:
        return True
    sample = _sample(body)
    if any(marker in sample for marker in _MARKERS):
        return True
    if int(status or 0) in (403, 503) and 'cloudflare' in server:
        return True
    if int(status or 0) in (403, 503) and 'cloudflare' in sample and 'ray id' in sample:
        return True
    return False


def is_challenge(response):
    if response is None:
        return False
    try:
        headers = response.headers or {}
    except Exception:
        headers = {}
    content_type = ''
    try:
        content_type = str(headers.get('Content-Type') or headers.get('content-type') or '').lower()
    except Exception:
        content_type = ''
    if content_type.startswith('image/') or content_type.startswith('video/') or 'mpegurl' in content_type:
        return False
    try:
        body = response.text
    except Exception:
        body = ''
    try:
        status = response.status_code
    except Exception:
        status = 0
    return body_is_challenge(status, body, headers)


def _post(payload, timeout):
    response = requests.post(
        FLARE_URL,
        data=json.dumps(payload),
        headers={'Content-Type': 'application/json'},
        timeout=timeout + 15,
    )
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict):
        raise FlareError('FlareSolverr returned an unexpected response.')
    return data


def _drop(session_id):
    if not session_id:
        return
    try:
        _post({'cmd': 'sessions.destroy', 'session': session_id}, 15)
    except Exception:
        pass


def _reap():
    now = time.time()
    stale = []
    with _POOL_LOCK:
        keep = []
        for session_id, used in _POOL:
            if now - used >= _IDLE_SECONDS:
                stale.append(session_id)
            else:
                keep.append((session_id, used))
        _POOL[:] = keep
    for session_id in stale:
        _drop(session_id)


def _reaper():
    while True:
        time.sleep(15)
        try:
            _reap()
        except Exception:
            pass


threading.Thread(target=_reaper, name='flare-reaper', daemon=True).start()


def _borrow(timeout):
    _reap()
    _SEM.acquire()
    try:
        with _POOL_LOCK:
            if _POOL:
                session_id, _used = _POOL.pop()
                return session_id
        data = _post({'cmd': 'sessions.create'}, timeout)
    except Exception as exc:
        _SEM.release()
        _log('FlareSolverr session was not created: %s' % exc)
        raise
    if data.get('status') != 'ok' or not data.get('session'):
        _SEM.release()
        raise FlareError(data.get('message') or 'FlareSolverr could not open a browser.')
    return data.get('session')


def _release(session_id, broken):
    try:
        if broken or not session_id:
            _drop(session_id)
        else:
            with _POOL_LOCK:
                _POOL.append((session_id, time.time()))
    finally:
        _SEM.release()


def _notify_wait():
    now = time.time()
    if now - _NOTICE.get('at', 0) < 8:
        return
    _NOTICE['at'] = now
    try:
        import xbmcgui
        from resources.lib.core import paths
        xbmcgui.Dialog().notification(
            paths.ADDON_NAME,
            'Detected Cloudflare. Bypassing with FlareSolverr, please wait.',
            paths.ICON_PATH,
            8000
        )
    except Exception:
        pass


def _opened(url, timeout, session_id):
    data = _post({
        'cmd': 'request.get',
        'url': url,
        'maxTimeout': int(timeout * 1000),
        'session': session_id,
    }, timeout)
    if data.get('status') != 'ok':
        message = data.get('message') or 'FlareSolverr could not open that page.'
        low = message.lower()
        raise FlareError(message, broken=('session' in low or 'browser' in low))
    solution = data.get('solution') or {}
    text = solution.get('response') or ''
    final_url = solution.get('url') or url
    status = solution.get('status') or 200
    if not str(text).strip() or body_is_challenge(status, text):
        raise FlareError('Cloudflare challenge was not solved.')
    _log('FlareSolverr opened %s' % url.split('?')[0])
    return Page(text, final_url, status)


def solve(url, timeout=60):
    _notify_wait()
    for attempt in (0, 1):
        session_id = _borrow(timeout)
        broken = False
        try:
            return _opened(url, timeout, session_id)
        except FlareError as exc:
            broken = bool(exc.broken)
            raise
        except Exception:
            broken = True
            if attempt:
                raise
        finally:
            _release(session_id, broken)
