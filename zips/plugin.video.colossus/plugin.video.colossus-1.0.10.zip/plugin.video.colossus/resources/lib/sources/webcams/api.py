from __future__ import absolute_import

from resources.lib.core.remote import RemoteError, call


class WebcamError(Exception):
    pass


def _run(name, payload=None, on_progress=None):
    try:
        return call('webcams', name, [payload or {}], on_progress=on_progress) or {}
    except RemoteError as exc:
        raise WebcamError(str(exc))


def browse(payload, on_progress=None):
    return _run('browse', payload, on_progress)


def resolve(url, on_progress=None):
    return _run('resolve', {'url': url or ''}, on_progress)
