from __future__ import absolute_import

from resources.lib.core.remote import RemoteError, call


class DocumentaryError(Exception):
    pass


def _run(name, payload=None):
    try:
        return call('documentaries', name, [payload or {}])
    except RemoteError as exc:
        raise DocumentaryError(str(exc))


def sources():
    return _run('sources') or []


def browse(payload):
    return _run('browse', payload) or {}


def resolve(url, on_progress=None):
    try:
        return call(
            'documentaries',
            'resolve',
            [{'url': url or ''}],
            on_progress=on_progress,
        ) or {}
    except RemoteError as exc:
        raise DocumentaryError(str(exc))
