                                                        

from __future__ import absolute_import

from resources.lib.core.remote import RemoteError, call


BASE_URL = 'https://musify.club'
REFERER = BASE_URL + '/en'
USER_AGENT = 'Mozilla/5.0'
PAGE_SIZE = 20
CATEGORIES = (
    {'key': 'charts', 'id': 'charts', 'title': 'Charts'},
    {'key': 'releases', 'id': 'releases', 'title': 'New releases'},
    {'key': 'playlists', 'id': 'playlists', 'title': 'Playlists'},
)
HITS = (
    {'key': 'hits-week', 'id': 'hits-week', 'title': 'Top 100 this week'},
    {'key': 'hits-month', 'id': 'hits-month', 'title': 'Monthly archive'},
    {'key': 'hits-all', 'id': 'hits-all', 'title': 'Hits'},
    {'key': 'hits-year', 'id': 'hits-year', 'title': 'Hits by year'},
    {'key': 'top-albums', 'id': 'top-albums', 'title': 'Top albums'},
    {'key': 'top-compilations', 'id': 'top-compilations', 'title': 'Top compilations'},
    {'key': 'top-soundtracks', 'id': 'top-soundtracks', 'title': 'Top soundtracks'},
)
LETTERS = tuple(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ') + ['#'])


class Mp3Error(Exception):
    pass


def _run(name, *args, **kwargs):
    try:
        return call('mp3lib', name, list(args), kwargs)
    except RemoteError as exc:
        raise Mp3Error(str(exc))


def get_category_page(category_id, page=1):
    return _run('get_category_page', category_id, page)


def search(query, page=1):
    return _run('search', query, page)


def get_letter_items(letter):
    return _run('get_letter_items', letter)


def get_release(post_id=None, link='', slug='', title='', artist=''):
    return _run(
        'get_release',
        post_id=post_id,
        link=link,
        slug=slug,
        title=title,
        artist=artist,
    )
