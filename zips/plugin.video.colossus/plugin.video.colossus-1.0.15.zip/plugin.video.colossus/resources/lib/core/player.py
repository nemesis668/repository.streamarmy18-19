from __future__ import absolute_import

import json
import re
import threading
from urllib.parse import quote, urljoin

import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.gui import dialogs
from resources.lib.core.hls_unwrap import PlaylistBlocked, start_wrapped_playlist
from resources.lib.sources.source2 import api as source2


def log(message):
    xbmc.log('[Colossus] %s' % message, xbmc.LOGINFO)


def encode_headers(headers):
    parts = []
    for key, value in (headers or {}).items():
        if value is None or value == '':
            continue
        parts.append('%s=%s' % (key, quote(str(value), safe='')))
    return '&'.join(parts)


def _request_bytes(url, headers, timeout, limit):
    import requests
    response = requests.get(
        url,
        timeout=timeout,
        headers=headers,
        stream=True,
        verify=False,
    )
    try:
        if response.status_code != 200:
            return response.status_code, '', b''
        chunks = []
        size = 0
        for chunk in response.iter_content(chunk_size=2048):
            if not chunk:
                continue
            chunks.append(chunk)
            size += len(chunk)
            if size >= limit:
                break
        body = b''.join(chunks)[:limit]
        content_type = (response.headers.get('Content-Type') or '').lower()
        return response.status_code, content_type, body
    finally:
        response.close()


def _playlist_uri(text):
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            return line
    return ''


def _segment_is_media(body, content_type):
    if 'text/html' in (content_type or ''):
        return False
    sample = (body or b'').lstrip()[:32].lower()
    if sample.startswith(b'<!doctype') or sample.startswith(b'<html'):
        return False
    return bool(body)


def stream_looks_live(play_url, headers=None, timeout=6):
    if not play_url:
        return False
    try:
        req_headers = {'User-Agent': source2.USER_AGENT, 'Accept': '*/*'}
        if headers:
            req_headers.update(headers)
        status, _content_type, body = _request_bytes(play_url, req_headers, timeout, 8192)
        if status != 200:
            return False
        if '.m3u8' not in (play_url or '').lower():
            return True
        text = body.decode('utf-8', 'ignore')
        if '#EXTM3U' not in text:
            return False
        media_url = play_url
        media = text
        if '#EXT-X-STREAM-INF' in text:
            variant = _playlist_uri(text)
            if not variant:
                return False
            media_url = urljoin(play_url, variant)
            try:
                status, _content_type, body = _request_bytes(media_url, req_headers, timeout, 8192)
            except Exception:
                return True
            if status != 200:
                return False
            media = body.decode('utf-8', 'ignore')
        if '#EXTINF' not in media:
            return False
        segment = _playlist_uri(media)
        if not segment:
            return False
        segment_url = urljoin(media_url, segment)
        try:
            status, content_type, body = _request_bytes(segment_url, req_headers, timeout, 256)
        except Exception:
            return True
        if status != 200:
            return True
        return _segment_is_media(body, content_type)
    except Exception as exc:
        log('Stream check failed: %s' % exc)
        return False


_INPUTSTREAM_ID = 'inputstream.adaptive'


def _inputstream_available():
    try:
        return xbmc.getCondVisibility('System.HasAddon(%s)' % _INPUTSTREAM_ID) == 1
    except Exception:
        return False


def _addon_rpc(method, params):
    try:
        raw = xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0',
            'id': 1,
            'method': method,
            'params': params,
        }))
        data = json.loads(raw)
    except Exception as exc:
        log('Addon request failed: %s' % exc)
        return {}
    if data.get('error'):
        log('Addon request %s failed: %s' % (method, data.get('error')))
        return {}
    return data.get('result') or {}


def _inputstream_enabled_flag():
    """None when it is not installed. True or False once it is on the device."""
    result = _addon_rpc('Addons.GetAddonDetails', {
        'addonid': _INPUTSTREAM_ID,
        'properties': ['enabled'],
    })
    addon = result.get('addon') or {}
    if not addon.get('addonid'):
        return None
    return bool(addon.get('enabled'))


def _inputstream_in_repo():
    """True when the repository lists it, False when it does not, None if Kodi did not answer."""
    result = _addon_rpc('Addons.GetAddons', {
        'type': 'kodi.inputstream',
        'installed': False,
    })
    if 'addons' not in result:
        return None
    return any(item.get('addonid') == _INPUTSTREAM_ID for item in result.get('addons') or [])


def ensure_inputstream():
    """Ask to install or turn on InputStream Adaptive, then let Kodi do it."""
    if _inputstream_available():
        return True
    enabled = _inputstream_enabled_flag()
    if enabled is False:
        if not dialogs.yesno(
            paths.ADDON_NAME,
            'InputStream Adaptive is installed, but it is turned off.\n\nTurn it on?',
            nolabel='Not now',
            yeslabel='Turn on',
        ):
            return False
        _addon_rpc('Addons.SetAddonEnabled', {
            'addonid': _INPUTSTREAM_ID,
            'enabled': True,
        })
        if _inputstream_available():
            return True
        dialogs.ok(paths.ADDON_NAME, 'InputStream Adaptive could not be turned on.')
        return False
    if _inputstream_in_repo() is False:
        dialogs.ok(
            paths.ADDON_NAME,
            'InputStream Adaptive is not available to install.\n\n'
            'Enable the Kodi add-on repository, then try this stream again.'
        )
        return False
    # Kodi asks, and Yes downloads and enables it.
    try:
        xbmc.executebuiltin('InstallAddon(%s)' % _INPUTSTREAM_ID, True)
    except TypeError:
        xbmc.executebuiltin('InstallAddon(%s)' % _INPUTSTREAM_ID)
    for _attempt in range(20):
        if _inputstream_available():
            return True
        xbmc.sleep(250)
    log('InputStream Adaptive is still missing after the install prompt')
    return False


def play_audio(title, url, headers=None, artist=None):
    headers = dict(headers or {})
    if not headers.get('User-Agent') and not headers.get('user-agent'):
        headers['User-Agent'] = source2.USER_AGENT
    if not headers.get('Accept'):
        headers['Accept'] = '*/*'
    if not headers.get('Referer'):
        headers['Referer'] = 'https://fmstream.org/'
    if not headers.get('Icy-MetaData'):
        headers['Icy-MetaData'] = '1'

    header_string = encode_headers(headers)
    play_path = '%s|%s' % (url, header_string) if header_string else url
    lowered = (url or '').lower()
    is_hls = '.m3u8' in lowered
    is_dash = '.mpd' in lowered
    use_isa = (is_hls or is_dash) and _inputstream_available()
    item_path = url if use_isa else play_path

    log('Playing radio %s via %s' % (title, 'inputstream.adaptive' if use_isa else 'default player'))
    list_item = xbmcgui.ListItem(label=title, path=item_path)
    list_item.setInfo('music', {'title': title, 'artist': artist or 'World Radio'})
    list_item.setInfo('video', {'title': title, 'mediatype': 'music'})
    list_item.setProperty('IsPlayable', 'true')
    try:
        list_item.setContentLookup(False)
    except Exception:
        pass

    if is_hls:
        list_item.setMimeType('application/vnd.apple.mpegurl')
        if use_isa:
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if header_string:
                list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
                list_item.setProperty('inputstream.adaptive.manifest_headers', header_string)
                list_item.setProperty('inputstream.adaptive.common_headers', header_string)
    elif is_dash:
        list_item.setMimeType('application/dash+xml')
        if use_isa:
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            if header_string:
                list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
                list_item.setProperty('inputstream.adaptive.manifest_headers', header_string)
                list_item.setProperty('inputstream.adaptive.common_headers', header_string)

    xbmc.Player().play(item_path, list_item, False)


def play_audio_items(tracks, headers=None, startpos=0):
    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    count = 0
    for track in tracks or []:
        url = (track.get('url') or '').strip()
        title = track.get('title') or 'Track'
        if not url:
            continue
        item_headers = dict(headers or track.get('headers') or {})
        if not item_headers.get('User-Agent') and not item_headers.get('user-agent'):
            item_headers['User-Agent'] = source2.USER_AGENT
        if not item_headers.get('Accept'):
            item_headers['Accept'] = '*/*'
        header_string = encode_headers(item_headers)
        play_path = '%s|%s' % (url, header_string) if header_string else url
        list_item = xbmcgui.ListItem(label=title, path=play_path)
        info = {
            'title': title,
            'artist': track.get('artist') or '',
        }
        if track.get('album'):
            info['album'] = track.get('album')
        list_item.setInfo('music', info)
        list_item.setProperty('IsPlayable', 'true')
        try:
            list_item.setContentLookup(False)
        except Exception:
            pass
        if '.mp3' in url.lower():
            list_item.setMimeType('audio/mpeg')
        playlist.add(play_path, list_item)
        count += 1
    if count < 1:
        return False
    if startpos < 0 or startpos >= count:
        startpos = 0
    log('Playing music playlist with %s tracks (start %s)' % (count, startpos))
    xbmc.Player().play(playlist, None, False, startpos)
    return True


def stop_audio():
    try:
        xbmc.Player().stop()
    except Exception:
        pass


def play_next_audio():
    try:
        xbmc.Player().playnext()
    except Exception:
        pass


def play_previous_audio():
    try:
        xbmc.Player().playprevious()
    except Exception:
        pass


def is_playing_audio():
    try:
        return bool(xbmc.Player().isPlayingAudio())
    except Exception:
        return False


def music_playlist_size():
    try:
        return xbmc.PlayList(xbmc.PLAYLIST_MUSIC).size()
    except Exception:
        return 0


class _PlaybackWatch(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.started = False
        self.finished = False

    def onPlayBackStarted(self):
        self.started = True

    def onAVStarted(self):
        self.started = True

    def onPlayBackError(self):
        self.finished = True

    def onPlayBackStopped(self):
        self.finished = True

    def onPlayBackEnded(self):
        self.finished = True


def _video_playing():
    try:
        return bool(xbmc.Player().isPlayingVideo())
    except Exception:
        return False


def playback_started(watch, timeout=15):
    """True once the picture has stayed up, so a stray stop event is not a failure."""
    if not watch:
        return False
    held = 0
    for _ in range(int(timeout * 5)):
        if getattr(watch, 'started', False) or _video_playing():
            held += 1
            if held >= 4 and _video_playing():
                return True
        else:
            held = 0
        xbmc.sleep(200)
    return False


def wait_until_playback_ends(watch):
    """Stay out of the way until this picture is gone. A stop event while it is still up does not count."""
    if not watch:
        return False
    if not playback_started(watch):
        return False
    while _video_playing():
        xbmc.sleep(400)
    return True


def _stop_current_video():
    """The previous film keeps asking for its playlist until playback stops."""
    try:
        current = xbmc.Player()
        if not current.isPlayingVideo():
            return
        current.stop()
        for _ in range(20):
            if not current.isPlayingVideo():
                return
            xbmc.sleep(50)
    except Exception:
        pass


def _drm_legacy(drm, headers):
    """Build the InputStream Adaptive key string. ClearKey is kid:key. Widevine is the licence address."""
    if not isinstance(drm, dict):
        return ''
    kind = (drm.get('type') or '').strip().lower()
    if kind == 'clearkey':
        kid = (drm.get('kid') or '').strip()
        key = (drm.get('key') or '').strip()
        if not kid or not key:
            return ''
        return 'org.w3.clearkey|%s:%s' % (kid, key)
    if kind == 'widevine':
        license_url = (drm.get('license') or '').strip()
        if not license_url or '|' in license_url:
            return ''
        # A bare address is one block. Any | means exactly four blocks:
        # address|headers|body|response. Gluing the user agent on with one |
        # is what makes this build reject the licence.
        user_agent = headers.get('User-Agent') or headers.get('user-agent') or source2.USER_AGENT
        licence_headers = 'Content-Type=' + quote('application/octet-stream', safe='')
        licence_headers += '&User-Agent=' + quote(user_agent, safe='')
        referer = headers.get('Referer') or headers.get('referer') or ''
        if referer and '|' not in referer:
            licence_headers += '&Referer=' + quote(referer, safe='')
        return 'com.widevine.alpha|%s|%s|R{SSM}|' % (license_url, licence_headers)
    return ''


def _apply_drm(list_item, legacy):
    kind, _sep, rest = legacy.partition('|')
    if not kind or not rest:
        return
    # ISA 21.5 ignores license_key for ClearKey and fails if both styles are set.
    # ClearKey keys go on drm_legacy only: org.w3.clearkey|kid:key
    if kind == 'org.w3.clearkey':
        list_item.setProperty('inputstream.adaptive.drm_legacy', '%s|%s' % (kind, rest))
        log('DRM clearkey via drm_legacy')
    else:
        list_item.setProperty('inputstream.adaptive.license_type', kind)
        list_item.setProperty('inputstream.adaptive.license_key', rest)
        log('DRM %s via license_key' % kind)


def _ensure_widevine():
    """Android and Fire TV already include Widevine. Other devices need the CDM library."""
    try:
        from inputstreamhelper import Helper
    except Exception:
        dialogs.ok(
            paths.ADDON_NAME,
            'This stream needs Widevine.\n\n'
            'Install InputStream Helper, open it, and choose Install Widevine.'
        )
        return False
    try:
        return Helper('mpd', drm='widevine').check_inputstream()
    except Exception as exc:
        log('Widevine check failed: %s' % exc)
        dialogs.ok(
            paths.ADDON_NAME,
            'Widevine could not be prepared.\n\n'
            'Open InputStream Helper and choose Install Widevine.'
        )
        return False


def _offer_quality_choice(list_item):
    """Ask which rung to play when the manifest has more than one.

    InputStream Adaptive builds the list from that stream and shows it on
    every device. A single rung skips the dialog. The highlighted row is the
    best fit for the screen that is actually playing, and any rung can be chosen.
    """
    list_item.setProperty('inputstream.adaptive.stream_selection_type', 'ask-quality')


def play_stream(title, url, headers=None, subtitles=None, passthrough=False, adaptive=True, drm=None):
    _stop_current_video()
    supplied = headers is not None
    headers = dict(headers or {})
    if not supplied or headers:
        if not headers.get('User-Agent') and not headers.get('user-agent'):
            headers['User-Agent'] = source2.USER_AGENT
        if not headers.get('Accept'):
            headers['Accept'] = '*/*'
    drm_legacy = _drm_legacy(drm, headers)

    wrapped = None
    if not passthrough and not drm_legacy:
        try:
            wrapped = start_wrapped_playlist(url, headers)
        except PlaylistBlocked as blocked:
            dialogs.ok(
                paths.ADDON_NAME,
                'This host needs about %s seconds.\n\n'
                'The links you already scraped are still here.\n'
                'Press OK, then choose one again after the wait.' % blocked.wait
            )
            return False
    if wrapped:
        local_url, mode = wrapped
        log('Playing wrapped playlist via %s' % local_url)
        url = local_url
        if mode == 'unwrap':
            headers = {'User-Agent': source2.USER_AGENT}

    header_string = encode_headers(headers)
    play_path = '%s|%s' % (url, header_string) if header_string else url
    lowered = (url or '').lower().split('?', 1)[0]
    is_hls = '.m3u8' in lowered
    is_dash = lowered.endswith('.mpd') or '/.mpd' in lowered or '.mpd' in lowered
    if drm_legacy and not is_hls:
        is_dash = True
    needs_isa = bool(drm_legacy or (adaptive and is_dash))
    if needs_isa and not _inputstream_available():
        if not ensure_inputstream():
            return False
    use_isa = (drm_legacy or (adaptive and (is_hls or is_dash))) and _inputstream_available()
    if isinstance(drm, dict) and (drm.get('type') or '').strip().lower() == 'widevine':
        if not _ensure_widevine():
            return False
    item_path = url if use_isa else play_path

    via = 'inputstream.adaptive' if use_isa else 'default player'
    log('Playing %s via %s' % (title, via))
    list_item = xbmcgui.ListItem(label=title, path=item_path)
    list_item.setInfo('video', {'title': title, 'mediatype': 'video'})
    list_item.setProperty('IsPlayable', 'true')
    try:
        list_item.setContentLookup(False)
    except Exception:
        pass
    subtitle_urls = [item for item in (subtitles or []) if item]
    if subtitle_urls:
        try:
            list_item.setSubtitles(subtitle_urls)
        except Exception:
            pass

    if is_hls:
        list_item.setMimeType('application/vnd.apple.mpegurl')
        if not use_isa:
            list_item.setProperty('inputstream', 'builtin')
        if use_isa:
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if header_string:
                list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
                list_item.setProperty('inputstream.adaptive.manifest_headers', header_string)
                list_item.setProperty('inputstream.adaptive.common_headers', header_string)
    elif is_dash:
        list_item.setMimeType('application/dash+xml')
        if use_isa:
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            if header_string:
                list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
                list_item.setProperty('inputstream.adaptive.manifest_headers', header_string)
                list_item.setProperty('inputstream.adaptive.common_headers', header_string)

    if use_isa:
        _offer_quality_choice(list_item)
    if drm_legacy and use_isa:
        _apply_drm(list_item, drm_legacy)

    watch = _PlaybackWatch()
    xbmc.Player().play(item_path, list_item, False)
    return watch


_PLAYER_BUTTON = re.compile(
    r'data-url="([^"]+)"[^>]*>\s*([^<]+)',
    re.I,
)


def _player_order(label):
    match = re.search(r'(\d+)', label or '')
    if not match:
        return 99
    try:
        return int(match.group(1))
    except ValueError:
        return 99


def _listed_players(watch_url, timeout=8):
    """Player buttons on a channel page. Empty when the page has a single player."""
    if 'watch.php' not in (watch_url or ''):
        return []
    try:
        import requests
        response = requests.get(
            watch_url,
            timeout=timeout,
            headers={
                'User-Agent': source2.USER_AGENT,
                'Accept': 'text/html',
                'Referer': source2.REFERER,
            },
            verify=False,
        )
        html = response.text or ''
    except Exception as exc:
        log('Player list failed: %s' % exc)
        return []
    players = []
    seen = set()
    for raw_url, raw_label in _PLAYER_BUTTON.findall(html):
        label = ' '.join((raw_label or '').split())
        if not label.lower().startswith('player'):
            continue
        url = (raw_url or '').strip()
        if url.startswith('/'):
            url = urljoin(watch_url, url)
        if not url or url in seen:
            continue
        seen.add(url)
        players.append({'label': label, 'url': url})
    players.sort(key=lambda item: _player_order(item.get('label')))
    return players


def _usable_stream(resolved):
    play_url = (resolved or {}).get('url')
    headers = (resolved or {}).get('headers') or {}
    return bool(play_url) and stream_looks_live(play_url, headers, timeout=5)


def _resolve_listed_player(player_item, referer):
    resolved = None
    try:
        resolved = source2.resolve_247_channel(
            player_item.get('url'),
            timeout=12,
            referer=referer,
        ) or {}
    except Exception as exc:
        log('Source resolve failed: %s' % exc)
        resolved = None
    if not _usable_stream(resolved):
        return None
    ready = dict(resolved)
    ready['label'] = player_item.get('label') or 'Source'
    return ready


def _source_progress_text(done, total, found):
    shown = min(total, done + 1) if done < total else total
    text = 'Checking sources... %s of %s' % (shown, total)
    if found == 1:
        text += '\nFound 1 link so far'
    elif found > 1:
        text += '\nFound %s links so far' % found
    return text


def _playable_players(players, referer, progress):
    ready = []
    lock = threading.Lock()
    gate = threading.BoundedSemaphore(3)
    state = {'done': 0}
    total = max(1, len(players))

    def work(player_item):
        with gate:
            try:
                item = _resolve_listed_player(player_item, referer)
            except Exception as exc:
                log('Player %s failed: %s' % (player_item.get('label'), exc))
                item = None
        with lock:
            state['done'] += 1
            if item:
                ready.append(item)

    threads = []
    for player_item in players:
        thread = threading.Thread(target=work, args=(player_item,))
        thread.daemon = True
        thread.start()
        threads.append(thread)
    tick = 0
    while any(thread.is_alive() for thread in threads):
        if progress.iscanceled():
            return None
        with lock:
            done = state['done']
            found = len(ready)
        percent = min(92, 8 + tick + int(60 * done / total))
        try:
            progress.update(percent, _source_progress_text(done, total, found))
        except Exception:
            pass
        xbmc.sleep(250)
        tick += 1
    ready.sort(key=lambda item: _player_order(item.get('label')))
    for index, item in enumerate(ready, start=1):
        item['label'] = 'Link %s' % index
    return ready


def _play_resolved(title, resolved):
    play_url = resolved.get('url')
    play_headers = resolved.get('headers') or {}
    resolver = resolved.get('resolver') or 'direct'
    log('Resolved via %s: %s' % (resolver, str(play_url)[:160]))
    return play_stream(title, play_url, play_headers)


def resolve_and_play(channel):
    title = channel.get('title') or 'Sports'
    watch_url = channel.get('url')
    if not watch_url:
        xbmcgui.Dialog().notification(
            paths.ADDON_NAME,
            'No stream URL on that source.',
            paths.ICON_PATH,
            3000
        )
        return

    progress = dialogs.Progress()
    progress.create(paths.ADDON_NAME, 'Resolving %s...' % title)
    try:
        referer = channel.get('referer') or source2.REFERER
        players = _listed_players(watch_url)
        if len(players) > 1:
            ready = _playable_players(players, watch_url, progress)
            if ready is None:
                return
            if not ready:
                progress.close()
                dialogs.ok(
                    paths.ADDON_NAME,
                    'Stream is down.\nPlease try another source.'
                )
                return
            progress.close()
            if len(ready) == 1:
                outcome = _play_resolved(title, ready[0])
                if outcome is not False:
                    wait_until_playback_ends(outcome)
                return
            labels = [item.get('label') or 'Player' for item in ready]
            while True:
                choice = dialogs.select('Choose a source', labels)
                if choice < 0:
                    return
                outcome = _play_resolved(title, ready[choice])
                if outcome is False or not playback_started(outcome):
                    continue
                wait_until_playback_ends(outcome)
                return

        log('Resolving Source Two: %s (%s)' % (title, watch_url))
        resolved = source2.resolve_247_channel(watch_url, referer=referer)
        if progress.iscanceled():
            return
        play_url = resolved.get('url')
        play_headers = resolved.get('headers') or {}
        if not play_url:
            raise RuntimeError('No play URL returned')

        try:
            progress.update(70, 'Checking stream...')
        except Exception:
            pass
        if progress.iscanceled():
            return
        if not stream_looks_live(play_url, play_headers):
            progress.close()
            dialogs.ok(
                paths.ADDON_NAME,
                'Stream is down.\nPlease try another source.'
            )
            return

        progress.close()
        _play_resolved(title, resolved)
    except Exception as exc:
        log('Source Two resolve failed: %s' % exc)
        try:
            progress.close()
        except Exception:
            pass
        detail = str(exc or '').lower()
        if 'timed out' in detail or 'timeout' in detail or 'max retries' in detail:
            reason = 'The stream source did not respond.'
        else:
            reason = 'This source is not broadcasting yet.'
        dialogs.ok(
            paths.ADDON_NAME,
            'Could not start the stream.\n%s' % reason
        )
