from __future__ import absolute_import

import hashlib
import json
import os
import re
import threading
import time
from datetime import datetime, timedelta

import pyxbmct
import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.sources.source2 import api as source2
from resources.lib.sources.sourceone import api as sourceone
from resources.lib.gui.buttons import text_button


HUB_OPTIONS = (
    {
        'key': 'live',
        'caption': 'LIVE SPORTS',
        'title': 'Live Sports',
        'meta': 'Categories  |  Live events  |  Sources',
        'overview': 'Browse live categories, pick an event, then choose a link to play.',
        'art': lambda: paths.SPORTS_LIVE_PATH,
        'action': 'live',
    },
    {
        'key': 'upcoming',
        'caption': 'UPCOMING',
        'title': 'Upcoming Events',
        'meta': 'Scheduled matches  |  Sources when available',
        'overview': 'See what is coming up next. Select an event to view every available source.',
        'art': lambda: paths.SPORTS_UPCOMING_PATH,
        'action': 'upcoming',
    },
    {
        'key': 'channels',
        'caption': '24/7 CHANNELS',
        'title': '24/7 Channels',
        'meta': 'Always on  |  Searchable channel list',
        'overview': 'Open the full 24/7 channel list. Favourite a channel, or add it to a playlist such as Sports, then browse those lists.',
        'art': lambda: paths.SPORTS_247_PATH,
        'action': 'channels',
    },
)


def _source_one_card(name):
    profile = os.path.join(paths.MEDIA_PATH, 'sports', name)
    if os.path.exists(profile):
        return profile
    bundled = paths.resource_path('media', 'sports', name)
    if os.path.exists(bundled):
        return bundled
    return ''


SOURCE_ONE_OPTIONS = (
    {
        'key': 'live',
        'caption': 'LIVE NOW',
        'title': 'Live Now',
        'meta': 'Categories  |  Live events',
        'overview': 'Live events grouped by category. Open one, pick a provider, then choose a link.',
        'art': lambda: _source_one_card('s1livenow.jpg'),
        'action': 'source_one_live',
    },
    {
        'key': 'soon',
        'caption': 'STARTS SOON',
        'title': 'Starts Soon',
        'meta': 'Starting within 2 hours',
        'overview': 'Events due to start in the next two hours. Pick a provider, then choose a link.',
        'art': lambda: _source_one_card('s1soon.jpg'),
        'action': 'source_one_soon',
    },
    {
        'key': 'today',
        'caption': 'EVENTS TODAY',
        'title': 'Events Today',
        'meta': 'Everything on today',
        'overview': 'Every event scheduled for today. Links often show up closer to the start.',
        'art': lambda: _source_one_card('s1today.jpg'),
        'action': 'source_one_today',
    },
)


def _sports_source_path():
    return os.path.join(paths.PROFILE_PATH, 'sports_source.json')


def sports_source():
    try:
        with open(_sports_source_path(), 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if data.get('source') in ('one', 'two'):
            return data['source']
    except Exception:
        pass
    return 'two'


def save_sports_source(source):
    source = source if source in ('one', 'two') else 'two'
    try:
        folder = os.path.dirname(_sports_source_path())
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(_sports_source_path(), 'w', encoding='utf-8') as handle:
            json.dump({'source': source}, handle)
    except Exception:
        pass
    return source


def _local_offset_minutes():
    delta = datetime.now() - datetime.utcnow()
    return int(round(delta.total_seconds() / 60.0))


def focus_texture():
    return os.path.join(
        os.path.dirname(pyxbmct.__file__),
        'textures',
        'estuary',
        'Button',
        'KeyboardKey.png'
    )


def busy_fetch(func, message):
    data, error, canceled = dialogs.busy(func, message)
    if canceled:
        return None
    if error is not None:
        dialogs.ok(paths.ADDON_NAME, 'Request failed.\n%s' % error)
        return None
    return data


def notify(message):
    xbmcgui.Dialog().notification(paths.ADDON_NAME, message, paths.ICON_PATH, 3000)


SOURCE_ONE_LIVE_URL = 'https://streamed.pk/api/matches/live'
SOURCE_ONE_IMAGE_BASE = 'https://streamed.pk'


def _norm_title(text):
    text = (text or '').lower()
    text = re.sub(r'[^a-z0-9]+', ' ', text)
    return ' '.join(text.split())


def _title_teams(text):
    normalized = re.sub(r'^(mlb|nfl|nba|nhl|wnba|mls)\s+', '', _norm_title(text))
    if ' vs ' not in normalized:
        return None
    left, right = normalized.split(' vs ', 1)
    left = left.strip()
    right = right.strip()
    if left and right:
        return (left, right)
    return None


def _last_sunday(year, month):
    day = datetime(year, month, 1) + timedelta(days=32)
    day = day.replace(day=1) - timedelta(days=1)
    while day.weekday() != 6:
        day -= timedelta(days=1)
    return day


def _uk_now():
    utc = datetime.utcnow()
    start = _last_sunday(utc.year, 3).replace(hour=1)
    end = _last_sunday(utc.year, 10).replace(hour=1)
    if start <= utc < end:
        return utc + timedelta(hours=1)
    return utc


def _kickoff_uk(clock):
    match = re.match(r'^\s*(\d{1,2}):(\d{2})', str(clock or ''))
    if not match:
        return None
    hour = int(match.group(1))
    minute = int(match.group(2))
    if hour > 23 or minute > 59:
        return None
    now = _uk_now()
    start = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if hour < 6 and now.hour >= 6:
        start += timedelta(days=1)
    elif hour >= 6 and now.hour < 6:
        start -= timedelta(days=1)
    return start


_MONTH_NUMBERS = {
    'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
    'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12,
}


def _month_number(name):
    text = (name or '').lower()
    if text.startswith('sept'):
        return 9
    return _MONTH_NUMBERS.get(text[:3])


def _date_span(day_a, day_b, month_name, year):
    month = _month_number(month_name)
    if not month:
        return None
    try:
        start = datetime(year, month, min(day_a, day_b)).date()
        end = datetime(year, month, max(day_a, day_b)).date()
    except ValueError:
        return None
    return start, end


def _title_span(title):
    """Day or day-range written in the fixture name, if it has one."""
    text = title or ''
    spans = []
    covered = []
    range_re = re.compile(
        r'(\d{1,2})(?:st|nd|rd|th)?\s*[\u2013\u2014\-]\s*'
        r'(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(20\d{2})',
        re.I,
    )
    for match in range_re.finditer(text):
        span = _date_span(
            int(match.group(1)),
            int(match.group(2)),
            match.group(3),
            int(match.group(4)),
        )
        if span:
            spans.append(span)
            covered.append(match.span())
    chars = list(text)
    for start, end in covered:
        for index in range(start, end):
            chars[index] = ' '
    single_re = re.compile(
        r'(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(20\d{2})',
        re.I,
    )
    for match in single_re.finditer(''.join(chars)):
        day = int(match.group(1))
        span = _date_span(day, day, match.group(2), int(match.group(3)))
        if span:
            spans.append(span)
    if not spans:
        return None
    return min(item[0] for item in spans), max(item[1] for item in spans)


def title_covers_today(title):
    span = _title_span(title)
    if span is None:
        return True
    today = _uk_now().date()
    return span[0] <= today <= span[1]


def title_is_over(title):
    span = _title_span(title)
    if span is None:
        return False
    return _uk_now().date() > span[1]


def event_has_started(event):
    if not title_covers_today((event or {}).get('title')):
        return False
    start = _kickoff_uk((event or {}).get('time'))
    if start is None:
        return True
    return start <= _uk_now()


LIVE_ON_NOW = timedelta(hours=3)


def event_is_on_now(event):
    if not title_covers_today((event or {}).get('title')):
        return False
    start = _kickoff_uk((event or {}).get('time'))
    if start is None:
        return False
    now = _uk_now()
    return start <= now <= start + LIVE_ON_NOW


def titles_match(left, right):
    a = _norm_title(left)
    b = _norm_title(right)
    if not a or not b:
        return False
    if a in b or b in a:
        return True
    teams_a = _title_teams(left)
    teams_b = _title_teams(right)
    if teams_a and all(part in b for part in teams_a):
        return True
    if teams_b and all(part in a for part in teams_b):
        return True
    return False


def _poster_url(poster):
    poster = (poster or '').strip()
    if not poster:
        return ''
    if poster.startswith('http://') or poster.startswith('https://'):
        return poster
    if poster.startswith('/'):
        return SOURCE_ONE_IMAGE_BASE + poster
    return SOURCE_ONE_IMAGE_BASE + '/' + poster.lstrip('/')


LIVE_TILE_SIZE = (1100, 560)
LIVE_TILE_RADIUS = 64


def _rounded_mask(size, radius):
    from PIL import Image, ImageDraw
    width, height = size
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    radius = max(1, min(int(radius), width // 2, height // 2))
    draw.rectangle([radius, 0, width - radius - 1, height - 1], fill=255)
    draw.rectangle([0, radius, width - 1, height - radius - 1], fill=255)
    draw.pieslice([0, 0, radius * 2, radius * 2], 180, 270, fill=255)
    draw.pieslice([width - radius * 2 - 1, 0, width - 1, radius * 2], 270, 360, fill=255)
    draw.pieslice([0, height - radius * 2 - 1, radius * 2, height - 1], 90, 180, fill=255)
    draw.pieslice([width - radius * 2 - 1, height - radius * 2 - 1, width - 1, height - 1], 0, 90, fill=255)
    return mask


def _decode_image_wic(path):
                                                                                
    if os.name != 'nt':
        return None
    import ctypes
    import uuid
    from ctypes import (
        HRESULT, POINTER, Structure, byref, c_double, c_ubyte, c_uint,
        c_void_p, c_wchar_p, windll, wintypes,
    )

    class GUID(Structure):
        _fields_ = [
            ('Data1', wintypes.DWORD),
            ('Data2', wintypes.WORD),
            ('Data3', wintypes.WORD),
            ('Data4', wintypes.BYTE * 8),
        ]

    def make_guid(text):
        value = uuid.UUID(text)
        data4 = (wintypes.BYTE * 8).from_buffer_copy(value.bytes[8:])
        return GUID(value.time_low, value.time_mid, value.time_hi_version, data4)

    def release(pointer):
        if not pointer:
            return
        table = ctypes.cast(pointer, POINTER(POINTER(c_void_p)))[0]
        ctypes.WINFUNCTYPE(ctypes.c_ulong, c_void_p)(table[2])(pointer)

    ole32 = windll.ole32
    started = ole32.CoInitialize(None)
    factory = c_void_p()
    decoder = c_void_p()
    frame = c_void_p()
    converter = c_void_p()
    try:
        result = ole32.CoCreateInstance(
            byref(make_guid('CACAF262-9370-4615-A13B-9F5539DA4C0A')),
            None,
            1,
            byref(make_guid('EC5EC8A9-C395-4314-9C77-54D7A935FF70')),
            byref(factory)
        )
        if result != 0 or not factory.value:
            return None
        factory_table = ctypes.cast(factory, POINTER(POINTER(c_void_p)))[0]
        create_decoder = ctypes.WINFUNCTYPE(
            HRESULT, c_void_p, c_wchar_p, c_void_p, wintypes.DWORD, c_uint, POINTER(c_void_p)
        )(factory_table[3])
        create_converter = ctypes.WINFUNCTYPE(
            HRESULT, c_void_p, POINTER(c_void_p)
        )(factory_table[10])
        if create_decoder(factory, path, None, 0x80000000, 1, byref(decoder)) != 0:
            return None
        decoder_table = ctypes.cast(decoder, POINTER(POINTER(c_void_p)))[0]
        get_frame = ctypes.WINFUNCTYPE(
            HRESULT, c_void_p, c_uint, POINTER(c_void_p)
        )(decoder_table[13])
        if get_frame(decoder, 0, byref(frame)) != 0:
            return None
        if create_converter(factory, byref(converter)) != 0:
            return None
        converter_table = ctypes.cast(converter, POINTER(POINTER(c_void_p)))[0]
        initialize = ctypes.WINFUNCTYPE(
            HRESULT, c_void_p, c_void_p, POINTER(GUID), c_uint, c_void_p, c_double, c_uint
        )(converter_table[8])
        pixel_format = make_guid('6FDDC324-4E03-4BFE-B185-3D77768DC90F')
        if initialize(converter, frame, byref(pixel_format), 0, None, 0.0, 0) != 0:
            return None
        get_size = ctypes.WINFUNCTYPE(
            HRESULT, c_void_p, POINTER(c_uint), POINTER(c_uint)
        )(converter_table[3])
        width = c_uint()
        height = c_uint()
        if get_size(converter, byref(width), byref(height)) != 0 or not width.value or not height.value:
            return None
        copy_pixels = ctypes.WINFUNCTYPE(
            HRESULT, c_void_p, c_void_p, c_uint, c_uint, POINTER(c_ubyte)
        )(converter_table[7])
        stride = width.value * 4
        raw = (c_ubyte * (stride * height.value))()
        if copy_pixels(converter, None, stride, stride * height.value, raw) != 0:
            return None
        from PIL import Image
        image = Image.frombuffer('RGBA', (width.value, height.value), bytes(raw), 'raw', 'BGRA', 0, 1)
        image.load()
        return image
    except Exception:
        return None
    finally:
        release(converter)
        release(frame)
        release(decoder)
        release(factory)
        if started == 0:
            ole32.CoUninitialize()


def _open_rgba(path):
    from PIL import Image
    try:
        return Image.open(path).convert('RGBA')
    except Exception:
        decoded = _decode_image_wic(path)
        if decoded is None:
            raise
        return decoded


def _round_live_poster(src_path, dest_path):
    try:
        from PIL import Image, ImageChops
    except ImportError:
        return ''
    try:
        source = _open_rgba(src_path)
        tile_w, tile_h = LIVE_TILE_SIZE
        scale = max(float(tile_w) / source.size[0], float(tile_h) / source.size[1])
        resized = source.resize(
            (max(1, int(source.size[0] * scale)), max(1, int(source.size[1] * scale))),
            Image.LANCZOS
        )
        left = max(0, (resized.size[0] - tile_w) // 2)
        top = max(0, (resized.size[1] - tile_h) // 2)
        cropped = resized.crop((left, top, left + tile_w, top + tile_h))
        mask = _rounded_mask((tile_w, tile_h), LIVE_TILE_RADIUS)
        cropped.putalpha(ImageChops.multiply(cropped.split()[-1], mask))
        cropped.save(dest_path, 'PNG')
        return dest_path
    except Exception:
        return ''


def _cache_live_poster(url, title, timeout=5):
    if not url:
        return ''
    cache_dir = os.path.join(paths.PROFILE_PATH, 'live_now')
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    digest = hashlib.md5((title + '|' + url).encode('utf-8')).hexdigest()
    extension = os.path.splitext(url.split('?')[0])[1] or '.webp'
    poster_file = os.path.join(cache_dir, digest + extension)
    tile_file = os.path.join(cache_dir, digest + '_tile.png')
    if os.path.exists(tile_file) and os.path.getsize(tile_file) > 1000:
        return tile_file
    if not os.path.exists(poster_file) or os.path.getsize(poster_file) <= 1000:
        import requests
        try:
            requests.packages.urllib3.disable_warnings()
        except Exception:
            pass
        response = requests.get(
            url,
            timeout=timeout,
            verify=False,
            headers={'User-Agent': 'Colossus/0.1', 'Accept': 'image/*,*/*'}
        )
        response.raise_for_status()
        with open(poster_file, 'wb') as handle:
            handle.write(response.content)
    rounded = _round_live_poster(poster_file, tile_file)
    return rounded or poster_file


def _fetch_source_one_live(timeout=5):
    import requests
    try:
        requests.packages.urllib3.disable_warnings()
    except Exception:
        pass
    response = requests.get(
        SOURCE_ONE_LIVE_URL,
        timeout=timeout,
        verify=False,
        headers={'User-Agent': 'Colossus/0.1', 'Accept': 'application/json'}
    )
    response.raise_for_status()
    data = response.json()
    return data if isinstance(data, list) else []


LIVE_NOW_TIMEOUT = 7


def load_live_now_events(timeout=LIVE_NOW_TIMEOUT):
    holder = {'result': []}

    def worker():
        try:
            holder['result'] = _load_live_now_events_inner(timeout) or []
        except Exception:
            holder['result'] = []

    thread = threading.Thread(target=worker)
    thread.daemon = True
    thread.start()
    thread.join(max(1.0, float(timeout)))
    return holder.get('result') or []


def _poster_catalog(timeout):
    catalog = []
    for url in (
        SOURCE_ONE_LIVE_URL,
        'https://streamed.pk/api/matches/all',
    ):
        try:
            import requests
            try:
                requests.packages.urllib3.disable_warnings()
            except Exception:
                pass
            response = requests.get(
                url,
                timeout=timeout,
                verify=False,
                headers={'User-Agent': 'Colossus/0.1', 'Accept': 'application/json'},
            )
            response.raise_for_status()
            rows = response.json()
        except Exception:
            continue
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict):
                continue
            poster = _poster_url(row.get('poster'))
            title = row.get('title') or ''
            if poster and title:
                catalog.append((title, poster))
    return catalog


def _match_poster(title, catalog):
    for other, poster in catalog:
        if titles_match(title, other):
            return poster
    return ''


def _load_font(size):
    from PIL import ImageFont
    candidates = (
        r'C:\Windows\Fonts\arialbd.ttf',
        r'C:\Windows\Fonts\arial.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        '/system/fonts/Roboto-Bold.ttf',
    )
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def _text_width(draw, text, font):
    try:
        return draw.textlength(text, font=font)
    except Exception:
        return len(text or '') * 28


def _wrap_text(draw, text, font, width):
    words = (text or '').split()
    if not words:
        return []
    lines = []
    current = words[0]
    for word in words[1:]:
        trial = current + ' ' + word
        if _text_width(draw, trial, font) <= width:
            current = trial
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def _plain_title(text):
    text = re.sub(r'[\U0001F1E6-\U0001F1FF]', '', text or '')
    text = re.sub(r'[\U0001F300-\U0001FAFF]', '', text)
    text = re.sub(r'[\u2600-\u27BF]', '', text)
    text = re.sub(r'\s+', ' ', text).strip(' :-|')
    return text or 'Live'


def _draw_centered(draw, text, font, y, fill, width):
    used = _text_width(draw, text, font)
    draw.text((max(48, (width - used) / 2), y), text, font=font, fill=fill)


def _event_card_fitted(dest, title, clock):
    try:
        from resources.lib.gui.cardtext import draw_fitted_card
        font_path = os.path.join(paths.MEDIA_PATH, 'live_font.png')
        if not os.path.exists(paths.LIVE_NOW_FILL_PATH) or not os.path.exists(font_path):
            return ''
        draw_fitted_card(paths.LIVE_NOW_FILL_PATH, font_path, dest, title, clock)
        if os.path.exists(dest) and os.path.getsize(dest) > 1000:
            return dest
    except Exception:
        return ''
    return ''


def _event_card(event):
    title = _plain_title((event or {}).get('title'))
    clock = (event or {}).get('time') or ''
    cache_dir = os.path.join(paths.PROFILE_PATH, 'live_now')
    if not os.path.exists(cache_dir):
        os.makedirs(cache_dir)
    digest = hashlib.md5(('%s|%s|v3' % (clock, title)).encode('utf-8')).hexdigest()
    dest = os.path.join(cache_dir, digest + '_card.png')
    if os.path.exists(dest) and os.path.getsize(dest) > 1000:
        return dest
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return _event_card_fitted(dest, title, clock)
    try:
        width, height = LIVE_TILE_SIZE
        image = Image.new('RGBA', LIVE_TILE_SIZE, (10, 18, 48, 255))
        draw = ImageDraw.Draw(image)
        usable_w = width - 220
        usable_h = height - 140
        chosen_size = 26
        lines = [title]
        line_height = 32
        clock_gap = 36 if clock else 0
        for size in (52, 46, 40, 34, 30, 26):
            large = _load_font(size)
            wrapped = _wrap_text(draw, title, large, usable_w)
            line_height = int(size * 1.2)
            clock_gap = int(size * 1.15) if clock else 0
            if (line_height * len(wrapped)) + clock_gap <= usable_h:
                chosen_size = size
                lines = wrapped
                break
        else:
            large = _load_font(chosen_size)
            lines = _wrap_text(draw, title, large, usable_w)
            room = max(1, int((usable_h - clock_gap) / max(1, line_height)))
            if len(lines) > room:
                lines = lines[:room]
                tail = lines[-1].rstrip('.')
                lines[-1] = tail[:max(1, len(tail) - 3)].rstrip() + '...'
        small = _load_font(max(24, int(chosen_size * 0.72)))
        large = _load_font(chosen_size)
        block = (line_height * len(lines)) + clock_gap
        y = max(70, (height - block) / 2)
        if clock:
            _draw_centered(draw, clock, small, y, (126, 224, 255, 255), width)
            y += clock_gap
        for line in lines:
            _draw_centered(draw, line, large, y, (255, 255, 255, 255), width)
            y += line_height
        raw = os.path.join(cache_dir, digest + '_card_raw.png')
        image.save(raw, 'PNG')
        rounded = _round_live_poster(raw, dest)
        try:
            os.remove(raw)
        except Exception:
            pass
        return rounded or dest
    except Exception:
        return ''


def _decorate_live_events(events, deadline):
    ready = []
    catalog = None
    for event in events or []:
        if event.get('provider') == 'sourceone' and event.get('poster_url'):
            poster_url = event.get('poster_url')
        else:
            if catalog is None:
                catalog = _poster_catalog(min(4.0, max(0.8, deadline - time.time())))
            poster_url = _match_poster(event.get('title') or '', catalog)
        poster = ''
        if poster_url and time.time() < deadline:
            poster = _cache_live_poster(
                poster_url,
                event.get('title') or 'live',
                timeout=min(3.0, max(0.8, deadline - time.time())),
            )
        event['poster'] = poster or _event_card(event)
        if event.get('poster') or event.get('title'):
            ready.append(event)
    return ready


def _mix_live_events(source_one, source_two):
    mixed = []
    left = list(source_one or [])
    right = list(source_two or [])
    while left or right:
        if left:
            mixed.append(left.pop(0))
        if right:
            mixed.append(right.pop(0))
    return mixed


def _load_live_now_events_inner(timeout):
    deadline = time.time() + max(1.0, float(timeout))

    def remaining():
        return max(0.8, deadline - time.time())

    try:
        events = source2.get_live_sports_events(
            source2.BASE_URL,
            'Live Sports',
            timeout=min(8.0, remaining()),
            allow_proxy=False,
        )
    except Exception:
        events = []
    on_now = []
    seen = set()
    for event in events or []:
        if not event_is_on_now(event) or not (event.get('channels') or []):
            continue
        key = (_norm_title(event.get('title')), event.get('time') or '')
        if key in seen:
            continue
        seen.add(key)
        on_now.append(dict(event))
    on_now.sort(key=lambda event: _kickoff_uk(event.get('time')) or datetime.min, reverse=True)
    on_now = on_now[:8]
    if not on_now:
        return []
    return _decorate_live_events(on_now, deadline)


def _source_one_art(kind):
    names = {
        'live': 's1livenow.jpg',
        'soon': 's1soon.jpg',
        'today': 's1today.jpg',
    }
    return _source_one_card(names.get(kind) or 's1livenow.jpg') or paths.SPORTS_LIVE_PATH


def _source_one_heading(kind):
    return {
        'live': 'LIVE NOW',
        'soon': 'STARTS SOON',
        'today': 'EVENTS TODAY',
    }.get(kind, 'LIVE NOW')


def open_source_one(kind):
    categories = busy_fetch(
        lambda: sourceone.categories(kind, offset=_local_offset_minutes()),
        'Loading %s...' % _source_one_heading(kind).title(),
    )
    if categories is None:
        return
    if not categories:
        notify('Nothing in %s right now.' % _source_one_heading(kind).title())
        return
    items = []
    total = sum(int(item.get('count') or 0) for item in categories)
    items.append({
        'label': 'All    (%s)' % total,
        'title': 'All',
        'meta': '%s events' % total,
        'overview': 'Show every event in this list.',
        'data': {'kind': kind, 'category': 'All', 'title': 'All'},
    })
    for category in categories:
        title = category.get('title') or 'Category'
        count = int(category.get('count') or 0)
        items.append({
            'label': '%s    (%s)' % (title, count),
            'title': title,
            'meta': '%s events' % count,
            'overview': 'Open %s.' % title,
            'data': {'kind': kind, 'category': title, 'title': title},
        })
    window = SportsBrowseWindow(
        heading=_source_one_heading(kind),
        status_text='%s categories  |  Select a category.' % len(items),
        items=items,
        on_select=_open_source_one_category,
        art_path=_source_one_art(kind),
        empty_title=_source_one_heading(kind).title(),
        empty_meta='Choose a category',
        empty_overview='Highlight a category, then select it to load the events.',
        list_heading='CATEGORIES',
    )
    window.doModal()
    del window


def _open_source_one_category(item):
    data = item.get('data') or {}
    kind = data.get('kind') or 'live'
    category = data.get('category') or 'All'
    title = data.get('title') or category
    rows = busy_fetch(
        lambda: sourceone.events(kind, category, offset=_local_offset_minutes()),
        'Loading %s...' % title,
    )
    if rows is None:
        return
    if not rows:
        notify('No events in %s.' % title)
        return
    items = []
    for event in rows:
        providers = event.get('sources') or []
        clock = event.get('time') or ''
        label = '%s    %s' % (clock, event.get('title') or 'Event') if clock else (event.get('title') or 'Event')
        items.append({
            'label': label,
            'title': event.get('title') or 'Event',
            'meta': '   |   '.join([part for part in (clock, event.get('cat') or '', '%s providers' % len(providers)) if part]),
            'overview': 'Select this event to see the providers, then pick a link.',
            'data': event,
        })
    window = SportsBrowseWindow(
        heading=title,
        status_text='%s events  |  Select an event.' % len(items),
        items=items,
        on_select=lambda chosen: _open_source_one_providers((chosen.get('data') or {})),
        art_path=_source_one_art(kind),
        empty_title=title,
        empty_meta='Choose an event',
        empty_overview='Select an event to see its providers.',
        allow_search=True,
        search_heading='Search events',
        list_heading='EVENTS',
        search_source=lambda query, pool=items: _filter_items(query, pool),
        search_list_heading='EVENTS',
    )
    window.doModal()
    del window


def _filter_items(query, items):
    query = (query or '').strip().lower()
    if not query:
        return None
    matched = []
    for item in items:
        haystack = ' '.join([
            item.get('title') or '',
            item.get('label') or '',
            item.get('meta') or '',
        ]).lower()
        if query in haystack:
            matched.append(item)
    return matched


def _open_source_one_providers(event):
    event = dict(event or {})
    sources = []
    for item in event.get('sources') or []:
        if isinstance(item, dict) and item.get('source') and item.get('id'):
            sources.append(item)
    if not sources:
        try:
            started = float(event.get('sort') or 0)
        except (TypeError, ValueError):
            started = 0
        if started and started <= time.time():
            dialogs.ok(paths.ADDON_NAME, 'Sorry, no links are available for this event at the moment.')
        else:
            dialogs.ok(paths.ADDON_NAME, 'This event has no links yet.\nTry closer to the start time.')
        return
    items = []
    for item in sources:
        name = str(item.get('source') or '').upper()
        items.append({
            'label': name,
            'title': name,
            'meta': event.get('title') or '',
            'overview': 'Load the links from %s.' % name,
            'data': {'event': event, 'source': item.get('source'), 'id': item.get('id')},
        })
    window = SportsBrowseWindow(
        heading=event.get('title') or 'Providers',
        status_text='%s providers  |  Select one.' % len(items),
        items=items,
        on_select=_open_source_one_streams,
        art_path=_source_one_art('live'),
        empty_title=event.get('title') or 'Providers',
        empty_meta='Choose a provider',
        empty_overview='Select a provider to load its links.',
        list_heading='PROVIDERS',
    )
    window.doModal()
    del window


def _open_source_one_streams(item):
    data = item.get('data') or {}
    event = data.get('event') or {}
    source = data.get('source') or ''
    source_id = data.get('id') or ''
    rows = busy_fetch(
        lambda: sourceone.streams(source, source_id),
        'Loading links...',
    )
    if rows is None:
        return
    if not rows:
        dialogs.ok(paths.ADDON_NAME, 'Sorry, no links are available for this event at the moment.')
        return
    items = []
    for stream in rows:
        quality = stream.get('quality') or ''
        language = stream.get('lang') or ''
        label = stream.get('title') or 'Stream'
        extra = '    '.join([part for part in (quality, language) if part])
        if extra:
            label = '%s    %s' % (label, extra)
        items.append({
            'label': label,
            'title': stream.get('title') or 'Stream',
            'meta': '   |   '.join([part for part in (quality, language) if part]),
            'overview': 'Play this link. If it does not start, the list stays here so you can try another.',
            'data': {'event': event, 'streams': rows, 'stream': stream},
        })
    title = event.get('title') or 'Links'

    def choose(chosen):
        payload = chosen.get('data') or {}
        if _play_source_one(title, payload.get('stream') or {}, payload.get('streams') or []):
            return

    window = SportsBrowseWindow(
        heading=title,
        status_text='%s links  |  Select one.' % len(items),
        items=items,
        on_select=choose,
        art_path=_source_one_art('live'),
        empty_title=title,
        empty_meta='Choose a link',
        empty_overview='Select a link to play it.',
        list_heading='LINKS',
    )
    window.doModal()
    del window


def _play_source_one(title, stream, streams):
    del streams
    if not stream:
        return False
    result = busy_fetch(
        lambda: sourceone.resolve(
            embed_url=stream.get('embed_url') or '',
            stream_key=stream.get('stream_ident') or '',
            stream_title=stream.get('stream_title') or '',
            stream_no=stream.get('stream_no') or '1',
        ),
        'Opening %s...' % (stream.get('title') or 'link'),
    )
    if result is None:
        return False
    if not result.get('url'):
        notify('That link did not start. Try another.')
        return False
    outcome = player.play_stream(title, result.get('url'), result.get('headers') or {})
    if outcome is False or not player.wait_until_playback_ends(outcome):
        notify('That link did not start. Try another.')
        return False
    return True


def open_event_sources(event):
    event = event or {}
    if event.get('provider') == 'sourceone':
        _open_source_one_providers(event)
        return
    _open_event_sources({'data': event})


def category_item(title, url, count):
    return {
        'label': '%s    (%s)' % (title, count),
        'title': title,
        'meta': '%s live events' % count,
        'overview': 'Open %s to view events that have already kicked off, then choose a source to play.' % title,
        'data': {'title': title, 'url': url, 'count': count},
    }


def event_item(event):
    event = dict(event or {})
    channels = visible_channels(event.get('channels') or [])
    event['channels'] = channels
    title = event.get('title') or 'Event'
    event_time = event.get('time') or ''
    category = event.get('cat') or ''
    label = '%s    %s' % (event_time, title) if event_time else title
    meta_parts = [part for part in (event_time, category, '%s sources' % len(channels)) if part]
    return {
        'label': label,
        'title': title,
        'meta': '   |   '.join(meta_parts),
        'overview': 'Select this event to see every available source, then play one.',
        'data': event,
    }


# Titles from the 24/7 list. Word boundaries keep normal names such as
# Essex or a numbered sports channel from being treated as adult.
_ADULT_CHANNEL = re.compile(
    r'(?i)(?:'
    r'\b18\s*\+'
    r'|\+\s*18\b'
    r'|\b18\s*plus\b'
    r'|\bxxx+\b'
    r'|\badults?\b'
    r'|\bporn(?:hub|stars?)?\b'
    r'|\bx+videos?\b'
    r'|\bbrazzers\b'
    r'|\bplayboy\b'
    r'|\bhustler\b'
    r'|\bonly\s*fans\b'
    r'|\bnsfw\b'
    r'|\berotic'
    r'|\bsex(?:y|cam|cams)?\b'
    r')'
)


def adult_channels_blocked():
    return paths.ADDON.getSetting('disable_adult') == 'true'


def channel_looks_adult(channel):
    if isinstance(channel, dict):
        title = channel.get('title') or channel.get('name') or ''
    else:
        title = channel or ''
    return bool(_ADULT_CHANNEL.search(str(title)))


def visible_channels(channels):
    channels = list(channels or [])
    if not adult_channels_blocked():
        return channels
    return [channel for channel in channels if not channel_looks_adult(channel)]


CHANNEL_LISTS_PATH = os.path.join(paths.PROFILE_PATH, 'channel_lists.json')


def channel_key(channel):
    channel = channel or {}
    url = str(channel.get('url') or '').strip()
    if url:
        return url
    title = str(channel.get('title') or '').strip().lower()
    return 'title:%s' % title if title else ''


def channel_identity(channel):
    title = ' '.join(str((channel or {}).get('title') or '').split()).lower()
    if title:
        return title
    return channel_key(channel)


def same_channel(left, right):
    if channel_identity(left) and channel_identity(left) == channel_identity(right):
        return True
    left_key = channel_key(left)
    return bool(left_key) and left_key == channel_key(right)


def unique_channels(records):
    kept = []
    for record in records or []:
        if not isinstance(record, dict) or not channel_key(record):
            continue
        if any(same_channel(record, existing) for existing in kept):
            continue
        kept.append(channel_record(record))
    return kept


def channel_record(channel):
    record = {}
    for key, value in (channel or {}).items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            record[key] = value
    if not record.get('title'):
        record['title'] = 'Channel'
    return record


def load_channel_lists():
    data = {'favs': [], 'playlists': []}
    try:
        if not os.path.exists(CHANNEL_LISTS_PATH):
            return data
        with open(CHANNEL_LISTS_PATH, 'r', encoding='utf-8') as handle:
            raw = json.load(handle)
    except Exception:
        return data
    if not isinstance(raw, dict):
        return data
    data['favs'] = unique_channels(raw.get('favs') or [])
    seen_names = set()
    for playlist in raw.get('playlists') or []:
        if not isinstance(playlist, dict):
            continue
        name = ' '.join(str(playlist.get('name') or '').split())
        if not name or name.lower() in seen_names:
            continue
        seen_names.add(name.lower())
        data['playlists'].append({
            'name': name[:40],
            'channels': unique_channels(playlist.get('channels') or []),
        })
    return data


def save_channel_lists(data):
    try:
        folder = os.path.dirname(CHANNEL_LISTS_PATH)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(CHANNEL_LISTS_PATH, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
    except Exception:
        pass


def channel_item(channel, meta='24/7 channel', overview=None):
    title = channel.get('title') or 'Channel'
    return {
        'label': title,
        'title': title,
        'meta': meta,
        'overview': overview or 'Play this channel now. Colossus will resolve the stream and start playback.',
        'data': channel,
    }


def _select_live_sports_item(item):
    data = item.get('data') or {}
    if data.get('type') == 'daddylive_event':
        _open_event_sources(item)
        return
    _open_live_category(item)


def _search_live_events(query, cache):
    query = (query or '').strip().lower()
    if not query:
        return None
    if cache.get('items') is None:
        events = busy_fetch(
            lambda: source2.get_live_sports_events(source2.BASE_URL, 'Live Sports'),
            'Searching events...'
        )
        if events is None:
            return None
        cache['items'] = [
            event_item(event) for event in events if event_has_started(event)
        ]
    matched = []
    for item in cache['items']:
        event = item.get('data') or {}
        channels = ' '.join(
            channel.get('title') or ''
            for channel in visible_channels(event.get('channels') or [])
        )
        haystack = ' '.join([
            item.get('title') or '',
            item.get('label') or '',
            event.get('time') or '',
            event.get('cat') or '',
            channels,
        ]).lower()
        if query in haystack:
            matched.append(item)
    return matched


def open_live_sports():
    categories = busy_fetch(source2.get_live_sports_categories, 'Loading Live Sports...')
    if categories is None:
        return
    if not categories:
        notify('No live sports found.')
        return

    items = []
    total = sum(int(item.get('count') or 0) for item in categories)
    items.append(category_item('All', source2.BASE_URL, total))
    for category in categories:
        title = category.get('title') or 'Category'
        count = int(category.get('count') or 0)
        items.append(category_item(title, category.get('url') or source2.BASE_URL, count))

    event_cache = {'items': None}
    window = SportsBrowseWindow(
        heading='LIVE SPORTS',
        status_text='%s categories  |  Select a category.' % len(items),
        items=items,
        on_select=_select_live_sports_item,
        art_path=paths.SPORTS_LIVE_PATH,
        empty_title='Live Sports',
        empty_meta='Choose a category',
        empty_overview='Highlight a category to preview it, then select it to load events.',
        allow_search=True,
        search_heading='Search events',
        list_heading='CATEGORIES',
        search_source=lambda query: _search_live_events(query, event_cache),
        search_list_heading='EVENTS'
    )
    window.doModal()
    del window


def _open_live_category(item):
    data = item.get('data') or {}
    title = data.get('title') or 'Live Sports'
    url = data.get('url') or source2.BASE_URL
    events = busy_fetch(
        lambda: source2.get_live_sports_events(url, category_title=title),
        'Loading %s...' % title
    )
    if events is None:
        return
    started = [event for event in events if event_has_started(event)]
    if not started:
        notify('Nothing in %s has kicked off yet. Later games are in Upcoming.' % title)
        return
    _open_event_list(title.upper(), started, paths.SPORTS_LIVE_PATH)


def _later_events(events):
    later = []
    seen = set()
    for event in events or []:
        if title_is_over(event.get('title')) or event_has_started(event):
            continue
        key = (_norm_title(event.get('title')), event.get('time') or '')
        if key in seen:
            continue
        seen.add(key)
        later.append(event)
    later.sort(key=lambda event: _kickoff_uk(event.get('time')) or datetime.max)
    return later


def open_upcoming_events():
    def load():
        upcoming = source2.get_upcoming_events() or []
        schedule = source2.get_live_sports_events(source2.BASE_URL, 'Live Sports') or []
        return _later_events(list(upcoming) + list(schedule))

    events = busy_fetch(load, 'Loading Upcoming Events...')
    if events is None:
        return
    _open_event_list('UPCOMING EVENTS', events, paths.SPORTS_UPCOMING_PATH)


def open_247_channels():
    channels = busy_fetch(source2.get_247_channels, 'Loading 24/7 Channels...')
    if channels is None:
        return
    channels = visible_channels(channels)
    if not channels:
        notify('No 24/7 channels found.')
        return

    window = ChannelListsWindow(channels)
    window.doModal()
    del window


def _open_event_list(heading, events, art_path):
    if not events:
        notify('No events found.')
        return

    items = [event_item(event) for event in events]
    window = SportsBrowseWindow(
        heading=heading,
        status_text='%s events  |  Select an event.' % len(items),
        items=items,
        on_select=_open_event_sources,
        art_path=art_path,
        empty_title=heading.title(),
        empty_meta='Select an event',
        empty_overview='Highlight an event to preview it, then select it to view sources.',
        allow_search=True,
        search_heading='Search events',
        list_heading='EVENTS'
    )
    window.doModal()
    del window


def _open_event_sources(item):
    event = item.get('data') or {}
    channels = visible_channels(event.get('channels') or [])
    title = event.get('title') or 'Event'
    if not channels:
        notify('No sources found for that event.')
        return

    items = []
    total = len(channels)
    for index, channel in enumerate(channels, start=1):
        items.append(channel_item(
            channel,
            meta='Source %s of %s' % (index, total),
            overview='Play this source for %s.' % title
        ))

    window = SportsBrowseWindow(
        heading=title.upper(),
        status_text='%s sources  |  Select a source to play.' % total,
        items=items,
        on_select=_play_channel_item,
        art_path=event.get('poster') or paths.SPORTS_LIVE_PATH,
        empty_title=title,
        empty_meta='Select a source',
        empty_overview='Highlight a source, then select it to resolve and play.',
        allow_search=False,
        list_heading='SOURCES'
    )
    window.doModal()
    del window


def _play_channel_item(item):
    player.resolve_and_play(item.get('data') or {})


class SportsHubWindow(ColossusFullWindow):
    def __init__(self):
        super(SportsHubWindow, self).__init__('')
        self.option_images = []
        self.option_buttons = []
        self.option_captions = []
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self._apply_source()
        self.setFocus(self.option_buttons[0])
        self.update_hub_preview()

    def _options(self):
        return HUB_OPTIONS

    def _run_action(self, name):
        actions = {
            'live': open_live_sports,
            'upcoming': open_upcoming_events,
            'channels': open_247_channels,
        }
        action = actions.get(name)
        if action:
            action()

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)

        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)

        self.header_label = pyxbmct.Label(
            '[B]SPORTS[/B]',
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.header_label, 2, 14, 6, 20)

        self.status_label = pyxbmct.Label(
            '',
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.status_label, 2, 36, 6, 40)

        self.poster = pyxbmct.Image(paths.SPORTS_LIVE_PATH, aspectRatio=0)
        self.placeControl(self.poster, 12, 3, 16, 16)

        self.title_label = pyxbmct.Label(
            '',
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.title_label, 12, 22, 8, 74)

        self.meta_label = pyxbmct.Label(
            '',
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.meta_label, 20, 22, 5, 74)

        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 26, 22, 10, 74)

        layouts = ((40, 8), (40, 37), (40, 66))
        for index, (row, column) in enumerate(layouts):
            image = pyxbmct.Image(paths.ICON_PATH, aspectRatio=0)
            self.option_images.append(image)
            self.placeControl(image, row, column, 40, 26, pad_x=0, pad_y=0)

            button = pyxbmct.Button('', noFocusTexture='', focusTexture=focus_texture())
            self.option_buttons.append(button)
            self.placeControl(button, row, column, 40, 26, pad_x=0, pad_y=0)
            self.connect(button, lambda index=index: self._activate(index))

            caption = pyxbmct.Label(
                '',
                font='font13',
                textColor='0xFFFFFFFF',
                alignment=pyxbmct.ALIGN_CENTER
            )
            self.option_captions.append(caption)
            self.placeControl(caption, 80, column, 6, 26)

    def _activate(self, index):
        options = self._options()
        if index >= len(options):
            return
        self._run_action(options[index].get('action'))

    def _apply_source(self):
        options = self._options()
        self.status_label.setLabel('Choose Live Sports, Upcoming, or 24/7.')
        for index, option in enumerate(options):
            art = option['art']()
            image = art if art and os.path.exists(art) else paths.ICON_PATH
            try:
                self.option_images[index].setImage(image)
            except Exception:
                pass
            self.option_captions[index].setLabel('[B]%s[/B]' % option['caption'])

    def set_navigation(self):
        left, middle, right = self.option_buttons

        self.back_button.controlDown(left)
        self.back_button.controlRight(right)

        left.controlUp(self.back_button)
        left.controlRight(middle)

        middle.controlUp(self.back_button)
        middle.controlLeft(left)
        middle.controlRight(right)

        right.controlUp(self.back_button)
        right.controlLeft(middle)

    def onAction(self, action):
        super(SportsHubWindow, self).onAction(action)
        self.update_hub_preview()

    def update_hub_preview(self):
        try:
            focused = self.getFocus()
        except Exception:
            return

        options = self._options()
        current = options[0]
        for index, option in enumerate(options):
            caption = self.option_captions[index]
            if focused == self.option_buttons[index]:
                current = option
                caption.setLabel('[COLOR aqua][B]%s[/B][/COLOR]' % option['caption'])
            else:
                caption.setLabel('[B]%s[/B]' % option['caption'])

        art = current['art']()
        try:
            self.poster.setImage(art if art and os.path.exists(art) else paths.ICON_PATH)
        except Exception:
            pass
        self.title_label.setLabel('[B]%s[/B]' % current['title'])
        self.meta_label.setLabel(current['meta'])
        self.overview_box.setText(current['overview'])


class SportsBrowseWindow(ColossusFullWindow):
    def __init__(
        self,
        heading,
        status_text,
        items,
        on_select,
        art_path,
        empty_title,
        empty_meta,
        empty_overview,
        allow_search=False,
        search_heading='Search',
        search_button_text='Search',
        list_heading='RESULTS',
        search_source=None,
        search_list_heading='EVENTS'
    ):
        super(SportsBrowseWindow, self).__init__('')
        self.heading = heading
        self.status_text = status_text
        self.all_items = list(items or [])
        self.visible_items = list(self.all_items)
        self.on_select = on_select
        self.art_path = art_path if os.path.exists(art_path) else paths.ICON_PATH
        self.empty_title = empty_title
        self.empty_meta = empty_meta
        self.empty_overview = empty_overview
        self.allow_search = allow_search
        self.search_heading = search_heading
        self.search_button_text = search_button_text or 'Search'
        self.list_heading_text = list_heading
        self.search_source = search_source
        self.search_list_heading = search_list_heading or list_heading
        self.current_index = -1
        self.setup_canvas()
        self.set_controls()
        self.set_navigation()
        self.populate_list()
        self.setFocus(self.results_list)

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)

        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 2, 2, 6, 10)
        self.connect(self.back_button, self.close)

        self.header_label = pyxbmct.Label(
            '[B]%s[/B]' % self.heading,
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.header_label, 2, 14, 6, 48)

        self.status_label = pyxbmct.Label(
            self.status_text,
            font='font12',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.status_label, 2, 64, 6, 32)

        self.poster = pyxbmct.Image(self.art_path, aspectRatio=0)
        self.placeControl(self.poster, 12, 3, 48, 20)

        self.title_label = pyxbmct.Label(
            '[B]%s[/B]' % self.empty_title,
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.title_label, 12, 25, 10, 38)

        self.meta_label = pyxbmct.Label(
            self.empty_meta,
            font='font13',
            textColor='0xFFD0D6DE',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.meta_label, 23, 25, 6, 38)

        self.overview_box = pyxbmct.TextBox(font='font13', textColor='0xFFE8EEF4')
        self.placeControl(self.overview_box, 30, 25, 28, 38)
        self.overview_box.setText(self.empty_overview)

        if self.allow_search:
            self.search_button = text_button(self.search_button_text)
            self.placeControl(self.search_button, 66, 3, 8, 18)
            self.connect(self.search_button, self.search_items)
        else:
            self.search_button = None

        self.list_heading = pyxbmct.Label(
            '[B]%s[/B]' % self.list_heading_text,
            font='font13',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_LEFT
        )
        self.placeControl(self.list_heading, 8, 68, 6, 28)

        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)

    def move_control(self, control, row, column, rowspan=1, columnspan=1, pad_x=5, pad_y=5):
        control.setPosition(
            (self.grid_x + self.tile_width * column) + pad_x,
            (self.grid_y + self.tile_height * row) + pad_y,
        )
        control.setWidth(self.tile_width * columnspan - 2 * pad_x)
        control.setHeight(self.tile_height * rowspan - 2 * pad_y)

    def set_navigation(self):
        if self.search_button is not None:
            self.back_button.controlRight(self.search_button)
            self.back_button.controlDown(self.search_button)
        else:
            self.back_button.controlRight(self.results_list)
            self.back_button.controlDown(self.results_list)

        if self.search_button is not None:
            self.search_button.controlUp(self.back_button)
            self.search_button.controlLeft(self.back_button)
            self.search_button.controlRight(self.results_list)
            self.search_button.controlDown(self.results_list)
            self.results_list.controlLeft(self.search_button)
            self.results_list.controlUp(self.search_button)
        else:
            self.results_list.controlLeft(self.back_button)
            self.results_list.controlUp(self.back_button)

    def onAction(self, action):
        super(SportsBrowseWindow, self).onAction(action)
        self.update_preview()

    def populate_list(self, query=''):
        query = (query or '').strip().lower()
        self.results_list.reset()
        self.current_index = -1
        searched_events = False
        if query and self.search_source:
            found = self.search_source(query)
            if found is None:
                self.visible_items = list(self.all_items)
            else:
                self.visible_items = list(found)
                searched_events = True
        elif query:
            self.visible_items = []
            for item in self.all_items:
                haystack = ' '.join([
                    item.get('label') or '',
                    item.get('title') or '',
                    item.get('meta') or '',
                    item.get('overview') or '',
                    item.get('search') or '',
                ]).lower()
                if query in haystack:
                    self.visible_items.append(item)
        else:
            self.visible_items = list(self.all_items)
        try:
            self.list_heading.setLabel(
                '[B]%s[/B]' % (self.search_list_heading if searched_events else self.list_heading_text)
            )
        except Exception:
            pass

        if not self.visible_items:
            self.results_list.addItem('No matches')
            self.status_label.setLabel('0 matches  |  Try another search.')
            self.title_label.setLabel('[B]No matches[/B]')
            self.meta_label.setLabel('')
            self.overview_box.setText('No items matched that search.')
            return

        for item in self.visible_items:
            self.results_list.addItem(item.get('label') or '')
        count_label = 'matches' if query else self.list_heading_text.lower()
        self.status_label.setLabel('%s %s  |  %s' % (
            len(self.visible_items),
            count_label,
            'Select an item.'
        ))
        self.update_preview(force=True)

    def search_items(self):
        keyboard = xbmc.Keyboard('', self.search_heading)
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return
        self.populate_list(keyboard.getText())
        self.setFocus(self.results_list)

    def select_current(self):
        position = self.results_list.getSelectedPosition()
        if position < 0 or position >= len(self.visible_items):
            return
        self.on_select(self.visible_items[position])

    def update_preview(self, force=False):
        if not self.visible_items:
            return
        try:
            index = self.results_list.getSelectedPosition()
        except Exception:
            return
        if index < 0 or index >= len(self.visible_items):
            return
        if not force and index == self.current_index:
            return
        self.current_index = index
        item = self.visible_items[index]
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or self.empty_title))
        self.meta_label.setLabel(item.get('meta') or '')
        self.overview_box.setText(item.get('overview') or self.empty_overview)
        try:
            self.poster.setImage(self.art_path)
        except Exception:
            pass


class ChannelListsWindow(SportsBrowseWindow):
    def __init__(self, channels):
        self.live_channels = list(channels or [])
        self.library = load_channel_lists()
        self._absorb_live()
        self.view = 'all'
        self.playlist_name = ''
        super(ChannelListsWindow, self).__init__(
            heading='24/7 CHANNELS',
            status_text='%s channels  |  Select a channel to play.' % len(self.live_channels),
            items=[channel_item(channel) for channel in self.live_channels],
            on_select=_play_channel_item,
            art_path=paths.SPORTS_247_PATH,
            empty_title='24/7 Channels',
            empty_meta='Always on',
            empty_overview=(
                'Highlight a channel and press Favourite, or Add to playlist. '
                'Favs and Playlists show only the channels you saved. '
                'Playlists can also rename or delete a whole list.'
            ),
            allow_search=False,
            search_heading='Search channels',
            list_heading='CHANNELS',
        )

    def set_controls(self):
        super(ChannelListsWindow, self).set_controls()
        self.fav_button = text_button('Favourite')
        self.placeControl(self.fav_button, 62, 2, 5, 22)
        self.connect(self.fav_button, self.toggle_favourite)
        self.favs_button = text_button('Favs')
        self.placeControl(self.favs_button, 67, 2, 5, 22)
        self.connect(self.favs_button, self.show_favs)
        self.add_button = text_button('Add to playlist')
        self.placeControl(self.add_button, 72, 2, 5, 22)
        self.connect(self.add_button, self.add_or_remove)
        self.playlists_button = text_button('Playlists')
        self.placeControl(self.playlists_button, 77, 2, 5, 22)
        self.connect(self.playlists_button, self.open_playlists)
        self.move_up_button = text_button('Move up')
        self.placeControl(self.move_up_button, 82, 2, 5, 22)
        self.connect(self.move_up_button, lambda: self._move_channel(-1))
        self.move_down_button = text_button('Move down')
        self.placeControl(self.move_down_button, 87, 2, 5, 22)
        self.connect(self.move_down_button, lambda: self._move_channel(1))
        self.search_button = text_button('Search')
        self.placeControl(self.search_button, 82, 2, 6, 22)
        self.connect(self.search_button, self.search_items)
        self._editing_layout = None
        self._layout_edit_buttons()

    def _layout_edit_buttons(self):
        editing = self.view == 'playlist'
        if self._editing_layout == editing:
            return
        self._editing_layout = editing
        if editing:
            self.move_control(self.move_up_button, 82, 2, 5, 22)
            self.move_up_button.setVisible(True)
            self.move_control(self.move_down_button, 87, 2, 5, 22)
            self.move_down_button.setVisible(True)
            self.move_control(self.search_button, 92, 2, 6, 22)
        else:
            self.move_up_button.setVisible(False)
            self.move_down_button.setVisible(False)
            self.move_control(self.search_button, 82, 2, 6, 22)

    def set_navigation(self):
        buttons = [
            self.fav_button,
            self.favs_button,
            self.add_button,
            self.playlists_button,
        ]
        if self.view == 'playlist':
            buttons.extend((self.move_up_button, self.move_down_button))
        buttons.append(self.search_button)
        self.back_button.controlDown(buttons[0])
        self.back_button.controlRight(self.results_list)
        for index, button in enumerate(buttons):
            button.controlUp(self.back_button if index == 0 else buttons[index - 1])
            if index + 1 < len(buttons):
                button.controlDown(buttons[index + 1])
            else:
                button.controlDown(self.results_list)
            button.controlRight(self.results_list)
            button.controlLeft(self.back_button)
        self.results_list.controlLeft(buttons[0])
        self.results_list.controlUp(self.back_button)

    def _absorb_live(self):
        fresh = {}
        for channel in self.live_channels:
            key = channel_key(channel)
            if key:
                fresh[key] = channel_record(channel)
        changed = False

        def refresh(records):
            updated = []
            local_changed = False
            for record in records:
                newer = fresh.get(channel_key(record))
                if newer and newer != record:
                    updated.append(newer)
                    local_changed = True
                else:
                    updated.append(record)
            return updated, local_changed

        favs, favs_changed = refresh(self.library.get('favs') or [])
        changed = changed or favs_changed
        self.library['favs'] = favs
        for playlist in self.library.get('playlists') or []:
            channels, playlist_changed = refresh(playlist.get('channels') or [])
            playlist['channels'] = channels
            changed = changed or playlist_changed
        if changed:
            save_channel_lists(self.library)

    def _is_fav(self, item):
        channel = (item or {}).get('data') or item
        return any(same_channel(channel, record) for record in (self.library.get('favs') or []))

    def _playlist_names_for(self, channel):
        key = channel_key(channel)
        if not key:
            return []
        names = []
        for playlist in self.library.get('playlists') or []:
            for record in playlist.get('channels') or []:
                if same_channel(channel, record):
                    names.append(playlist.get('name') or '')
                    break
        return [name for name in names if name]

    def _merge_saved(self, records):
        fresh = {}
        for channel in self.live_channels:
            key = channel_key(channel)
            if key:
                fresh[key] = channel
        merged = []
        for record in records or []:
            if not channel_key(record):
                continue
            if any(same_channel(record, existing) for existing in merged):
                continue
            merged.append(fresh.get(channel_key(record)) or record)
        return visible_channels(merged)

    def _pool(self):
        if self.view == 'favs':
            records = self._merge_saved(self.library.get('favs') or [])
        elif self.view == 'playlist':
            records = []
            for playlist in self.library.get('playlists') or []:
                if playlist.get('name') == self.playlist_name:
                    records = self._merge_saved(playlist.get('channels') or [])
                    break
        else:
            records = list(self.live_channels)
        items = []
        for channel in records:
            item = channel_item(channel)
            title = item.get('title') or 'Channel'
            marks = []
            if self._is_fav(item):
                marks.append('[COLOR FF7EE0FF]*[/COLOR]')
            if self._playlist_names_for(channel):
                marks.append('[COLOR FF7EE0FF]![/COLOR]')
            if marks:
                item['label'] = '%s  %s' % (' '.join(marks), title)
            items.append(item)
        return items

    def _current_item(self):
        if not self.visible_items:
            return None
        index = self.current_index
        if index < 0 or index >= len(self.visible_items):
            try:
                index = self.results_list.getSelectedPosition()
            except Exception:
                return None
        if index < 0 or index >= len(self.visible_items):
            return None
        return self.visible_items[index]

    def _heading(self):
        if self.view == 'favs':
            return 'FAVS'
        if self.view == 'playlist':
            return (self.playlist_name or 'Playlist').upper()
        return 'CHANNELS'

    def _empty_message(self):
        if self.view == 'favs':
            return (
                'No favourites yet',
                'Highlight a channel and press Favourite. Favs then shows only those channels.',
            )
        if self.view == 'playlist':
            return (
                'Playlist is empty',
                'Press All channels, highlight one, and press Add to playlist. '
                'Inside a playlist, Remove takes a channel out. Move up and Move down change the order. '
                'Playlists can rename or delete the whole list.',
            )
        return ('No channels', 'No channels are available right now.')

    def populate_list(self, query=''):
        pool = self._pool()
        self._sync_buttons()
        try:
            self.list_heading.setLabel('[B]%s[/B]' % self._heading())
        except Exception:
            pass
        if not pool:
            title, overview = self._empty_message()
            self.visible_items = []
            self.current_index = -1
            self._repaint_list([title])
            self.status_label.setLabel(title)
            self.title_label.setLabel('[B]%s[/B]' % title)
            self.meta_label.setLabel('')
            self.overview_box.setText(overview)
            return
        saved = self.all_items
        self.all_items = pool
        try:
            super(ChannelListsWindow, self).populate_list(query)
        finally:
            self.all_items = saved
        self._repaint_list([item.get('label') or '' for item in self.visible_items])
        try:
            self.list_heading.setLabel('[B]%s[/B]' % self._heading())
        except Exception:
            pass
        if self.visible_items and not (query or '').strip():
            if self.view == 'favs':
                self.status_label.setLabel('%s favs  |  Select a channel to play.' % len(self.visible_items))
            elif self.view == 'playlist':
                self.status_label.setLabel(
                    '%s in %s  |  Play, Remove, or Move up and Move down.' % (len(self.visible_items), self.playlist_name)
                )
            else:
                self.status_label.setLabel('%s channels  |  Select a channel to play.' % len(self.visible_items))
        self._sync_buttons()

    def update_preview(self, force=False):
        super(ChannelListsWindow, self).update_preview(force=force)
        item = self._current_item()
        if not item:
            self._sync_buttons()
            return
        notes = []
        if self._is_fav(item):
            notes.append('This channel is saved in favs.')
        names = self._playlist_names_for(item.get('data') or {})
        if names:
            notes.append('This channel is added to a playlist: %s.' % ', '.join(names))
        if notes:
            text = item.get('overview') or ''
            self.overview_box.setText(text + '\n\n' + '\n'.join(notes))
        self._sync_buttons()

    def _repaint_list(self, labels):
        # The first fill happens before the window is shown. Later fills of
        # the same list stay on screen until the window is opened again.
        if not getattr(self, '_ready', False):
            self._ready = True
            return
        try:
            self.removeControl(self.results_list)
        except Exception:
            pass
        self.results_list = pyxbmct.List()
        self.placeControl(self.results_list, 14, 66, 78, 32)
        self.connect(self.results_list, self.select_current)
        for label in labels:
            self.results_list.addItem(label)
        try:
            self.set_navigation()
        except Exception:
            pass

    def _sync_buttons(self):
        item = self._current_item()
        self.fav_button.setLabel('Unfavourite' if item and self._is_fav(item) else 'Favourite')
        self.favs_button.setLabel('All channels' if self.view != 'all' else 'Favs')
        self.add_button.setLabel('Remove' if self.view == 'playlist' else 'Add to playlist')
        previous = self._editing_layout
        self._layout_edit_buttons()
        if previous != self._editing_layout:
            try:
                self.set_navigation()
            except Exception:
                pass

    def _reselect(self, key):
        if not key:
            return
        for index, item in enumerate(self.visible_items):
            if channel_key(item.get('data') or {}) == key:
                try:
                    self.results_list.selectItem(index)
                except Exception:
                    pass
                self.update_preview(force=True)
                return

    def toggle_favourite(self):
        item = self._current_item()
        channel = (item or {}).get('data') or {}
        key = channel_key(channel)
        if not key:
            notify('Highlight a channel first.')
            return
        favs = list(self.library.get('favs') or [])
        if any(same_channel(channel, record) for record in favs):
            favs = [record for record in favs if not same_channel(channel, record)]
            notify('Removed from favs.')
        else:
            favs.append(channel_record(channel))
            notify('Added to favs.')
        self.library['favs'] = favs
        save_channel_lists(self.library)
        self.populate_list()
        self._reselect(key)
        self.setFocus(self.results_list)

    def show_favs(self):
        if self.view != 'all':
            self.view = 'all'
            self.playlist_name = ''
        else:
            self.view = 'favs'
            self.playlist_name = ''
        self.populate_list()
        self.setFocus(self.results_list)

    def _ask_playlist_name(self, current='', ignore=''):
        keyboard = xbmc.Keyboard(current or '', 'Playlist name')
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return ''
        name = ' '.join(keyboard.getText().split())[:40].strip()
        if not name:
            notify('Enter a playlist name.')
            return ''
        folded_ignore = (ignore or '').lower()
        for playlist in self.library.get('playlists') or []:
            existing = str(playlist.get('name') or '')
            if folded_ignore and existing.lower() == folded_ignore:
                continue
            if existing.lower() == name.lower():
                notify('You already have a playlist with that name.')
                return ''
        return name

    def _pick_playlist(self, heading):
        names = []
        for playlist in self.library.get('playlists') or []:
            label = playlist.get('name') or ''
            if label:
                names.append(label)
        if self.view == 'playlist' and self.playlist_name in names:
            names = [self.playlist_name] + [label for label in names if label != self.playlist_name]
        if not names:
            notify('No playlists yet.')
            return ''
        choice = dialogs.select(heading, names)
        if choice < 0:
            return ''
        return names[choice]

    def _rename_playlist(self, name):
        playlist = self._playlist_by_name(name)
        if playlist is None:
            notify('That playlist is gone.')
            return False
        new_name = self._ask_playlist_name(current=name, ignore=name)
        if not new_name or new_name == name:
            return False
        playlist['name'] = new_name
        save_channel_lists(self.library)
        if self.playlist_name == name:
            self.playlist_name = new_name
        notify('Renamed to %s.' % new_name)
        return True

    def _delete_playlist(self, name):
        if not dialogs.yesno(paths.ADDON_NAME, 'Delete the playlist "%s"?' % name):
            return False
        self.library['playlists'] = [
            playlist for playlist in (self.library.get('playlists') or [])
            if playlist.get('name') != name
        ]
        save_channel_lists(self.library)
        notify('Playlist deleted.')
        if self.view == 'playlist' and self.playlist_name == name:
            self.view = 'all'
            self.playlist_name = ''
        return True

    def _playlist_by_name(self, name):
        for playlist in self.library.get('playlists') or []:
            if playlist.get('name') == name:
                return playlist
        return None

    def add_or_remove(self):
        if self.view == 'playlist':
            self._remove_from_playlist()
            return
        self._add_to_playlist()

    def _add_to_playlist(self):
        item = self._current_item()
        channel = (item or {}).get('data') or {}
        key = channel_key(channel)
        if not key:
            notify('Highlight a channel first.')
            return
        playlists = self.library.setdefault('playlists', [])
        options = ['New playlist'] + [playlist.get('name') or 'Playlist' for playlist in playlists]
        choice = dialogs.select('Add to playlist', options)
        if choice < 0:
            return
        if choice == 0:
            name = self._ask_playlist_name()
            if not name:
                return
            playlist = {'name': name, 'channels': []}
            playlists.append(playlist)
        else:
            playlist = playlists[choice - 1]
            name = playlist.get('name') or 'Playlist'
        channels = playlist.setdefault('channels', [])
        if any(same_channel(channel, record) for record in channels):
            notify('Already in %s.' % name)
            return
        channels.append(channel_record(channel))
        playlist['channels'] = unique_channels(channels)
        save_channel_lists(self.library)
        notify('Added to %s.' % name)
        self.populate_list()
        self._reselect(key)
        self.setFocus(self.results_list)

    def _remove_from_playlist(self):
        item = self._current_item()
        channel = (item or {}).get('data') or {}
        key = channel_key(channel)
        playlist = self._playlist_by_name(self.playlist_name)
        if not key or not playlist:
            notify('Highlight a channel first.')
            return
        playlist['channels'] = [
            record for record in (playlist.get('channels') or [])
            if not same_channel(channel, record)
        ]
        save_channel_lists(self.library)
        notify('Removed from %s.' % self.playlist_name)
        self.populate_list()
        self.setFocus(self.results_list)

    def _move_channel(self, direction):
        if self.view != 'playlist':
            notify('Open a playlist to change the order.')
            return
        item = self._current_item()
        channel = (item or {}).get('data') or {}
        key = channel_key(channel)
        playlist = self._playlist_by_name(self.playlist_name)
        if not key or not playlist:
            notify('Highlight a channel first.')
            return
        channels = list(playlist.get('channels') or [])
        index = None
        for position, record in enumerate(channels):
            if same_channel(channel, record):
                index = position
                break
        if index is None:
            notify('That channel is not in this playlist.')
            return
        target = index + direction
        if target < 0:
            notify('Already at the top.')
            return
        if target >= len(channels):
            notify('Already at the bottom.')
            return
        channels[index], channels[target] = channels[target], channels[index]
        playlist['channels'] = channels
        save_channel_lists(self.library)
        self.populate_list()
        self._reselect(key)
        self.setFocus(self.results_list)

    def open_playlists(self):
        playlists = self.library.get('playlists') or []
        options = []
        actions = []
        if self.view != 'all':
            options.append('All channels')
            actions.append('all')
        options.append('New playlist')
        actions.append('new')
        if playlists:
            options.append('Rename a playlist')
            actions.append('rename')
            options.append('Delete a playlist')
            actions.append('delete')
        for playlist in playlists:
            count = len(playlist.get('channels') or [])
            options.append('%s    (%s)' % (playlist.get('name') or 'Playlist', count))
            actions.append(('open', playlist.get('name') or ''))
        choice = dialogs.select('Playlists', options)
        if choice < 0:
            return
        action = actions[choice]
        if action == 'all':
            self.view = 'all'
            self.playlist_name = ''
        elif action == 'new':
            name = self._ask_playlist_name()
            if not name:
                return
            self.library.setdefault('playlists', []).append({'name': name, 'channels': []})
            save_channel_lists(self.library)
            notify('Playlist created. Highlight a channel and press Add to playlist.')
        elif action == 'rename':
            name = self._pick_playlist('Rename a playlist')
            if not name or not self._rename_playlist(name):
                return
        elif action == 'delete':
            name = self._pick_playlist('Delete a playlist')
            if not name or not self._delete_playlist(name):
                return
        elif isinstance(action, tuple) and action[0] == 'open':
            self.view = 'playlist'
            self.playlist_name = action[1]
        self.populate_list()
        self.setFocus(self.results_list)


def open_sports():
    window = SportsHubWindow()
    window.doModal()
    del window
