from __future__ import absolute_import

import json
import os
import sys
import threading
from urllib.request import Request, urlopen

import pyxbmct
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.core import paths
from resources.lib.core import presence
from resources.lib.gui import dialogs
from resources.lib.gui.sections import open_section
from resources.lib.gui.buttons import text_button


TMDB_API_KEY = '5135334daa33251bc407e5f24cb1c6a5'
TMDB_BASE_URL = 'https://api.themoviedb.org/3'
TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/w500'

LIVE_NOW_LAYOUT = (22, 42, 36, 42)
LIVE_CAROUSEL_LAYOUT = (
    (26, 42, 34, 26),
    (26, 70, 34, 26),
)

# One label per line, placed inside the rounded card. Android draws extra
# lines past the bottom of a tall label, onto the grass under the card.
_LIVE_CAPTION_LINE_COUNT = 4
_LIVE_CAPTION_CHARS = 16

CAROUSEL_MOVIES = 20
CAROUSEL_SHOWS = 20

TMDB_CAROUSEL_LAYOUT = (
    (64, 42, 22, 9),
    (64, 53, 22, 9),
    (64, 64, 22, 9),
    (64, 75, 22, 9),
    (64, 86, 22, 9),
)

SECTION_LAYOUT = (
    ('Sports', 14, 3, 16, 10),
    ('Movies & Shows', 14, 15, 16, 10),
    ('IPTV', 32, 3, 16, 10),
    ('Music', 32, 15, 16, 10),
    ('Cartoons & Anime', 50, 3, 16, 10),
    ('Community Lists', 50, 15, 16, 10),
    ('XXX', 68, 3, 16, 10),
    ('Misc', 68, 15, 16, 10),
)

SECTION_ART = {
    'Sports': (paths.SPORTS_BUTTON_PATH, paths.SPORTS_BUTTON_FOCUS_PATH),
    'XXX': (paths.ADULT_BUTTON_PATH, paths.ADULT_BUTTON_FOCUS_PATH),
    'Movies & Shows': (paths.MS_BUTTON_PATH, paths.MS_BUTTON_FOCUS_PATH),
    'Music': (paths.MUSIC_BUTTON_PATH, paths.MUSIC_BUTTON_FOCUS_PATH),
    'IPTV': (paths.IPTV_BUTTON_PATH, paths.IPTV_BUTTON_FOCUS_PATH),
    'Cartoons & Anime': (paths.AC_BUTTON_PATH, paths.AC_BUTTON_FOCUS_PATH),
    'Community Lists': (paths.CL_BUTTON_PATH, paths.CL_BUTTON_FOCUS_PATH),
    'Misc': (paths.MISC_BUTTON_PATH, paths.MISC_BUTTON_FOCUS_PATH),
}


class ColossusHomeWindow(pyxbmct.AddonFullWindow):
    def __init__(self):
        super(ColossusHomeWindow, self).__init__('Colossus')
        self.quit_requested = False
        self.carousel_items = self.load_tmdb_carousel()
        self.carousel_start = 0
        self._settled_carousel = None
        self.carousel_images = []
        self.carousel_buttons = []
        self.carousel_glows = []
        self.live_events = []
        self.live_start = 0
        self.live_images = []
        self.live_captions = []
        self.live_buttons = []
        self.live_glows = []
        self._settled_live = None
        self.live_row_label = None
        self.live_now_placeholder = None
        self.live_now_label = None
        self.live_now_fill = None
        self.live_now_image = None
        self.live_now_caption = None
        self.live_now_frame = None
        self.live_now_glow = None
        self.live_now_button = None
        self.section_buttons = {}
        self.section_images = {}
        self.section_layout = self.visible_section_layout()
        self.utility_buttons = {}
        self.reopen = False
        self.setGeometry(1280, 720, 100, 100)
        self.hide_default_chrome()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.quit_addon)
        self.set_controls()
        self.set_navigation()
        self._start_live_now_loader()

    def hide_default_chrome(self):
        for name in ('window_close_button', 'title_bar', 'title_background', 'background'):
            control = getattr(self, name, None)
            if control is None:
                continue
            try:
                control.setVisible(False)
                control.setEnabled(False)
            except Exception:
                pass

    def doModal(self):
        xbmcgui.Window.show(self)
        xbmc.sleep(200)
        self.focus_sports()
        from resources.lib.gui.notices import present
        present(self)
        self.focus_sports()
        self._schedule_focus_sports()
        xbmcgui.Window.doModal(self)

    def _schedule_focus_sports(self):
        def later():
            monitor = xbmc.Monitor()
            for wait in (0.1, 0.25, 0.5):
                if monitor.waitForAbort(wait) or self.quit_requested:
                    return
                try:
                    self.focus_sports()
                except Exception:
                    return

        thread = threading.Thread(target=later)
        thread.daemon = True
        thread.start()

    def focus_sports(self):
        sports = self.section_buttons.get('Sports')
        if sports is None:
            return
        try:
            self.setFocus(sports)
        except Exception:
            try:
                self.setFocusId(sports.getId())
            except Exception:
                pass
        self.update_section_art(focused=sports)
        self.update_live_now_art()
        self.update_focus_rings()

    def set_controls(self):
        self.add_background()
        self.add_section_buttons()
        self.add_live_now_button()
        self.add_live_carousel()
        self.add_featured_label()
        self.add_carousel_buttons()
        self.add_utility_buttons()

        self.version_label = xbmcgui.ControlLabel(
            28,
            684,
            720,
            28,
            'Version %s' % paths.ADDON.getAddonInfo('version'),
            textColor='0xFFFFFFFF'
        )
        self.addControl(self.version_label)

    def add_background(self):
        try:
            background_path = paths.BACKDROP2_PATH
            if not os.path.exists(background_path):
                background_path = paths.BACKDROP_PATH
            if not os.path.exists(background_path):
                background_path = paths.FANART_PATH
            self.background = xbmcgui.ControlImage(
                0,
                0,
                1280,
                720,
                background_path
            )
            self.addControl(self.background)
        except Exception:
                                                                           
            pass

    def visible_section_layout(self):
        if paths.ADDON.getSetting('disable_adult') != 'true':
            return SECTION_LAYOUT
        return tuple(item for item in SECTION_LAYOUT if item[0] != 'XXX')

    def add_section_buttons(self):
        self.section_images = {}
        for section_name, row, column, height, width in self.section_layout:
            button = self.create_section_button(section_name)
            self.section_buttons[section_name] = button
            self.placeControl(button, row, column, height, width, pad_x=0, pad_y=0)
            self.connect(button, self.make_section_opener(section_name))

    def add_utility_buttons(self):
        normal = paths.SETTINGS_BUTTON_PATH
        focused = paths.SETTINGS_BUTTON_FOCUS_PATH
        if not os.path.exists(focused):
            focused = normal
        self.utility_buttons['Settings'] = pyxbmct.Button(
            '',
            noFocusTexture=normal,
            focusTexture=focused
        )
        self.placeControl(self.utility_buttons['Settings'], 3, 90, 12, 7, pad_x=0, pad_y=0)
        self.connect(self.utility_buttons['Settings'], self.open_settings)

        support_normal = paths.SUPPORT_BUTTON_PATH
        support_focused = paths.SUPPORT_BUTTON_FOCUS_PATH
        if os.path.exists(support_normal):
            if not os.path.exists(support_focused):
                support_focused = support_normal
            self.utility_buttons['Support'] = pyxbmct.Button(
                '',
                noFocusTexture=support_normal,
                focusTexture=support_focused
            )
        else:
            self.utility_buttons['Support'] = text_button('Support')
        self.placeControl(self.utility_buttons['Support'], 3, 82, 12, 7, pad_x=0, pad_y=0)
        self.connect(self.utility_buttons['Support'], self.open_support)

    def add_live_now_button(self):
        row, column, height, width = LIVE_NOW_LAYOUT
        placeholder = paths.LIVE_NOW_BUTTON_PATH if os.path.exists(paths.LIVE_NOW_BUTTON_PATH) else ''

        if placeholder:
            self.live_now_placeholder = pyxbmct.Image(placeholder, aspectRatio=0)
            self.placeControl(self.live_now_placeholder, row, column, height, width, pad_x=0, pad_y=0)

        if os.path.exists(paths.LIVE_NOW_FILL_PATH):
            self.live_now_fill = pyxbmct.Image(paths.LIVE_NOW_FILL_PATH, aspectRatio=0)
            self.placeControl(self.live_now_fill, row, column, height, width, pad_x=0, pad_y=0)
            self.live_now_fill.setVisible(False)

        self.live_now_image = pyxbmct.Image(paths.ICON_PATH, aspectRatio=0)
        self.placeControl(self.live_now_image, row, column, height, width, pad_x=0, pad_y=0)
        self.live_now_image.setVisible(False)

        if os.path.exists(paths.LIVE_NOW_CAPTION_PATH):
            self.live_now_caption = pyxbmct.Image(paths.LIVE_NOW_CAPTION_PATH, aspectRatio=0)
            self.placeControl(self.live_now_caption, row, column, height, width, pad_x=0, pad_y=0)
            self.live_now_caption.setVisible(False)

        frame_path = paths.LIVE_NOW_FRAME_PATH if os.path.exists(paths.LIVE_NOW_FRAME_PATH) else ''
        if frame_path:
            self.live_now_frame = pyxbmct.Image(frame_path, aspectRatio=0)
            self.placeControl(self.live_now_frame, row, column, height, width, pad_x=0, pad_y=0)
            self.live_now_frame.setVisible(False)

        self.live_now_label = pyxbmct.Label(
            '[B]NOTHING LIVE[/B]',
            font='font30',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_CENTER
        )
        self.placeControl(self.live_now_label, row + height - 10, column + 1, 8, width - 2, pad_x=0, pad_y=0)
        self.live_now_label.setVisible(False)

        if os.path.exists(paths.LIVE_GLOW_PATH):
            self.live_now_glow = pyxbmct.Image(paths.LIVE_GLOW_PATH, aspectRatio=0)
            self.placeControl(self.live_now_glow, row, column, height, width, pad_x=-22, pad_y=-22)
            self.live_now_glow.setVisible(False)

        blank = paths.BLANK_TEXTURE_PATH if os.path.exists(paths.BLANK_TEXTURE_PATH) else ''
        self.live_now_button = pyxbmct.Button(
            '',
            noFocusTexture=blank,
            focusTexture=blank
        )
        self.placeControl(self.live_now_button, row, column, height, width, pad_x=0, pad_y=0)
        self.connect(self.live_now_button, self.open_live_now)

    def add_live_carousel(self):
        blank = paths.BLANK_TEXTURE_PATH if os.path.exists(paths.BLANK_TEXTURE_PATH) else ''
        self.live_row_label = pyxbmct.Label(
            '[B]LIVE[/B]',
            font='font12',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_RIGHT + pyxbmct.ALIGN_CENTER_Y
        )
        live_row, _live_column, live_height, _live_width = LIVE_CAROUSEL_LAYOUT[0]
        self.placeControl(self.live_row_label, live_row, 26, live_height, 14, pad_x=0, pad_y=0)
        self.live_row_label.setVisible(False)
        for index, (row, column, height, width) in enumerate(LIVE_CAROUSEL_LAYOUT):
            image = pyxbmct.Image(paths.ICON_PATH, aspectRatio=0)
            self.placeControl(image, row, column, height, width, pad_x=0, pad_y=0)
            image.setVisible(False)
            self.live_images.append(image)
            if os.path.exists(paths.FEATURED_GLOW_PATH):
                glow = pyxbmct.Image(paths.FEATURED_GLOW_PATH, aspectRatio=0)
                self.placeControl(glow, row, column, height, width, pad_x=-14, pad_y=-14)
                glow.setVisible(False)
                self.live_glows.append(glow)
            button = pyxbmct.Button('', noFocusTexture=blank, focusTexture=blank)
            self.placeControl(button, row, column, height, width, pad_x=0, pad_y=0)
            button.setVisible(False)
            button.setEnabled(False)
            self.live_buttons.append(button)
            self.connect(button, lambda slot=index: self.open_live_slot(slot))
            labels = []
            for _line_index in range(_LIVE_CAPTION_LINE_COUNT):
                caption = pyxbmct.Label(
                    '',
                    font='font10',
                    textColor='0xFFFFFFFF',
                    alignment=pyxbmct.ALIGN_CENTER_X + pyxbmct.ALIGN_CENTER_Y
                )
                self.placeControl(caption, row, column, 1, width, pad_x=0, pad_y=0)
                caption.setVisible(False)
                labels.append(caption)
            self.live_captions.append(labels)

    def add_featured_label(self):
        self.featured_label = pyxbmct.Label(
            '[B]FEATURED[/B]',
            font='font12',
            textColor='0xFFFFFFFF',
            alignment=pyxbmct.ALIGN_RIGHT + pyxbmct.ALIGN_CENTER_Y
        )
        self.placeControl(self.featured_label, 64, 26, 22, 14, pad_x=0, pad_y=0)

    def _start_live_now_loader(self):
        thread = threading.Thread(target=self._load_live_now_in_background)
        thread.daemon = True
        thread.start()

    def _load_live_now_in_background(self):
        events = []
        try:
            from resources.lib.gui.sports import load_live_now_events
            events = load_live_now_events(timeout=15) or []
        except Exception:
            events = []
        self._apply_live_events(events)

    def _visible_live_count(self):
        return min(len(self.live_buttons), len(self.live_events))

    def get_live_item(self, index):
        if not self.live_events:
            return None
        return self.live_events[(self.live_start + index) % len(self.live_events)]

    def _wrap_title_lines(self, text, limit):
        words = (text or 'Live').split() or ['Live']
        lines = []
        current = ''
        for word in words:
            trial = (current + ' ' + word).strip()
            if current and len(trial) > limit:
                lines.append(current)
                current = word
            else:
                current = trial
        if current:
            lines.append(current)
        return lines

    def _live_caption_lines(self, item):
        clock = (item.get('time') or '').strip()
        title = ' '.join((item.get('title') or 'Live').split()) or 'Live'
        room = _LIVE_CAPTION_LINE_COUNT - (1 if clock else 0)
        lines = self._wrap_title_lines(title, _LIVE_CAPTION_CHARS)
        if len(lines) > room:
            kept = lines[:room]
            tail = kept[-1].rstrip('.')
            if len(tail) > _LIVE_CAPTION_CHARS - 3:
                tail = tail[:_LIVE_CAPTION_CHARS - 3].rstrip()
            kept[-1] = tail + '...'
            lines = kept
        if clock:
            lines.insert(0, '[COLOR FF7EE0FF]%s[/COLOR]' % clock)
        return lines[:_LIVE_CAPTION_LINE_COUNT]

    def _move_grid_control(self, control, row, column, height, width):
        control.setPosition(
            int(self.grid_x + (self.tile_width * column)),
            int(self.grid_y + (self.tile_height * row))
        )
        control.setWidth(int(self.tile_width * width))
        control.setHeight(int(self.tile_height * height))

    def _set_live_caption(self, index, item, show):
        labels = self.live_captions[index] if index < len(self.live_captions) else []
        for label in labels:
            label.setLabel('')
            label.setVisible(False)
        if not show or index >= len(LIVE_CAROUSEL_LAYOUT):
            return
        row, column, height, width = LIVE_CAROUSEL_LAYOUT[index]
        lines = self._live_caption_lines(item or {})
        inset_x = 2
        inset_y = 8
        line_height = 4
        inner_height = height - (inset_y * 2)
        block = line_height * len(lines)
        start = row + inset_y + max(0, (inner_height - block) // 2)
        text_width = width - (inset_x * 2)
        for offset, text in enumerate(lines):
            if offset >= len(labels):
                break
            label = labels[offset]
            self._move_grid_control(
                label,
                start + (offset * line_height),
                column + inset_x,
                line_height,
                text_width
            )
            label.setLabel(text)
            label.setVisible(True)

    def _live_needs_caption(self, poster):
        name = os.path.basename(poster or '').lower()
        if not poster or not os.path.exists(poster):
            return True
        return name == 'livesports.jpg'

    def _paint_live_slot(self, index, item):
        item = item or {}
        image = self.live_images[index]
        poster = item.get('poster') or ''
        if self._live_needs_caption(poster):
            fill = paths.LIVE_NOW_FILL_PATH if os.path.exists(paths.LIVE_NOW_FILL_PATH) else paths.ICON_PATH
            image.setImage(fill)
            self._set_live_caption(index, item, True)
        else:
            image.setImage(poster)
            self._set_live_caption(index, item, False)
        image.setVisible(True)

    def _apply_live_events(self, events):
        ready = []
        for event in events or []:
            event = dict(event or {})
            poster = event.get('poster') or ''
            if os.path.basename(poster).lower() == 'livesports.jpg':
                event['poster'] = ''
            if event.get('title') or (poster and os.path.exists(poster)):
                ready.append(event)
        self.live_events = ready
        self.live_start = 0
        try:
            self._show_live_carousel(bool(ready))
            self._wire_live_navigation()
            if ready:
                try:
                    if self.getFocus() == self.live_now_button:
                        self.setFocus(self.live_buttons[0])
                except Exception:
                    pass
            self.update_focus_rings()
        except Exception:
            pass

    def _show_live_carousel(self, show):
        visible = self._visible_live_count() if show else 0
        for index, image in enumerate(self.live_images):
            button = self.live_buttons[index]
            if index < visible:
                self._paint_live_slot(index, self.get_live_item(index) or {})
                button.setVisible(True)
                button.setEnabled(True)
            else:
                image.setVisible(False)
                self._set_live_caption(index, None, False)
                button.setVisible(False)
                button.setEnabled(False)
                if index < len(self.live_glows):
                    self.live_glows[index].setVisible(False)
        if self.live_row_label:
            self.live_row_label.setVisible(bool(visible))
        self._set_empty_live_visible(not visible)

    def _set_empty_live_visible(self, show):
        for control in (
            self.live_now_placeholder,
            self.live_now_fill,
            self.live_now_image,
            self.live_now_caption,
            self.live_now_frame,
            self.live_now_label,
            self.live_now_glow,
            self.live_now_button,
        ):
            if control is None:
                continue
            try:
                control.setVisible(bool(show) and control in (
                    self.live_now_placeholder,
                    self.live_now_button,
                ))
            except Exception:
                pass
        if show and self.live_now_placeholder:
            try:
                self.live_now_placeholder.setVisible(True)
            except Exception:
                pass
        if self.live_now_button:
            try:
                self.live_now_button.setEnabled(bool(show))
            except Exception:
                pass

    def open_live_slot(self, index):
        event = self.get_live_item(index) or {}
        if event.get('channels'):
            from resources.lib.gui.sports import open_event_sources
            open_event_sources(event)
            return
        dialogs.ok(paths.ADDON_NAME, 'No events live currently.')

    def add_carousel_buttons(self):
        for index, (row, column, height, width) in enumerate(TMDB_CAROUSEL_LAYOUT):
            item = self.get_carousel_item(index)
            poster = item.get('poster', '') if item else ''
            image = pyxbmct.Image(poster or paths.ICON_PATH, aspectRatio=0)
            self.carousel_images.append(image)
            self.placeControl(image, row, column, height, width)

            if os.path.exists(paths.FEATURED_GLOW_PATH):
                glow = pyxbmct.Image(paths.FEATURED_GLOW_PATH, aspectRatio=0)
                self.placeControl(glow, row, column, height, width, pad_x=-18, pad_y=-18)
                glow.setVisible(False)
                self.carousel_glows.append(glow)

            button = self.create_carousel_button(item)
            self.carousel_buttons.append(button)
            self.placeControl(button, row, column, height, width)
            self.connect(button, lambda index=index: self.open_visible_carousel_item(index))

    def section_art_paths(self, section_name):
        art = SECTION_ART.get(section_name)
        if not art:
            return None
        normal, focused = art
        if not os.path.exists(normal):
            return None
        if not os.path.exists(focused):
            focused = normal
        return (normal, focused)

    def create_section_button(self, section_name):
        art = self.section_art_paths(section_name)
        if art:
            normal, focused = art
            return pyxbmct.Button(
                '',
                noFocusTexture=normal,
                focusTexture=focused
            )

        label = section_name.upper()
        if section_name == 'Movies & Shows':
            label = 'MOVIES &\nSHOWS'
        elif section_name == 'Cartoons & Anime':
            label = 'CARTOONS &\nANIME'
        elif section_name == 'Community Lists':
            label = 'COMMUNITY\nLISTS'
        return text_button('[B]%s[/B]' % label)

    def create_carousel_button(self, item):
        blank = paths.BLANK_TEXTURE_PATH if os.path.exists(paths.BLANK_TEXTURE_PATH) else ''
        return pyxbmct.Button(
            '',
            noFocusTexture=blank,
            focusTexture=blank
        )

    def get_carousel_item(self, index):
        if not self.carousel_items:
            fallback = ['Top Movie', 'Top Show', 'Top Movie', 'Top Show']
            return {'title': fallback[index], 'media_type': 'placeholder'}
        return self.carousel_items[(self.carousel_start + index) % len(self.carousel_items)]

    def open_visible_carousel_item(self, index):
        self.open_carousel_item(self.get_carousel_item(index))

    def open_carousel_item(self, item):
        if not item or item.get('media_type') not in ('movie', 'tv'):
            return
        from resources.lib.gui.movies import open_media_from_home
        open_media_from_home(item)

    def open_live_now(self):
        dialogs.ok(paths.ADDON_NAME, 'No events live currently.')

    def open_support(self):
        from resources.lib.gui.notices import open_support
        open_support()

    def open_settings(self):
        from resources.lib.core import adult_lock
        adult_lock.sync_reset_label()
        before = paths.ADDON.getSetting('disable_adult')
        lock_before = paths.ADDON.getSetting('protect_adult') == 'true'
        adult_lock.mark_settings_session(True)
        try:
            paths.ADDON.openSettings()
        finally:
            adult_lock.mark_settings_session(False)
        adult_lock.confirm_disable(lock_before)
        turned_lock_on = (not lock_before) and paths.ADDON.getSetting('protect_adult') == 'true'
        if turned_lock_on and adult_lock.has_password():
            adult_lock.arm()
        if turned_lock_on and not adult_lock.has_password():
            if not adult_lock.create_password() and not adult_lock.has_password():
                paths.ADDON.setSetting('protect_adult', 'false')
                dialogs.ok(
                    paths.ADDON_NAME,
                    'Password protect adult was turned off because no password was set.'
                )
        if paths.ADDON.getSetting('disable_adult') != before:
            self.reopen = True
            self.close()

    def rotate_carousel(self, direction, focus_index):
        if not self.carousel_items:
            return

        self.carousel_start = (self.carousel_start + direction) % len(self.carousel_items)
        for index, image in enumerate(self.carousel_images):
            item = self.get_carousel_item(index)
            poster = item.get('poster', '') if item else ''
            image.setImage(poster or paths.ICON_PATH)

        try:
            self.setFocus(self.carousel_buttons[focus_index])
        except Exception:
            pass
        self.update_focus_rings()

    def rotate_live(self, direction, focus_index):
        if len(self.live_events) <= 1:
            return
        self.live_start = (self.live_start + direction) % len(self.live_events)
        visible = self._visible_live_count()
        for index in range(visible):
            self._paint_live_slot(index, self.get_live_item(index) or {})
        try:
            self.setFocus(self.live_buttons[focus_index])
        except Exception:
            pass
        self.update_focus_rings()

    def load_tmdb_carousel(self):
        try:
            from resources.lib.core import tmdb
            movie_items = self._carousel_from_browse(tmdb.browse('movie_top', page=1), CAROUSEL_MOVIES)
            tv_items = self._carousel_from_browse(tmdb.browse('tv_top', page=1), CAROUSEL_SHOWS)
            return self.interleave_tmdb_items(movie_items, tv_items)
        except Exception:
            return []

    def _carousel_from_browse(self, payload, limit):
        items = []
        for raw in (payload or {}).get('results') or []:
            if len(items) >= limit:
                break
            poster_url = raw.get('poster') or ''
            poster_path = ''
            if poster_url:
                poster_path = '/' + poster_url.rsplit('/', 1)[-1]
            poster = self.cache_tmdb_poster(raw.get('media_type'), raw.get('id'), poster_path)
            if not poster:
                continue
            items.append({
                'id': raw.get('id'),
                'title': raw.get('title'),
                'media_type': raw.get('media_type'),
                'poster': poster,
            })
        return items

    def interleave_tmdb_items(self, movie_items, tv_items):
        items = []
        for index in range(max(len(movie_items), len(tv_items))):
            if index < len(movie_items):
                items.append(movie_items[index])
            if index < len(tv_items):
                items.append(tv_items[index])
        return items

    def cache_tmdb_poster(self, media_type, tmdb_id, poster_path):
        if not poster_path or not tmdb_id:
            return ''

        cache_dir = os.path.join(paths.PROFILE_PATH, 'tmdb_posters')
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)

        extension = os.path.splitext(poster_path)[1] or '.jpg'
        poster_file = os.path.join(cache_dir, '%s_%s%s' % (media_type, tmdb_id, extension))
        if os.path.exists(poster_file):
            return poster_file

        request = Request(TMDB_IMAGE_BASE + poster_path, headers={'User-Agent': 'Colossus/0.0.1'})
        response = urlopen(request, timeout=8)
        with open(poster_file, 'wb') as poster:
            poster.write(response.read())
        return poster_file

    def make_section_opener(self, section_name):
        return lambda: open_section(section_name)

    def quit_addon(self):
        self.quit_requested = True
        presence.stop()
        self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = action

        if action_id in (pyxbmct.ACTION_PREVIOUS_MENU, pyxbmct.ACTION_NAV_BACK):
            self.quit_addon()
            return

        try:
            focused_id = self.getFocusId()
        except Exception:
            focused_id = None

        if not focused_id:
            self.focus_sports()
            return

        live_index = self._live_index(focused_id)
        visible_live = self._visible_live_count()
        if visible_live and len(self.live_events) > visible_live:
            if (
                action_id == pyxbmct.ACTION_MOVE_RIGHT
                and live_index == visible_live - 1
                and self._settled_live == live_index
            ):
                self.rotate_live(1, live_index)
                return
            if (
                action_id == pyxbmct.ACTION_MOVE_LEFT
                and live_index == 0
                and self._settled_live == 0
            ):
                self.rotate_live(-1, 0)
                return

        carousel_index = self._carousel_index(focused_id)
        last_index = len(self.carousel_buttons) - 1
        if (
            action_id == pyxbmct.ACTION_MOVE_RIGHT
            and carousel_index == last_index
            and self._settled_carousel == last_index
        ):
            self.rotate_carousel(1, last_index)
            return

        if (
            action_id == pyxbmct.ACTION_MOVE_LEFT
            and carousel_index == 0
            and self._settled_carousel == 0
        ):
            self.rotate_carousel(-1, 0)
            return

        super(ColossusHomeWindow, self).onAction(action)
        self._refresh_focus_soon()

    def _carousel_index(self, focused_id):
        for index, button in enumerate(self.carousel_buttons):
            if button.getId() == focused_id:
                return index
        return None

    def _live_index(self, focused_id):
        for index, button in enumerate(self.live_buttons):
            if button.getId() == focused_id:
                return index
        return None

    def _refresh_focus_soon(self):
        self._focus_token = getattr(self, '_focus_token', 0) + 1
        token = self._focus_token

        def later():
            xbmc.sleep(50)
            if token != getattr(self, '_focus_token', 0) or self.quit_requested:
                return
            try:
                self.update_section_art()
                self.update_live_now_art()
                self.update_focus_rings()
            except Exception:
                pass

        thread = threading.Thread(target=later)
        thread.daemon = True
        thread.start()

    def update_live_now_art(self):
        if self.live_events:
            self._set_empty_live_visible(False)
            return
        if not self.live_now_placeholder:
            return
        normal = paths.LIVE_NOW_BUTTON_PATH
        if not os.path.exists(normal):
            return
        if self.live_events:
            self._set_empty_live_visible(False)
            return
        try:
            self.live_now_placeholder.setImage(normal)
            self._set_empty_live_visible(True)
        except Exception:
            pass

    def update_focus_rings(self):
        try:
            focused = self.getFocus()
        except Exception:
            focused = None
        if self.live_now_frame:
            try:
                self.live_now_frame.setVisible(False)
            except Exception:
                pass
        if self.live_now_glow:
            try:
                self.live_now_glow.setVisible(
                    not self.live_events and focused == self.live_now_button
                )
            except Exception:
                pass
        for glow, button in zip(self.live_glows, self.live_buttons):
            try:
                glow.setVisible(focused == button)
            except Exception:
                pass
        for glow, button in zip(self.carousel_glows, self.carousel_buttons):
            try:
                glow.setVisible(focused == button)
            except Exception:
                pass
        settled = None
        settled_live = None
        if focused is not None:
            try:
                settled = self._carousel_index(focused.getId())
                settled_live = self._live_index(focused.getId())
            except Exception:
                settled = None
                settled_live = None
        self._settled_carousel = settled
        self._settled_live = settled_live

    def update_section_art(self, focused=None):
        if focused is None:
            try:
                focused = self.getFocus()
            except Exception:
                focused = self.section_buttons.get('Sports')
        for section_name, image in self.section_images.items():
            art = self.section_art_paths(section_name)
            if not art:
                continue
            normal, selected = art
            try:
                image.setImage(selected if focused == self.section_buttons.get(section_name) else normal)
            except Exception:
                pass

    def set_navigation(self):
        sports = self.section_buttons['Sports']
        adult = self.section_buttons.get('XXX')
        movies = self.section_buttons['Movies & Shows']
        iptv = self.section_buttons['IPTV']
        music = self.section_buttons['Music']
        anime = self.section_buttons['Cartoons & Anime']
        community = self.section_buttons['Community Lists']
        misc = self.section_buttons['Misc']
        posters = self.carousel_buttons
        live_now = self.live_now_button
        settings = self.utility_buttons['Settings']
        support = self.utility_buttons['Support']

        support.controlLeft(movies)
        support.controlRight(settings)
        support.controlUp(support)
        support.controlDown(live_now)

        settings.controlLeft(support)
        settings.controlRight(settings)
        settings.controlUp(settings)
        settings.controlDown(live_now)

        sports.controlLeft(sports)
        sports.controlRight(movies)
        sports.controlUp(sports)
        sports.controlDown(iptv)

        movies.controlLeft(sports)
        movies.controlRight(live_now)
        movies.controlUp(movies)
        movies.controlDown(music)

        iptv.controlLeft(iptv)
        iptv.controlRight(music)
        iptv.controlUp(sports)
        iptv.controlDown(anime)

        music.controlLeft(iptv)
        music.controlRight(live_now)
        music.controlUp(movies)
        music.controlDown(community)

        anime.controlLeft(anime)
        anime.controlRight(community)
        anime.controlUp(iptv)
        anime.controlDown(adult or misc)

        community.controlLeft(anime)
        community.controlRight(posters[0])
        community.controlUp(music)
        community.controlDown(misc)

        if adult is not None:
            adult.controlLeft(adult)
            adult.controlRight(misc)
            adult.controlUp(anime)
            adult.controlDown(adult)

        misc.controlLeft(adult or anime)
        misc.controlRight(posters[-1])
        misc.controlUp(community)
        misc.controlDown(misc)

        live_now.controlLeft(movies)
        live_now.controlRight(live_now)
        live_now.controlUp(settings)
        live_now.controlDown(posters[0])

        for index, poster in enumerate(posters):
            poster.controlUp(live_now)
            poster.controlDown(movies)
            poster.controlLeft(posters[index - 1] if index else poster)
            poster.controlRight(posters[index + 1] if index < len(posters) - 1 else poster)
        self._wire_live_navigation()

    def _wire_live_navigation(self):
        movies = self.section_buttons['Movies & Shows']
        music = self.section_buttons['Music']
        posters = self.carousel_buttons
        settings = self.utility_buttons['Settings']
        support = self.utility_buttons['Support']
        live_now = self.live_now_button
        visible = self._visible_live_count()
        slots = self.live_buttons[:visible]
        can_roll = bool(slots) and len(self.live_events) > len(slots)

        if not slots:
            support.controlDown(live_now)
            settings.controlDown(live_now)
            movies.controlRight(live_now)
            music.controlRight(live_now)
            live_now.controlLeft(movies)
            live_now.controlRight(live_now)
            live_now.controlUp(settings)
            live_now.controlDown(posters[0])
            for poster in posters:
                poster.controlUp(live_now)
                poster.controlDown(movies)
            return

        left = slots[0]
        right = slots[-1]
        support.controlDown(right)
        settings.controlDown(right)
        movies.controlRight(left)
        music.controlRight(left)
        for index, slot in enumerate(slots):
            slot.controlUp(support if index == 0 else settings)
            poster_index = 0 if index == 0 else min(2, len(posters) - 1)
            slot.controlDown(posters[poster_index])
            if index == 0:
                slot.controlLeft(slot if can_roll else movies)
            else:
                slot.controlLeft(slots[index - 1])
            if index == len(slots) - 1:
                slot.controlRight(slot)
            else:
                slot.controlRight(slots[index + 1])
        for index, poster in enumerate(posters):
            poster.controlUp(left if visible == 1 or index < 2 else right)
            poster.controlDown(movies)


def _release_plugin():
    try:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, cacheToDisc=False)
    except Exception:
        pass


def _go_home():
    xbmc.executebuiltin('ReplaceWindow(Home)')


def run():
    paths.discard_downloaded_artwork()
    from resources.lib.core import adult_lock
    adult_lock.sync_reset_label()
    adult_lock.start_guard()
    presence.stop()
    from resources.lib.gui.access import StartupCover, allow_entry
    cover = StartupCover()
    cover.present()
    _release_plugin()
    try:
        if not allow_entry():
            cover.close()
            cover = None
            _go_home()
            return
        presence.start()
        quit_requested = False
        try:
            while True:
                window = ColossusHomeWindow()
                xbmcgui.Window.show(window)
                xbmc.sleep(50)
                if cover is not None:
                    cover.close()
                    cover = None
                window.doModal()
                quit_requested = window.quit_requested
                reopen = window.reopen
                del window
                if not reopen:
                    break
        finally:
            presence.stop()
        if quit_requested:
            _go_home()
    finally:
        if cover is not None:
            cover.close()
