from __future__ import absolute_import

import json
import os
import re
import threading
from urllib.parse import urlparse

import pyxbmct
import requests
import xbmc
import xbmcgui

from resources.lib.core import paths
from resources.lib.core import player
from resources.lib.core.presence import user_id as device_user_id
from resources.lib.gui import dialogs
from resources.lib.gui.details import ColossusFullWindow
from resources.lib.gui.sports import SportsBrowseWindow
from resources.lib.gui.buttons import text_button


FEED_URL = 'https://nemzzy.info/colossus/community'
COMMUNITY_PAGE = 'https://nemzzy.info/community'
COMMUNITY_QR_PATH = os.path.join(paths.MEDIA_PATH, 'community_qr.png')
FAV_PATH = os.path.join(paths.PROFILE_PATH, 'community_favs.json')
DIRECT_VIDEO = ('.mp4', '.m3u8')
DIRECT_AUDIO = ('.mp3',)
DIRECT_PLAYLIST = ('.m3u',)
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
)


def kodi_colour(text):
    return re.sub(r'\[COLOR\s*=\s*', '[COLOR ', text or '', flags=re.I)


def plain_title(text):
    text = kodi_colour(text)
    text = re.sub(r'\[/?COLOR[^\]]*\]', '', text, flags=re.I)
    text = re.sub(r'\[/?(?:B|I|CR|UPPERCASE)\]', '', text, flags=re.I)
    return ' '.join(text.replace('\n', ' ').split()) or 'Community'


def safe_image(url):
    url = (url or '').strip()
    if url.startswith('https://') or url.startswith('http://'):
        return url
    return paths.ICON_PATH


def media_kind(url):
    path = urlparse(url or '').path.lower()
    if path.endswith(DIRECT_AUDIO):
        return 'audio'
    if path.endswith(('.m3u8', '.m3u', '.mpd', '.mp4', '.ts')):
        return 'video'
    lowered = (url or '').lower()
    if '.m3u8' in lowered or '.mpd' in lowered:
        return 'video'
    return ''


def host_name(url):
    host = (urlparse(url).netloc or '').lower()
    if host.startswith('www.'):
        host = host[4:]
    return host or 'Link'


_LINK_FIELDS = ('kid', 'key', 'license', 'licence', 'ua', 'referer')


def item_links(item):
    raw = item.get('links')
    if isinstance(raw, str):
        raw = [raw]
    if not isinstance(raw, list):
        return []
    links = []
    for link in raw:
        extra = {}
        if isinstance(link, dict):
            url = str(link.get('url') or '').strip()
            label = str(link.get('label') or '').strip()
            for field in _LINK_FIELDS:
                value = str(link.get(field) or '').strip()
                if value:
                    extra[field] = value
        else:
            url = str(link or '').strip()
            label = ''
        if url:
            row = {'url': url, 'label': label}
            row.update(extra)
            links.append(row)
    return links


def link_drm(link):
    link = link or {}
    kid = (link.get('kid') or '').strip()
    key = (link.get('key') or '').strip()
    if kid and key:
        return {'type': 'clearkey', 'kid': kid, 'key': key}
    license_url = (link.get('license') or link.get('licence') or '').strip()
    if license_url:
        return {'type': 'widevine', 'license': license_url}
    return None


def link_headers(link):
    link = link or {}
    headers = {}
    ua = (link.get('ua') or '').strip()
    referer = (link.get('referer') or '').strip()
    if ua:
        headers['User-Agent'] = ua
    if referer:
        headers['Referer'] = referer
    return headers or None


class _WrappingLabel(object):
    """Stand-in for a one-line label so long community titles wrap instead of clipping."""

    def __init__(self, box):
        self.box = box

    def setLabel(self, text):
        try:
            self.box.setText(text or '')
        except Exception:
            pass


class CommunityWindow(SportsBrowseWindow):
    def set_controls(self):
        super(CommunityWindow, self).set_controls()
        try:
            self.removeControl(self.poster)
        except Exception:
            try:
                self.poster.setVisible(False)
            except Exception:
                pass
        self.poster = pyxbmct.Image(paths.ICON_PATH, aspectRatio=2)
        self.placeControl(self.poster, 10, 2, 20, 14)
        self._title_box = pyxbmct.TextBox(font='font30', textColor='0xFFFFFFFF')
        self.placeControl(self._title_box, 10, 18, 14, 80)
        try:
            self.removeControl(self.title_label)
        except Exception:
            try:
                self.title_label.setVisible(False)
            except Exception:
                pass
        self.title_label = _WrappingLabel(self._title_box)
        self._layout_wide()

    def _layout_wide(self):
        self.move_control(self.back_button, 2, 2, 6, 11)
        self.move_control(self.header_label, 2, 14, 6, 54)
        self.move_control(self.status_label, 2, 70, 6, 28)
        self.move_control(self.poster, 10, 2, 20, 14)
        self.move_control(self._title_box, 10, 18, 14, 80)
        self.move_control(self.meta_label, 24, 18, 5, 80)
        self.move_control(self.overview_box, 31, 2, 6, 96)
        if self.search_button is not None:
            self.move_control(self.search_button, 37, 2, 7, 16)
            self._place_list(46)
        else:
            self._place_list(37)

    def _place_list(self, row):
        self.move_control(self.list_heading, row, 2, 5, 40)
        old_list = getattr(self, 'results_list', None)
        if old_list is not None:
            try:
                self.removeControl(old_list)
            except Exception:
                try:
                    old_list.setVisible(False)
                    old_list.setPosition(-2000, -2000)
                except Exception:
                    pass
        # Kodi locks a list's item width when the control is first added.
        # Moving the old list only changes its position, so build a new one
        # at the full row width before it is added.
        self.results_list = pyxbmct.List(font='font13', textColor='0xFFFFFFFF')
        self.placeControl(self.results_list, row + 5, 2, 96 - (row + 5), 96)
        self.connect(self.results_list, self.select_current)

    def populate_list(self, query=''):
        super(CommunityWindow, self).populate_list(query)
        if not self.visible_items:
            try:
                self.poster.setImage(paths.ICON_PATH)
            except Exception:
                pass

    def update_preview(self, force=False):
        previous = self.current_index
        super(CommunityWindow, self).update_preview(force=force)
        if not self.visible_items:
            try:
                self.poster.setImage(paths.ICON_PATH)
            except Exception:
                pass
            return
        if not force and self.current_index == previous:
            return
        if self.current_index < 0 or self.current_index >= len(self.visible_items):
            return
        image = self.visible_items[self.current_index].get('image') or paths.ICON_PATH
        try:
            self.poster.setImage(image)
        except Exception:
            pass


def load_favs():
    try:
        if not os.path.exists(FAV_PATH):
            return []
        with open(FAV_PATH, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if not isinstance(data, list):
            return []
        return [str(item) for item in data if str(item)]
    except Exception:
        return []


def save_favs(ids):
    try:
        folder = os.path.dirname(FAV_PATH)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        with open(FAV_PATH, 'w', encoding='utf-8') as handle:
            json.dump(ids, handle)
    except Exception:
        pass


def list_id(item):
    return str(((item or {}).get('data') or {}).get('id') or '')


LIST_ROW_COUNT = 8
LIST_ROW_TOP = 40
LIST_ROW_PITCH = 7
LIST_FAV_COLUMN = 62
LIST_VOTE_COLUMN = 75
LIST_BUTTON_SPAN = 12
_MOVE_UP = (3, 104)
_MOVE_DOWN = (4, 105)


def row_button(label):
    normal = paths.TEXT_BUTTON_PATH if os.path.exists(paths.TEXT_BUTTON_PATH) else ''
    focused = paths.TEXT_BUTTON_FOCUS_PATH if os.path.exists(paths.TEXT_BUTTON_FOCUS_PATH) else normal
    return pyxbmct.Button(
        label,
        noFocusTexture=normal,
        focusTexture=focused,
        textColor='0xFFFFFFFF',
        focusedColor='0xFFFFFFFF',
        font='font12',
        textOffsetX=0,
    )


class CommunityListsWindow(CommunityWindow):
    def __init__(self, items, on_select):
        self.fav_ids = set(load_favs())
        self.favs_only = False
        super(CommunityListsWindow, self).__init__(
            heading='COMMUNITY LISTS',
            status_text='%s lists  |  Select a list.' % len(items or []),
            items=items,
            on_select=on_select,
            art_path=paths.ICON_PATH,
            empty_title='Community Lists',
            empty_meta='',
            empty_overview='Favourite and Upvote are on each list. Favourites, at the top, shows only the lists you saved.',
            allow_search=False,
            list_heading='LISTS',
        )

    def set_controls(self):
        super(CommunityListsWindow, self).set_controls()
        self._cursor = 0
        self._offset = 0
        self._column = 'title'
        self._filled = 0
        self._last_focus_id = None
        self._last_list_pos = -1
        self._drop_stock_list()
        self.results_list = pyxbmct.List(
            font='font13',
            textColor='0xFFFFFFFF',
            _itemHeight=39,
            _space=10,
            _itemTextYOffset=-5,
        )
        self.placeControl(
            self.results_list,
            LIST_ROW_TOP,
            2,
            LIST_ROW_COUNT * LIST_ROW_PITCH,
            58,
        )
        self.connect(self.results_list, self.select_current)
        self.move_control(self.header_label, 2, 14, 6, 22)
        self.move_control(self.status_label, 2, 36, 6, 26)
        self.move_control(self.list_heading, 36, 2, 5, 30)
        self.filter_button = text_button('Favourites')
        self.placeControl(self.filter_button, 1, 64, 7, 15)
        self.connect(self.filter_button, self.toggle_filter)
        self.create_button = text_button('Create a list')
        self.placeControl(self.create_button, 1, 81, 7, 17)
        self.connect(self.create_button, self.open_create)
        line_texture = os.path.join(pyxbmct.skin.images, 'List', 'MenuItemNF.png')
        list_right = (self.tile_width * 2) + 5 + (self.tile_width * 58 - 10)
        vote_right = (self.tile_width * LIST_VOTE_COLUMN) + 5 + (self.tile_width * LIST_BUTTON_SPAN - 10)
        self._slots = []
        for index in range(LIST_ROW_COUNT):
            top = LIST_ROW_TOP + (index * LIST_ROW_PITCH)
            line = pyxbmct.Image(line_texture)
            self.placeControl(line, top, 59, LIST_ROW_PITCH, 30, pad_x=0)
            line.setPosition(list_right - 4, line.getY())
            line.setWidth(vote_right - list_right + 4)
            fav_button = row_button('Favourite')
            vote_button = row_button('Upvote')
            self.placeControl(fav_button, top, LIST_FAV_COLUMN, LIST_ROW_PITCH, LIST_BUTTON_SPAN)
            self.placeControl(vote_button, top, LIST_VOTE_COLUMN, LIST_ROW_PITCH, LIST_BUTTON_SPAN)
            self.connect(fav_button, lambda slot=index: self._favourite_slot(slot))
            self.connect(vote_button, lambda slot=index: self._upvote_slot(slot))
            self._slots.append({
                'line': line,
                'fav': fav_button,
                'vote': vote_button,
            })

    def _drop_stock_list(self):
        old_list = getattr(self, 'results_list', None)
        if old_list is None:
            return
        try:
            self.removeControl(old_list)
        except Exception:
            try:
                old_list.setVisible(False)
                old_list.setPosition(-2000, -2000)
            except Exception:
                pass

    def set_navigation(self):
        self.back_button.controlRight(self.filter_button)
        self.back_button.controlDown(self.filter_button)
        self.filter_button.controlLeft(self.back_button)
        self.filter_button.controlRight(self.create_button)
        self.filter_button.controlUp(self.back_button)
        self.create_button.controlLeft(self.filter_button)
        self.create_button.controlUp(self.back_button)
        self._wire_rows()

    def _is_fav(self, item):
        return list_id(item) in self.fav_ids

    def _item_at(self, index):
        if index < 0 or index >= len(self.visible_items):
            return None
        return self.visible_items[index]

    def _current_item(self):
        return self._item_at(self._cursor)

    def populate_list(self, query=''):
        del query
        remembered = list_id(self._current_item())
        chosen = [item for item in self.all_items if (not self.favs_only or self._is_fav(item))]
        self.visible_items = chosen
        self._cursor = 0
        if remembered:
            for index, item in enumerate(chosen):
                if list_id(item) == remembered:
                    self._cursor = index
                    break
        if chosen and self._cursor >= len(chosen):
            self._cursor = len(chosen) - 1
        self._fit_offset()
        self._refresh_rows()
        self._show_preview()
        self.results_list = self._focus_control()

    def _fit_offset(self):
        count = len(self.visible_items)
        if count <= LIST_ROW_COUNT:
            self._offset = 0
            return
        if self._cursor < self._offset:
            self._offset = self._cursor
        if self._cursor >= self._offset + LIST_ROW_COUNT:
            self._offset = self._cursor - LIST_ROW_COUNT + 1
        max_offset = max(0, count - LIST_ROW_COUNT)
        if self._offset > max_offset:
            self._offset = max_offset
        if self._offset < 0:
            self._offset = 0

    def _refresh_rows(self):
        count = len(self.visible_items)
        filled = 0
        self.results_list.reset()
        for index, slot in enumerate(self._slots):
            item_index = self._offset + index
            buttons = (slot['fav'], slot['vote'])
            if item_index >= count:
                slot['line'].setVisible(False)
                for button in buttons:
                    button.setVisible(False)
                    button.setEnabled(False)
                continue
            filled += 1
            item = self.visible_items[item_index]
            slot['line'].setVisible(True)
            for button in buttons:
                button.setVisible(True)
                button.setEnabled(True)
            title = item.get('title') or 'Untitled list'
            if self._is_fav(item):
                title = '[COLOR FF7EE0FF]*[/COLOR]  ' + title
            self.results_list.addItem(title)
            slot['fav'].setLabel('Unfavourite' if self._is_fav(item) else 'Favourite')
            slot['vote'].setLabel('Upvoted' if item.get('voted') else 'Upvote')
        if filled:
            slot = self._cursor - self._offset
            if slot < 0 or slot >= filled:
                slot = 0
            self.results_list.selectItem(slot)
        self._filled = filled
        self._last_list_pos = self._list_pos()
        self._wire_rows()
        try:
            self.list_heading.setLabel('[B]%s[/B]' % ('FAVOURITES' if self.favs_only else 'LISTS'))
        except Exception:
            pass
        self.filter_button.setLabel('All lists' if self.favs_only else 'Favourites')
        if self.favs_only:
            status = '%s favourites  |  Select a list.' % count if count else 'No favourite lists yet.'
        else:
            status = '%s lists  |  Select a list.' % count
        self.status_label.setLabel(status)

    def _wire_rows(self):
        filled = self._filled
        if not filled:
            self.filter_button.controlDown(self.create_button)
            self.create_button.controlDown(self.filter_button)
            self.back_button.controlDown(self.filter_button)
            return
        slot = self._cursor - self._offset
        if slot < 0 or slot >= filled:
            slot = 0
        self.filter_button.controlDown(self.results_list)
        self.create_button.controlDown(self.results_list)
        self.create_button.controlRight(self.results_list)
        self.back_button.controlDown(self.results_list)
        self.results_list.controlRight(self._slots[slot]['fav'])
        self.results_list.controlLeft(self.results_list)
        self.results_list.controlDown(self.results_list)
        if self._offset > 0:
            self.results_list.controlUp(self.results_list)
        else:
            self.results_list.controlUp(self.filter_button)
        for index in range(filled):
            fav = self._slots[index]['fav']
            vote = self._slots[index]['vote']
            fav.controlLeft(self.results_list)
            fav.controlRight(vote)
            vote.controlLeft(fav)
            vote.controlRight(vote)
            self._wire_vertical(index, filled, 'fav')
            self._wire_vertical(index, filled, 'vote')

    def _wire_vertical(self, index, filled, key):
        control = self._slots[index][key]
        if index > 0:
            control.controlUp(self._slots[index - 1][key])
        elif self._offset > 0:
            control.controlUp(control)
        else:
            control.controlUp(self.filter_button)
        if index + 1 < filled:
            control.controlDown(self._slots[index + 1][key])
        else:
            control.controlDown(control)

    def _focus_control(self):
        if not self.visible_items or not self._filled:
            return self.filter_button
        slot = self._cursor - self._offset
        if slot < 0 or slot >= self._filled:
            slot = 0
        if self._column == 'title':
            return self.results_list
        return self._slots[slot].get(self._column) or self.results_list

    def _list_pos(self):
        try:
            return int(self.results_list.getSelectedPosition())
        except Exception:
            return -1

    def _focus_is_list(self):
        try:
            return self.getFocusId() == self.results_list.getId()
        except Exception:
            return False

    def _slot_index(self, focus_id):
        for index, slot in enumerate(self._slots):
            if focus_id in (slot['fav'].getId(), slot['vote'].getId()):
                return index
        return None

    def _column_for(self, focus_id):
        if self._focus_is_list():
            return 'title'
        for slot in self._slots:
            if focus_id == slot['fav'].getId():
                return 'fav'
            if focus_id == slot['vote'].getId():
                return 'vote'
        return self._column

    def _sync_cursor_from_focus(self):
        if self._focus_is_list():
            pos = self._list_pos()
            if pos < 0 or pos >= self._filled:
                return
            self._cursor = self._offset + pos
            self._column = 'title'
            if self._filled:
                self.results_list.controlRight(self._slots[pos]['fav'])
            return
        slot = self._slot_index(self.getFocusId())
        if slot is None or slot >= self._filled:
            return
        index = self._offset + slot
        if index >= len(self.visible_items):
            return
        self._cursor = index
        self._column = self._column_for(self.getFocusId())
        try:
            self.results_list.selectItem(slot)
        except Exception:
            pass

    def _show_preview(self):
        item = self._current_item()
        self.current_index = self._cursor if item else -1
        if not item:
            self.title_label.setLabel('[B]No favourites[/B]' if self.favs_only else '[B]Community Lists[/B]')
            self.meta_label.setLabel('')
            self.overview_box.setText(
                'No favourite lists yet. Press Favourite on a list, then press Favourites to see only those lists.'
                if self.favs_only else
                'Each list has Favourite and Upvote beside the title.'
            )
            try:
                self.poster.setImage(paths.ICON_PATH)
            except Exception:
                pass
            return
        self.title_label.setLabel('[B]%s[/B]' % (item.get('title') or 'Community Lists'))
        self.meta_label.setLabel(item.get('meta') or '')
        text = item.get('overview') or ''
        if self._is_fav(item):
            text = (text + '\n\nIn your favourites.').strip()
        self.overview_box.setText(text)
        try:
            self.poster.setImage(item.get('image') or paths.ICON_PATH)
        except Exception:
            pass

    def update_preview(self, force=False):
        del force
        self._show_preview()

    def select_current(self):
        pos = self._list_pos()
        item = self._item_at(self._offset + pos)
        if not item:
            return
        self._cursor = self._offset + pos
        self._column = 'title'
        self.on_select(item)

    def onAction(self, action):
        action_id = action.getId()
        if action_id == 5:
            self._shift(-LIST_ROW_COUNT)
            return
        if action_id == 6:
            self._shift(LIST_ROW_COUNT)
            return
        if self._at_list_edge(action_id):
            self._column = 'title'
            self._cursor = self._offset + max(self._list_pos(), 0)
            self._shift(1 if action_id in _MOVE_DOWN else -1)
            return
        if action_id in _MOVE_DOWN and self._last_focus_id == self.getFocusId() and self._can_scroll(1):
            self._shift(1)
            return
        if action_id in _MOVE_UP and self._last_focus_id == self.getFocusId() and self._can_scroll(-1):
            self._shift(-1)
            return
        super(CommunityListsWindow, self).onAction(action)
        self._sync_cursor_from_focus()
        self._last_focus_id = self.getFocusId()
        self._last_list_pos = self._list_pos()
        self._show_preview()

    def _at_list_edge(self, action_id):
        if not self._focus_is_list() or not self.visible_items:
            return False
        pos = self._list_pos()
        if pos != self._last_list_pos:
            return False
        if action_id in _MOVE_DOWN:
            return pos >= self._filled - 1 and (self._offset + pos) < len(self.visible_items) - 1
        if action_id in _MOVE_UP:
            return pos <= 0 and self._offset > 0
        return False

    def _can_scroll(self, delta):
        if not self.visible_items:
            return False
        if self._focus_is_list():
            pos = self._list_pos()
            if delta > 0:
                return pos >= self._filled - 1 and (self._offset + pos) < len(self.visible_items) - 1
            return pos <= 0 and self._offset > 0
        slot = self._slot_index(self.getFocusId())
        if slot is None:
            return False
        if delta > 0:
            return slot >= self._filled - 1 and (self._offset + slot) < len(self.visible_items) - 1
        return slot == 0 and self._offset > 0

    def _shift(self, delta):
        if not self.visible_items:
            return
        self._column = self._column_for(self.getFocusId())
        self._cursor = max(0, min(len(self.visible_items) - 1, self._cursor + delta))
        self._fit_offset()
        self._refresh_rows()
        self.setFocus(self._focus_control())
        self._last_focus_id = self.getFocusId()
        self._last_list_pos = self._list_pos()
        self._show_preview()

    def _favourite_slot(self, slot):
        self._cursor = self._offset + slot
        self._column = 'fav'
        self.toggle_favourite()

    def _upvote_slot(self, slot):
        self._cursor = self._offset + slot
        self._column = 'vote'
        self.upvote_current()

    def toggle_favourite(self):
        item = self._current_item()
        ident = list_id(item)
        if not ident:
            notify('Highlight a list first.')
            return
        favs = load_favs()
        if ident in favs:
            favs = [entry for entry in favs if entry != ident]
            notify('Removed from favourites.')
        else:
            favs.append(ident)
            notify('Added to favourites.')
        save_favs(favs)
        self.fav_ids = set(favs)
        self.populate_list()
        self.setFocus(self._focus_control())
        self._last_focus_id = self.getFocusId()

    def upvote_current(self):
        item = self._current_item()
        ident = list_id(item)
        if not ident:
            notify('Highlight a list first.')
            return
        if item.get('voted'):
            notify('You have already upvoted this list.')
            return
        result = busy_fetch(lambda: cast_vote(ident), 'Sending vote...')
        if not isinstance(result, dict):
            return
        data = item.get('data') or {}
        data['votes'] = int(result.get('votes') or 0)
        data['voted'] = True
        item['data'] = data
        item['voted'] = True
        item['meta'] = list_meta(data)
        self.all_items.sort(
            key=lambda row: (
                int((row.get('data') or {}).get('pinned') or 0),
                int((row.get('data') or {}).get('votes') or 0),
            ),
            reverse=True,
        )
        notify('Upvoted.')
        self.populate_list()
        self.setFocus(self._focus_control())
        self._last_focus_id = self.getFocusId()

    def toggle_filter(self):
        self.favs_only = not self.favs_only
        self._column = 'title'
        self._cursor = -1
        self.populate_list()
        self.setFocus(self._focus_control())
        self._last_focus_id = self.getFocusId()

    def open_create(self):
        window = CreateListWindow()
        window.doModal()
        del window


class CreateListWindow(ColossusFullWindow):
    def __init__(self):
        super(CreateListWindow, self).__init__('')
        self.setup_canvas()
        self.set_controls()
        self.setFocus(self.back_button)

    def set_controls(self):
        self.add_fanart(paths.BACKDROP_PATH or paths.FANART_PATH)
        self.back_button = text_button('Back')
        self.placeControl(self.back_button, 4, 4, 8, 14)
        self.connect(self.back_button, self.close)
        self.back_button.controlRight(self.back_button)
        self.back_button.controlDown(self.back_button)

        qr_path = COMMUNITY_QR_PATH if os.path.exists(COMMUNITY_QR_PATH) else paths.ICON_PATH
        self.qr_image = pyxbmct.Image(qr_path, aspectRatio=2)
        self.placeControl(self.qr_image, 18, 8, 64, 30)

        self.message_box = pyxbmct.TextBox(font='font13', textColor='0xFFFFFFFF')
        self.placeControl(self.message_box, 28, 42, 40, 50)
        self.message_box.setText(
            'Would you like to make your own lists that will appear in this addon?\n\n'
            'Scan the QR code or visit %s to get started.' % COMMUNITY_PAGE
        )


def notify(message):
    xbmcgui.Dialog().notification(paths.ADDON_NAME, message, paths.ICON_PATH, 3000)


def busy_fetch(func, message):
    data, error, canceled = dialogs.busy(func, message)
    if canceled:
        return None
    if error is not None:
        dialogs.ok(paths.ADDON_NAME, 'Could not load community lists.\n%s' % error)
        return None
    return data


def cast_vote(list_id):
    response = requests.post(
        FEED_URL + '/vote',
        json={'list_id': int(list_id), 'voter_id': device_user_id()},
        timeout=20,
        headers={'User-Agent': 'Colossus', 'Accept': 'application/json'},
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError('Vote was not accepted.')
    return payload


def fetch_lists():
    response = requests.get(
        FEED_URL,
        params={'voter': device_user_id()},
        timeout=25,
        headers={'User-Agent': 'Colossus', 'Accept': 'application/json'},
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        return []
    lists = payload.get('lists') or []
    return lists if isinstance(lists, list) else []


def list_meta(entry):
    items = entry.get('items') if isinstance(entry.get('items'), list) else []
    owner = (entry.get('owner') or '').strip()
    count = '%s item' % len(items) if len(items) == 1 else '%s items' % len(items)
    votes = int(entry.get('votes') or 0)
    vote_text = '1 vote' if votes == 1 else '%s votes' % votes
    return '  |  '.join([part for part in (owner, count, vote_text) if part])


def list_row(entry):
    title = kodi_colour(entry.get('title') or 'Untitled list')
    return {
        'label': title,
        'title': title,
        'meta': list_meta(entry),
        'overview': 'Select this list to browse its items.',
        'image': safe_image(entry.get('image')),
        'voted': bool(entry.get('voted')),
        'data': entry,
    }


def content_row(item):
    title = kodi_colour(item.get('title') or 'Untitled')
    links = item_links(item)
    if len(links) == 1:
        meta = '1 link'
    else:
        meta = '%s links' % len(links)
    description = (item.get('description') or '').strip() or 'No description.'
    return {
        'label': title,
        'title': title,
        'meta': meta,
        'overview': description,
        'image': safe_image(item.get('image')),
        'links': links,
        'plain': plain_title(title),
    }


def open_window(heading, status_text, items, on_select, empty_title, empty_overview, list_heading, allow_search=False):
    window = CommunityWindow(
        heading=heading,
        status_text=status_text,
        items=items,
        on_select=on_select,
        art_path=paths.ICON_PATH,
        empty_title=empty_title,
        empty_meta='',
        empty_overview=empty_overview,
        allow_search=allow_search,
        search_heading='Search',
        list_heading=list_heading,
    )
    window.doModal()
    del window


def play_direct(title, url, kind):
    label = plain_title(title)
    if kind == 'audio':
        header_string = player.encode_headers({
            'User-Agent': USER_AGENT,
            'Accept': '*/*',
        })
        path = '%s|%s' % (url, header_string) if header_string else url
        list_item = xbmcgui.ListItem(label=label, path=path)
        list_item.setInfo('music', {'title': label})
        list_item.setProperty('IsPlayable', 'true')
        xbmc.Player().play(path, list_item, False)
        return
    player.play_stream(label, url)


def _stream_link(url, link):
    """Pull a ClearKey pair out of an old is_clearkey address, then keep the https link."""
    link = dict(link or {})
    url = (url or '').strip()
    if url.startswith('is_clearkey://'):
        url = url[len('is_clearkey://'):]
    marker = '<$>'
    if marker in url:
        url, _sep, tail = url.partition(marker)
        url = url.strip()
        if '|' in tail and not (link.get('kid') and link.get('key')):
            _scheme, _sep, pair = tail.partition('|')
            kid, _sep, key = pair.partition(':')
            kid = kid.strip()
            key = key.strip()
            if kid and key:
                link['kid'] = kid
                link['key'] = key
    return url, link


def play_link(title, url, link=None):
    url, link = _stream_link(url, link)
    if not url:
        notify('That item has no link.')
        return
    drm = link_drm(link)
    headers = link_headers(link)
    kind = media_kind(url)
    if drm or kind == 'video':
        player.play_stream(plain_title(title), url, headers=headers, drm=drm)
        return
    if kind == 'audio':
        play_direct(title, url, kind)
        return

    progress = dialogs.Progress()
    progress.create(paths.ADDON_NAME, 'Resolving link...')
    try:
        import resolveurl
        hosted = resolveurl.HostedMediaFile(url=url)
        if not hosted:
            raise RuntimeError('ResolveURL does not support that link.')
        resolved = hosted.resolve()
        if isinstance(resolved, dict):
            resolved = resolved.get('url') or ''
        resolved = str(resolved or '').strip()
        if not resolved.startswith('http'):
            raise RuntimeError('ResolveURL did not return a stream.')
    except Exception as exc:
        xbmc.log('[Colossus] Community resolve failed: %s %s' % (exc, url), xbmc.LOGINFO)
        dialogs.ok(paths.ADDON_NAME, 'Could not play that link.\n%s' % exc)
        return
    finally:
        try:
            progress.close()
        except Exception:
            pass
    play_direct(title, resolved, media_kind(resolved) or 'video')


def open_sources(row):
    links = row.get('links') or []
    sources = []
    for index, link in enumerate(links):
        url = link.get('url') or ''
        host = host_name(url)
        label = (link.get('label') or '').strip()
        sources.append({
            'label': kodi_colour(label) if label else 'Source %s    %s' % (index + 1, host),
            'title': row.get('title') or 'Sources',
            'meta': plain_title(label) if label else host,
            'overview': row.get('overview') or '',
            'image': row.get('image') or paths.ICON_PATH,
            'url': url,
            'plain': row.get('plain') or plain_title(row.get('title')),
            'link': link,
        })
    open_window(
        'SOURCES',
        '%s sources  |  Select one to play.' % len(sources),
        sources,
        lambda source: play_link(source.get('plain'), source.get('url'), source.get('link')),
        plain_title(row.get('title')),
        row.get('overview') or 'Choose a source.',
        'SOURCES',
    )


def open_item(row):
    links = row.get('links') or []
    if not links:
        notify('That item has no link.')
        return
    if len(links) == 1:
        play_link(row.get('plain'), links[0].get('url'), links[0])
        return
    open_sources(row)


def open_list(row):
    entry = row.get('data') or {}
    items = entry.get('items') if isinstance(entry.get('items'), list) else []
    rows = [content_row(item) for item in items]
    if not rows:
        notify('That list has no items yet.')
        return
    title = plain_title(entry.get('title') or 'Community list')
    open_window(
        title,
        '%s items  |  Select one to play.' % len(rows),
        rows,
        open_item,
        title,
        'Highlight an item to see its image and description. Select it to play.',
        'ITEMS',
        allow_search=True,
    )


def open_community():
    lists = busy_fetch(fetch_lists, 'Loading community lists...')
    if lists is None:
        return
    rows = [list_row(entry) for entry in lists if isinstance(entry, dict)]
    if not rows:
        notify('No community lists have been approved yet.')
        return
    window = CommunityListsWindow(rows, open_list)
    window.doModal()
    del window
